"""A2A 공통 키트 (공식 a2a-sdk 1.x 기반).

서버 측
- build_agent_card()     : Agent Card 생성 (skill 목록, Bearer 인증 명시)
- SkillRouterExecutor    : message.metadata["skill"] 값으로 핸들러를 고르는 AgentExecutor
- create_agent_app()     : Agent Card + JSON-RPC 엔드포인트 + 인증 가드가 붙은 FastAPI 앱

클라이언트 측
- A2AConnector           : Agent Card 캐시 + 사용자 토큰 전달 + 스트리밍 결과 수집

skill 지정 규칙(이 프로젝트의 약속):
  A2A 표준에는 "어떤 skill 을 호출한다"는 필드가 없으므로 Message.metadata["skill"] 에 skill id 를 넣는다.
"""

import json
import logging
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
from a2a.auth.user import UnauthenticatedUser, User
from a2a.client import A2ACardResolver, ClientCallContext, ClientConfig, ClientFactory
from a2a.helpers.proto_helpers import (
    get_data_parts,
    get_text_parts,
    new_data_part,
    new_task_from_user_message,
    new_text_part,
)
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.context import ServerCallContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import (
    DefaultServerCallContextBuilder,
    add_a2a_routes_to_fastapi,
    create_agent_card_routes,
    create_jsonrpc_routes,
)
from a2a.server.tasks import InMemoryTaskStore, TaskStore, TaskUpdater
from a2a.types.a2a_pb2 import (
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentProvider,
    AgentSkill,
    HTTPAuthSecurityScheme,
    Message,
    Part,
    Role,
    SecurityScheme,
    SendMessageRequest,
    Task,
    TaskState,
)
from a2a.utils.constants import TransportProtocol
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from google.protobuf.json_format import MessageToDict

from common import simulate, telemetry
from common.auth import Principal, directory, principal_from_header
from common.config import A2A_RPC_PATH, MONITOR_URL, NODES, node_of_url

logger = logging.getLogger(__name__)

TERMINAL_STATES = {"completed", "failed", "canceled", "rejected"}


def state_name(state: int) -> str:
    """TaskState enum -> 'completed', 'input_required' 같은 짧은 이름."""
    return TaskState.Name(state).removeprefix("TASK_STATE_").lower()


# =============================================================================
# 서버 측
# =============================================================================


def build_agent_card(
    *,
    name: str,
    description: str,
    base_url: str,
    skills: list[dict[str, Any]],
    version: str = "0.1.0",
) -> AgentCard:
    return AgentCard(
        name=name,
        description=description,
        version=version,
        provider=AgentProvider(organization="Sample Tech (mock)", url=base_url),
        supported_interfaces=[
            AgentInterface(
                url=base_url + A2A_RPC_PATH,
                protocol_binding=TransportProtocol.JSONRPC,
                protocol_version="1.0",
            )
        ],
        capabilities=AgentCapabilities(streaming=True),
        security_schemes={
            "bearer": SecurityScheme(
                http_auth_security_scheme=HTTPAuthSecurityScheme(
                    scheme="bearer",
                    bearer_format="JWT",
                    description="사내 SSO(OIDC) 토큰. 목업에서는 dev-token-<user_id>",
                )
            )
        },
        default_input_modes=["text/plain", "application/json"],
        default_output_modes=["text/plain", "application/json"],
        skills=[
            AgentSkill(
                id=s["id"],
                name=s["name"],
                description=s["description"],
                tags=s.get("tags", []),
                examples=s.get("examples", []),
            )
            for s in skills
        ],
    )


class A2AUser(User):
    def __init__(self, principal: Principal):
        self.principal = principal

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def user_name(self) -> str:
        return self.principal.user_id


class SSOContextBuilder(DefaultServerCallContextBuilder):
    """기본 컨텍스트(헤더, A2A 버전, 확장) + Bearer 토큰 -> principal, trace_id."""

    def build(self, request) -> ServerCallContext:
        context = super().build(request)
        principal = principal_from_header(request.headers.get("authorization"))
        context.user = A2AUser(principal) if principal else UnauthenticatedUser()
        context.state["principal"] = principal
        context.state["trace_id"] = request.headers.get("x-trace-id") or uuid.uuid4().hex[:12]
        return context


class SkillError(Exception):
    """핸들러가 사용자에게 보여줄 메시지와 함께 Task 를 failed 로 끝낼 때 사용."""


@dataclass
class SkillRequest:
    """핸들러에 전달되는 입력 묶음."""

    principal: Principal
    skill: str
    text: str
    data: dict[str, Any]
    task: Task
    is_new_task: bool
    updater: TaskUpdater
    trace_id: str
    interrupted: bool = False
    stream_artifact_id: str | None = None

    async def stream_text(self, delta: str, name: str = "answer") -> None:
        """텍스트를 조각 단위로 artifact 에 이어 붙여 스트리밍 (A2A TaskArtifactUpdateEvent append)."""
        append = self.stream_artifact_id is not None
        if not append:
            self.stream_artifact_id = uuid.uuid4().hex
        await self.updater.add_artifact([new_text_part(delta, media_type="text/markdown")],
                                        artifact_id=self.stream_artifact_id, name=name, append=append)

    async def wait_for_input(self, text: str) -> None:
        """Task 를 종료하지 않고 input_required 로 열어둔다 (다음 메시지에서 이어서 처리)."""
        self.interrupted = True
        await self.updater.requires_input(self.agent_message(text))

    async def progress(self, text: str) -> None:
        """진행 상황을 WORKING 상태 메시지로 스트리밍."""
        telemetry.emit("skill.progress", trace_id=self.trace_id, skill=self.skill,
                       task_id=self.task.id, detail=text)
        await self.updater.update_status(
            TaskState.TASK_STATE_WORKING,
            message=self.updater.new_agent_message([new_text_part(text)]),
        )

    async def reply(self, *, text: str = "", data: dict | None = None, name: str = "result") -> None:
        parts: list[Part] = []
        if text:
            parts.append(new_text_part(text, media_type="text/markdown"))
        if data is not None:
            parts.append(new_data_part(data, media_type="application/json"))
        await self.updater.add_artifact(parts, name=name)

    def agent_message(self, text: str) -> Message:
        return self.updater.new_agent_message([new_text_part(text)])


SkillHandler = Callable[[SkillRequest], Awaitable[None]]


class SkillRouterExecutor(AgentExecutor):
    """skill id -> 핸들러 라우팅.

    핸들러 규약:
      - 결과는 req.reply(...) 로 artifact 를 추가하고 반환하면 completed
      - Task 를 열어두려면 req.wait_for_input(...) 후 반환 (input_required)
      - 실패는 SkillError 를 raise (failed)
    """

    def __init__(
        self,
        name: str,
        handlers: dict[str, SkillHandler],
        classifier: Callable[[str], Awaitable[str]] | None = None,
    ):
        self.name = name
        self.handlers = handlers
        self.classifier = classifier

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        state = context.call_context.state
        principal: Principal | None = state.get("principal")
        trace_id = state.get("trace_id", "-")
        telemetry.set_trace(trace_id)  # 이 요청 처리 중 나가는 하위 호출/LLM 호출에 같은 trace 전파

        is_new = context.current_task is None
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)
        updater = TaskUpdater(event_queue, task.id, task.context_id)

        msg_meta = MessageToDict(context.message.metadata) if context.message else {}
        skill = msg_meta.get("skill") or ""
        text = context.get_user_input()
        data_parts = get_data_parts(context.message.parts) if context.message else []
        data = next((d for d in data_parts if isinstance(d, dict)), {})

        if principal is None:
            await updater.reject(updater.new_agent_message([new_text_part("인증이 필요합니다.")]))
            return
        if not skill and self.classifier and text:
            skill = await self.classifier(text)
        if not skill and len(self.handlers) == 1:
            skill = next(iter(self.handlers))

        handler = self.handlers.get(skill)
        if handler is None:
            await updater.reject(
                updater.new_agent_message(
                    [new_text_part(f"[{self.name}] 지원하지 않는 skill 입니다: '{skill}'")]
                )
            )
            return

        logger.info("[%s] trace=%s user=%s skill=%s task=%s", self.name, trace_id,
                    principal.user_id, skill, task.id)
        req = SkillRequest(
            principal=principal, skill=skill, text=text, data=data, task=task,
            is_new_task=is_new, updater=updater, trace_id=trace_id,
        )
        started = telemetry.now_ms()
        telemetry.emit("skill.start", trace_id=trace_id, skill=skill, user=principal.user_id,
                       task_id=task.id, continued=not is_new)
        final_state, detail = "completed", ""
        try:
            await updater.start_work()
            await handler(req)
            if req.interrupted:
                final_state = "input_required"
            else:
                await updater.complete()
        except SkillError as e:
            final_state, detail = "failed", str(e)
            await updater.failed(req.agent_message(str(e)))
        except Exception as e:  # noqa: BLE001
            logger.exception("[%s] skill=%s 처리 실패", self.name, skill)
            final_state, detail = "failed", f"내부 오류: {e}"
            await updater.failed(req.agent_message(f"[{self.name}] 내부 오류: {e}"))
        telemetry.emit("skill.end", trace_id=trace_id, skill=skill, user=principal.user_id,
                       task_id=task.id, state=final_state, detail=detail or None,
                       duration_ms=round(telemetry.now_ms() - started, 1))

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task
        if task:
            await TaskUpdater(event_queue, task.id, task.context_id).cancel()


class _AuthGuard:
    """JSON-RPC 엔드포인트는 Bearer 토큰 필수 (Agent Card 는 공개). 순수 ASGI 미들웨어."""

    def __init__(self, app, protected_prefixes: tuple[str, ...]):
        self.app = app
        self.protected = protected_prefixes

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http" and scope["path"].startswith(self.protected):
            headers = {k.decode().lower(): v.decode() for k, v in scope.get("headers", [])}
            if principal_from_header(headers.get("authorization")) is None:
                body = json.dumps({"error": "unauthorized", "detail": "Bearer 토큰이 필요합니다."}).encode()
                await send({"type": "http.response.start", "status": 401,
                            "headers": [(b"content-type", b"application/json"),
                                        (b"www-authenticate", b"Bearer")]})
                await send({"type": "http.response.body", "body": body})
                return
        await self.app(scope, receive, send)


def create_agent_app(
    card: AgentCard,
    executor: AgentExecutor,
    *,
    node: str,
    console_html: Path | None = None,
    task_store: TaskStore | None = None,
    protected_prefixes: tuple[str, ...] = (A2A_RPC_PATH, "/api/"),
) -> FastAPI:
    """A2A 서버 앱.

    - /.well-known/agent-card.json, /a2a (JSON-RPC), /health
    - /            : 운영 콘솔 화면 (console_html)
    - /_console/*  : 콘솔 공용 자산 + 메타 정보
    - /admin/*     : 각 서비스가 추가하는 콘솔용 조작 API
                     (목업은 인증 없음. 운영에서는 관리자 권한 + 내부망 한정 필수)
    """
    telemetry.configure(node)
    app = FastAPI(title=card.name, description=card.description, version=card.version)
    mount_console(app, node)
    if console_html is not None:
        @app.get("/", include_in_schema=False)
        async def console() -> FileResponse:
            return FileResponse(console_html)

    handler = DefaultRequestHandler(
        agent_executor=executor,
        task_store=task_store or InMemoryTaskStore(),
        agent_card=card,
    )
    add_a2a_routes_to_fastapi(
        app,
        agent_card_routes=create_agent_card_routes(card),
        jsonrpc_routes=create_jsonrpc_routes(
            handler, rpc_url=A2A_RPC_PATH, context_builder=SSOContextBuilder()
        ),
    )

    @app.get("/health", tags=["ops"])
    async def health() -> dict:
        return {"status": "ok", "agent": card.name}

    app.add_middleware(_AuthGuard, protected_prefixes=protected_prefixes)
    return app


CONSOLE_STATIC_DIR = Path(__file__).resolve().parent / "console_static"


def mount_console(app: FastAPI, node: str) -> None:
    """콘솔 공용 자산(/_console/static)과 메타 정보(/_console/meta)."""
    app.mount("/_console/static", StaticFiles(directory=CONSOLE_STATIC_DIR), name="console-static")

    @app.get("/_console/meta", include_in_schema=False)
    async def console_meta() -> dict:
        return {
            "node": node,
            "nodes": NODES,
            "monitor_url": MONITOR_URL,
            "users": [
                {"id": u["id"], "name": u["name"], "team": u["team"], "groups": u["groups"]}
                for u in directory().values()
            ],
        }


# =============================================================================
# 클라이언트 측
# =============================================================================


@dataclass
class AgentResult:
    """스트리밍 이벤트를 모아 만든 최종 결과.

    artifact 는 id 별로 모은다. append=True 조각은 같은 artifact 의 텍스트 뒤에 이어 붙인다.
    """

    agent: str
    task_id: str = ""
    context_id: str = ""
    state: str = "unknown"
    status_text: str = ""
    progress: list[str] = field(default_factory=list)
    artifacts: dict[str, dict] = field(default_factory=dict)

    def add_parts(self, artifact_id: str, name: str, parts, append: bool = False) -> str:
        art = self.artifacts.get(artifact_id)
        if art is None or not append:
            art = self.artifacts[artifact_id] = {"name": name, "text": "", "data": []}
        delta = "".join(get_text_parts(parts))
        art["text"] += delta
        art["data"].extend(d for d in get_data_parts(parts) if isinstance(d, dict))
        return delta

    @property
    def ok(self) -> bool:
        return self.state == "completed"

    @property
    def text(self) -> str:
        return "\n\n".join(a["text"] for a in self.artifacts.values() if a["text"])

    @property
    def first_data(self) -> dict:
        return next((d for a in self.artifacts.values() for d in a["data"]), {})

    def to_dict(self) -> dict:
        return {
            "agent": self.agent, "task_id": self.task_id, "context_id": self.context_id,
            "state": self.state, "status_text": self.status_text, "progress": self.progress,
            "text": self.text, "data": self.first_data,
        }


ProgressCallback = Callable[[str], Awaitable[None]]


class A2AConnector:
    """원격 A2A Agent 호출기.

    - Agent Card 는 base_url 별로 1회 조회 후 캐시
    - 호출마다 사용자 토큰을 Authorization 헤더로 전달 (하위 Agent 가 사용자 권한으로 처리)
    - on_progress: 진행 상태 메시지, on_text: 스트리밍되는 답변 텍스트 조각
    """

    def __init__(self, timeout: float = 180.0):
        self._http = httpx.AsyncClient(timeout=timeout)
        self._factory = ClientFactory(ClientConfig(httpx_client=self._http, streaming=True))
        self._cards: dict[str, AgentCard] = {}

    async def card(self, base_url: str, refresh: bool = False) -> AgentCard:
        if refresh or base_url not in self._cards:
            self._cards[base_url] = await A2ACardResolver(self._http, base_url).get_agent_card()
        return self._cards[base_url]

    async def send(
        self,
        base_url: str,
        *,
        skill: str,
        token: str,
        text: str = "",
        data: dict | None = None,
        task_id: str | None = None,
        context_id: str | None = None,
        trace_id: str | None = None,
        on_progress: ProgressCallback | None = None,
        on_text: ProgressCallback | None = None,
    ) -> AgentResult:
        card = await self.card(base_url)
        client = self._factory.create(card)

        parts: list[Part] = []
        if text:
            parts.append(new_text_part(text))
        if data is not None:
            parts.append(new_data_part(data, media_type="application/json"))
        message = Message(
            role=Role.ROLE_USER,
            message_id=uuid.uuid4().hex,
            parts=parts,
            task_id=task_id or "",
            context_id=context_id or "",
        )
        message.metadata.update({"skill": skill})

        trace_id = trace_id or telemetry.get_trace() or telemetry.new_trace_id()
        headers = {"Authorization": f"Bearer {token}", "X-Trace-Id": trace_id}
        call_ctx = ClientCallContext(service_parameters=headers)

        target = node_of_url(base_url)
        peer = {"from": telemetry.NODE, "to": target, "call_id": uuid.uuid4().hex[:10]}
        started = telemetry.now_ms()
        telemetry.emit("a2a.request", trace_id=trace_id, **peer, skill=skill, task_id=task_id,
                       method="SendStreamingMessage")
        # 목업 네트워크 지연 (PC → 사내 서버는 사내망/VPN, 서버 ↔ 서버는 데이터센터 내부)
        await simulate.delay("net.pc" if telemetry.NODE.startswith("desktop") else "net.dc")
        result = AgentResult(agent=card.name)
        try:
            await self._consume(client, message, call_ctx, result, on_progress, on_text)
        except Exception as e:
            telemetry.emit("a2a.response", trace_id=trace_id, **peer, skill=skill, state="error",
                           detail=f"{e.__class__.__name__}: {e}",
                           duration_ms=round(telemetry.now_ms() - started, 1))
            raise
        telemetry.emit("a2a.response", trace_id=trace_id, **peer, skill=skill, task_id=result.task_id,
                       state=result.state,
                       detail=result.status_text if result.state not in ("completed", "working") else None,
                       duration_ms=round(telemetry.now_ms() - started, 1))
        return result

    async def _consume(self, client, message: Message, call_ctx: ClientCallContext, result: AgentResult,
                       on_progress: ProgressCallback | None, on_text: ProgressCallback | None) -> None:
        async for event in client.send_message(SendMessageRequest(message=message), context=call_ctx):
            if event.HasField("task"):
                t = event.task
                result.task_id, result.context_id = t.id, t.context_id
                result.state = state_name(t.status.state)
                for artifact in t.artifacts:
                    result.add_parts(artifact.artifact_id, artifact.name, artifact.parts)
            elif event.HasField("status_update"):
                su = event.status_update
                result.state = state_name(su.status.state)
                if su.status.HasField("message"):
                    msg_text = "\n".join(get_text_parts(su.status.message.parts))
                    if msg_text:
                        result.status_text = msg_text
                        if result.state == "working":
                            result.progress.append(msg_text)
                            if on_progress:
                                await on_progress(msg_text)
            elif event.HasField("artifact_update"):
                au = event.artifact_update
                delta = result.add_parts(au.artifact.artifact_id, au.artifact.name, au.artifact.parts, au.append)
                if delta and on_text:
                    await on_text(delta)
            elif event.HasField("message"):
                result.state = "completed"
                result.add_parts("message", "message", event.message.parts)

    async def aclose(self) -> None:
        await self._http.aclose()