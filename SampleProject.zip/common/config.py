"""모든 프로세스가 공유하는 설정.

목업은 환경변수 + 기본값으로 동작한다.
운영 전환 시: 서비스별 설정 파일 / 설정 서버(Vault, Consul 등)로 교체.
"""

import os
from datetime import date
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("MOCK_DATA_DIR", ROOT_DIR / "data"))

# --- 운영 서버 측 Agent 주소 ---------------------------------------------
# PC 는 HUB_URL 하나만 알면 된다. 하위 Agent 주소는 Hub 만 알고 있다.
HUB_URL = os.getenv("HUB_URL", "http://127.0.0.1:9000")
KNOWLEDGE_AGENT_URL = os.getenv("KNOWLEDGE_AGENT_URL", "http://127.0.0.1:9101")
PEOPLE_AGENT_URL = os.getenv("PEOPLE_AGENT_URL", "http://127.0.0.1:9102")
REQUEST_BROKER_URL = os.getenv("REQUEST_BROKER_URL", "http://127.0.0.1:9103")

# Hub 가 기동 시 Agent Card 를 읽어 skill 레지스트리를 구성할 대상
DOWNSTREAM_AGENT_URLS = [
    KNOWLEDGE_AGENT_URL,
    PEOPLE_AGENT_URL,
    REQUEST_BROKER_URL,
]

A2A_RPC_PATH = "/a2a"

# --- 사내 LLM (vLLM, OpenAI 호환 API) ------------------------------------------
# PC Agent 와 서버 Agent 모두 이 주소의 vLLM 을 직접 사용한다.
# 목업 기본값은 scripts/run_all.py 가 띄우는 mock vLLM(:8800). 실제 사내 vLLM 으로 바꾸려면
#   VLLM_BASE_URL=http://<사내 vLLM 주소>/v1, VLLM_MODEL=<served-model-name>, VLLM_API_KEY=<키>
VLLM_BASE_URL = os.getenv("VLLM_BASE_URL", "http://127.0.0.1:8800/v1").rstrip("/")
VLLM_MODEL = os.getenv("VLLM_MODEL", "corp-llm-32b-instruct")
VLLM_API_KEY = os.getenv("VLLM_API_KEY", "")
# mock vLLM 이 어떤 업무 응답을 만들지 알려주는 힌트(요청 body 의 mock_hint)를 보낼지.
# 실제 vLLM 은 모르는 필드를 무시하지만, 운영에서는 끄는 것을 권장.
VLLM_MOCK_HINTS = os.getenv("VLLM_MOCK_HINTS", "1") == "1"

# vllm(기본) | claude | template(규칙 기반, 지연 없음 - 오프라인 대체용)
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "vllm").lower()
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-opus-5-5")

# --- 지연 시뮬레이션 ------------------------------------------------------------
# 1.0 = 현실적인 속도, 2.0 = 2배 빠르게, 0 = 지연 없음 (scripts/run_all.py --fast)
MOCK_SPEED = float(os.getenv("MOCK_SPEED", "1.0"))
# mock vLLM 성능 (요청 1건 기준 토큰/초). 동시 요청이 많으면 생성 속도가 떨어진다.
MOCK_LLM_PREFILL_TPS = float(os.getenv("MOCK_LLM_PREFILL_TPS", "2500"))
MOCK_LLM_DECODE_TPS = float(os.getenv("MOCK_LLM_DECODE_TPS", "45"))

# --- 데스크탑(목업) -----------------------------------------------------------
DESKTOP_URLS = {
    "u002": os.getenv("DESKTOP_U002_URL", "http://127.0.0.1:8001"),
    "u003": os.getenv("DESKTOP_U003_URL", "http://127.0.0.1:8002"),
}

# --- 관제(Monitor) ------------------------------------------------------------
# 각 프로세스가 동작 이벤트(메타데이터만)를 보내는 곳. 빈 값이면 전송하지 않는다.
MONITOR_URL = os.getenv("MONITOR_URL", "http://127.0.0.1:9900")

VLLM_ORIGIN = VLLM_BASE_URL.removesuffix("/v1")

# 관제 화면/콘솔 내비게이션에서 쓰는 노드 목록 (node id -> 표시 정보)
NODES: dict[str, dict] = {
    "desktop:u002": {"label": "PC 이서준", "sub": "정산팀", "url": DESKTOP_URLS["u002"],
                     "health": "/api/me", "kind": "desktop"},
    "desktop:u003": {"label": "PC 박지아", "sub": "플랫폼팀", "url": DESKTOP_URLS["u003"],
                     "health": "/api/me", "kind": "desktop"},
    "hub": {"label": "Hub", "sub": "Gateway + Orchestrator", "url": HUB_URL,
            "health": "/health", "kind": "server"},
    "llm": {"label": "사내 vLLM", "sub": VLLM_MODEL, "url": VLLM_ORIGIN,
            "health": "/health", "kind": "llm"},
    "knowledge": {"label": "Knowledge Agent", "sub": "문서 검색", "url": KNOWLEDGE_AGENT_URL,
                  "health": "/health", "kind": "server"},
    "people": {"label": "People Agent", "sub": "담당자/주간보고", "url": PEOPLE_AGENT_URL,
               "health": "/health", "kind": "server"},
    "broker": {"label": "Request Broker", "sub": "담당자 요청", "url": REQUEST_BROKER_URL,
               "health": "/health", "kind": "server"},
}


def node_of_url(url: str) -> str:
    url = url.rstrip("/")
    for node_id, node in NODES.items():
        if node["url"].rstrip("/") == url:
            return node_id
    return url


# --- 목업 기준일 -------------------------------------------------------------
# 더미 데이터(주간 활동, 일정)가 2026-10-12 주간 기준으로 작성되어 있어 고정한다.
MOCK_TODAY = date.fromisoformat(os.getenv("MOCK_TODAY", "2026-10-16"))


def port_of(url: str) -> int:
    return int(url.rstrip("/").rsplit(":", 1)[1].split("/")[0])