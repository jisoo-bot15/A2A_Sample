"""아주 단순한 한국어 친화 검색 (문자 bigram 겹침 비율).

목업 전용. 운영 전환 시 벡터 검색(pgvector, OpenSearch k-NN 등) + 재랭킹으로 교체.
"""

import re

_TOKEN_RE = re.compile(r"[0-9a-z가-힣]+")

STOPWORDS = {
    "알려줘", "알려주세요", "알려", "해줘", "해주세요", "주세요", "관련", "관련된", "내용",
    "어떻게", "뭐야", "무엇", "무엇인가요", "있어", "있나요", "대해", "대해서", "대한", "좀",
    "정리", "정리해줘", "찾아줘", "찾아", "요청", "요청해줘", "확인", "확인해줘", "부탁",
    "에게", "한테", "님에게", "누구", "누구야", "누가", "담당자", "그리고", "에서", "내",
}


def tokens(text: str) -> list[str]:
    return [t for t in _TOKEN_RE.findall(text.lower()) if t not in STOPWORDS]


def bigrams(text: str) -> set[str]:
    grams: set[str] = set()
    for tok in tokens(text):
        if len(tok) == 1:
            continue
        if len(tok) == 2 or tok.isascii():
            grams.add(tok)
        if not tok.isascii():
            grams.update(tok[i:i + 2] for i in range(len(tok) - 1))
    return grams


def overlap(query: str | set[str], text: str) -> float:
    """query bigram 중 text 에 포함된 비율 (0~1)."""
    q = bigrams(query) if isinstance(query, str) else query
    if not q:
        return 0.0
    return len(q & bigrams(text)) / len(q)


def best_snippet(query: str, text: str, max_len: int = 220) -> str:
    """query 와 가장 많이 겹치는 문단을 잘라서 반환."""
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    if not paragraphs:
        return ""
    # 제목 한 줄짜리 문단보다는 본문이 있는 문단을 우선
    bodies = [p for p in paragraphs if len(re.sub(r"(?m)^#+.*$", "", p).strip()) >= 20] or paragraphs
    best = max(bodies, key=lambda p: overlap(query, p))
    best = re.sub(r"\s+", " ", re.sub(r"(?m)^#+\s*", "", best)).strip()
    return best if len(best) <= max_len else best[:max_len] + "…"
