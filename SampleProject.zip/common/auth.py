"""목업 SSO.

토큰 형식: ``dev-token-<user_id>`` (예: dev-token-u002)

운영 전환 시:
- PC App  : OIDC Authorization Code + PKCE 로 로그인, 토큰은 OS 키체인에 보관
- 서버    : JWT 서명/만료/audience 검증 후 claims(sub, groups 등)로 Principal 구성
- Hub→하위 Agent : 사용자 토큰을 그대로 전달하거나 OAuth Token Exchange(OBO)로 교환
"""

import json
from dataclasses import dataclass
from functools import lru_cache

from fastapi import HTTPException, Request

from common.config import DATA_DIR

TOKEN_PREFIX = "dev-token-"


@dataclass(frozen=True)
class Principal:
    """인증된 사용자. 하위 Agent 는 이 정보로 권한(ACL)을 판단한다."""

    user_id: str
    name: str
    team: str
    groups: tuple[str, ...]
    token: str

    def to_dict(self) -> dict:
        return {
            "user_id": self.user_id,
            "name": self.name,
            "team": self.team,
            "groups": list(self.groups),
        }


@lru_cache
def directory() -> dict[str, dict]:
    # 목업에서는 인사 디렉터리(users.json)를 IdP 처럼 사용한다.
    users = json.loads((DATA_DIR / "users.json").read_text(encoding="utf-8"))
    return {u["id"]: u for u in users}


def issue_dev_token(user_id: str) -> str:
    if user_id not in directory():
        raise ValueError(f"알 수 없는 사용자: {user_id}")
    return f"{TOKEN_PREFIX}{user_id}"


def verify_token(token: str | None) -> Principal | None:
    if not token or not token.startswith(TOKEN_PREFIX):
        return None
    user = directory().get(token[len(TOKEN_PREFIX):])
    if not user:
        return None
    return Principal(
        user_id=user["id"],
        name=user["name"],
        team=user["team"],
        groups=tuple(user["groups"]),
        token=token,
    )


def principal_from_header(authorization: str | None) -> Principal | None:
    if not authorization:
        return None
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer":
        return None
    return verify_token(token.strip())


def auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def require_principal(request: Request) -> Principal:
    """FastAPI 의존성: REST 확장 API 에서 사용."""
    principal = principal_from_header(request.headers.get("authorization"))
    if principal is None:
        raise HTTPException(status_code=401, detail="인증이 필요합니다.")
    return principal
