"""목업 지연 시뮬레이션.

모든 것이 한 PC 의 메모리에서 돌기 때문에 그대로 두면 수 ms 만에 끝나 '일을 안 하는 것처럼' 보인다.
작업 종류별로 현실적인 지연을 넣는다. LLM 지연은 mock vLLM 서버가 토큰 수 기준으로 따로 계산한다.

MOCK_SPEED: 1.0 = 현실 속도, 2.0 = 2배 빠르게, 0 = 지연 없음
운영 코드에는 들어가지 않는 부분이다.
"""

import asyncio
import random

from common.config import MOCK_SPEED

# 작업 종류별 지연 범위 (ms)
PROFILES = {
    "net.pc": (25, 70),          # PC → 사내 서버 (사내망/VPN)
    "net.dc": (2, 8),            # 서버 ↔ 서버 (같은 데이터센터)
    "vector_search": (180, 450),  # 문서 임베딩 검색
    "directory": (40, 110),      # 인사/담당자 조회
    "db_write": (20, 60),        # 요청 저장
    "local_scan": (80, 220),     # PC 작업 폴더/일정/활동 기록 읽기
}


def scaled(seconds: float) -> float:
    return 0.0 if MOCK_SPEED <= 0 else seconds / MOCK_SPEED


async def delay(profile: str, factor: float = 1.0) -> None:
    lo, hi = PROFILES[profile]
    seconds = scaled(random.uniform(lo, hi) / 1000 * factor)
    if seconds > 0:
        await asyncio.sleep(seconds)
