// 서버 운영 콘솔 공용 스크립트: 상단/내비게이션/탭, API 헬퍼, A2A 호출 테스터
/* eslint-disable no-unused-vars */

const C = (() => {
  const $ = (sel, el = document) => el.querySelector(sel);
  const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const h = (html) => {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  };
  const json = (v) => JSON.stringify(v, null, 2);
  const fmtTime = (iso) => (iso ? iso.replace('T', ' ').slice(5, 19) : '');
  const traceId = () => Math.random().toString(16).slice(2, 14).padEnd(12, '0');

  async function api(path, opts = {}) {
    const r = await fetch(path, { ...opts, headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) } });
    const body = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(body.detail || body.error || r.statusText);
    return body;
  }
  const send = (method) => (path, body, headers) =>
    api(path, { method, body: JSON.stringify(body ?? {}), headers });

  const state = { meta: null };

  function toast(text) {
    let box = $('.toast-box');
    if (!box) { box = h('<div class="toast-box"></div>'); document.body.append(box); }
    const t = h(`<div class="toast">${esc(text)}</div>`);
    box.append(t);
    setTimeout(() => t.remove(), 4000);
  }

  function userOptions(selected) {
    return state.meta.users.map((u) =>
      `<option value="${esc(u.id)}" ${u.id === selected ? 'selected' : ''}>${esc(u.name)} (${esc(u.team)}) · ${esc(u.id)}</option>`).join('');
  }
  const token = (userId) => `dev-token-${userId}`;

  // ------------------------------------------------------------- 레이아웃

  async function init({ title, subtitle, tabs, agentLinks = true }) {
    state.meta = await api('/_console/meta');
    document.title = `${title} 콘솔`;
    const nav = Object.entries(state.meta.nodes).map(([id, n]) => {
      const href = n.kind === 'desktop' ? n.url : `${n.url}/`;
      return `<a href="${esc(href)}" class="${id === state.meta.node ? 'active' : ''}" target="${id === state.meta.node ? '_self' : '_blank'}">${esc(n.label)}</a>`;
    }).join('');
    document.body.prepend(h(`<div>
      <header class="c-header">
        <div><div class="c-title">${esc(title)}</div><div class="c-sub">${esc(subtitle || '')}</div></div>
        <nav class="c-nav">${nav}<a class="monitor" href="${esc(state.meta.monitor_url)}/" target="_blank">관제</a>
          <a href="/docs" target="_blank">API 문서</a>${agentLinks ? '<a href="/.well-known/agent-card.json" target="_blank">Agent Card</a>' : ''}</nav>
      </header>
      <div class="c-tabs">${tabs.map((t, i) => `<button data-tab="${t.id}" class="${i ? '' : 'active'}">${esc(t.label)}</button>`).join('')}</div>
      <main class="c-body">${tabs.map((t, i) => `<section class="c-pane ${i ? 'hidden' : ''}" id="pane-${t.id}"></section>`).join('')}</main>
    </div>`));

    const rendered = new Set();
    const show = async (id) => {
      $$('.c-tabs button').forEach((b) => b.classList.toggle('active', b.dataset.tab === id));
      $$('.c-pane').forEach((p) => p.classList.toggle('hidden', p.id !== `pane-${id}`));
      const tab = tabs.find((t) => t.id === id);
      if (!rendered.has(id) || tab.refresh) {
        rendered.add(id);
        try { await tab.render($(`#pane-${id}`)); } catch (e) { $(`#pane-${id}`).innerHTML = `<div class="msg-err">${esc(e.message)}</div>`; }
      }
    };
    $$('.c-tabs button').forEach((b) => { b.onclick = () => show(b.dataset.tab); });
    await show(tabs[0].id);
  }

  // ------------------------------------------------------------- 관제 이벤트 (브라우저 → Monitor)

  function emit(event) {
    if (!state.meta?.monitor_url) return;
    fetch(`${state.meta.monitor_url}/ingest`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ node: 'console', ...event }), // ts 는 Monitor 가 수신 시각으로 채움
    }).catch(() => {});
  }

  // ------------------------------------------------------------- A2A 테스터

  /**
   * 브라우저에서 이 서버의 A2A JSON-RPC 엔드포인트를 직접 호출한다.
   * samples: { skillId: { text, data } }
   */
  async function a2aTester(el, { samples = {}, defaultUser = 'u002' } = {}) {
    const card = await api('/.well-known/agent-card.json');
    const rpcUrl = card.supportedInterfaces[0].url;
    const skillOpts = card.skills.map((s) => `<option value="${esc(s.id)}">${esc(s.id)} - ${esc(s.name)}</option>`).join('');
    el.innerHTML = '';
    el.append(h(`<div class="grid2">
      <div class="card">
        <h3>A2A 호출 (SendStreamingMessage)</h3>
        <div class="stack">
          <div class="row">
            <label>호출 사용자 (Bearer)<select name="user">${userOptions(defaultUser)}</select></label>
            <label>skill (message.metadata.skill)<select name="skill">${skillOpts}<option value="">(지정 안 함)</option></select></label>
          </div>
          <label>이어서 보낼 Task ID (선택 - input_required Task 에 답할 때)<input name="task" placeholder="비우면 새 Task"></label>
          <label>text part<textarea name="text" rows="3"></textarea></label>
          <label>data part (JSON, 선택)<textarea name="data" rows="6" class="code"></textarea></label>
          <div class="row">
            <label class="row" style="flex-direction:row"><input type="checkbox" name="noauth"> 토큰 없이 호출 (401 확인)</label>
            <span class="spacer"></span><button class="primary" name="send">보내기</button>
          </div>
        </div>
        <details style="margin-top:10px"><summary class="small muted">보낸 JSON-RPC 요청</summary><pre name="req"></pre></details>
      </div>
      <div class="card">
        <h3>응답 스트림 <span class="muted small" name="summary"></span></h3>
        <div class="tester-events" name="events"><p class="muted small">왼쪽에서 호출하면 SSE 이벤트가 순서대로 표시됩니다.</p></div>
        <h3 style="margin-top:14px">최종 결과</h3>
        <pre name="final">-</pre>
      </div></div>`));

    const f = (n) => $(`[name=${n}]`, el);
    const applySample = () => {
      const s = samples[f('skill').value] || {};
      f('text').value = s.text || '';
      f('data').value = s.data ? json(s.data) : '';
    };
    f('skill').onchange = applySample;
    applySample();

    f('send').onclick = async () => {
      let data = null;
      if (f('data').value.trim()) {
        try { data = JSON.parse(f('data').value); } catch (e) { toast(`data JSON 오류: ${e.message}`); return; }
      }
      const parts = [];
      if (f('text').value.trim()) parts.push({ text: f('text').value });
      if (data) parts.push({ data, mediaType: 'application/json' });
      const message = { messageId: crypto.randomUUID(), role: 'ROLE_USER', parts };
      if (f('skill').value) message.metadata = { skill: f('skill').value };
      if (f('task').value.trim()) message.taskId = f('task').value.trim();
      const rpc = { jsonrpc: '2.0', id: crypto.randomUUID(), method: 'SendStreamingMessage', params: { message } };
      const trace = traceId();
      const headers = { 'Content-Type': 'application/json', 'A2A-Version': '1.0', 'X-Trace-Id': trace, Accept: 'text/event-stream' };
      if (!f('noauth').checked) headers.Authorization = `Bearer ${token(f('user').value)}`;
      f('req').textContent = `POST ${rpcUrl}\n${Object.entries(headers).map(([k, v]) => `${k}: ${v}`).join('\n')}\n\n${json(rpc)}`;

      const events = f('events');
      events.innerHTML = '';
      f('final').textContent = '…';
      f('summary').textContent = `trace ${trace}`;
      f('send').disabled = true;
      emit({ kind: 'a2a.request', trace_id: trace, from: 'console', to: state.meta.node, skill: f('skill').value, user: f('user').value });
      const started = performance.now();
      const final = { state: '', texts: [], data: [], taskId: '' };
      try {
        const r = await fetch(rpcUrl.replace(/^https?:\/\/[^/]+/, ''), { method: 'POST', headers, body: JSON.stringify(rpc) });
        if (!r.ok) {
          const body = await r.text();
          events.append(h(`<div class="msg-err">HTTP ${r.status} ${esc(body)}</div>`));
          final.state = `http_${r.status}`;
        } else {
          await readSse(r, (msg) => {
            const res = msg.result || {};
            const kind = Object.keys(res)[0] || (msg.error ? 'error' : '?');
            const v = res[kind] || msg.error;
            let label = '';
            if (kind === 'task') { final.taskId = v.id; final.state = v.status?.state; label = `task ${v.id.slice(0, 8)}… · ${v.status?.state}`; }
            if (kind === 'statusUpdate') {
              final.state = v.status?.state;
              const t = (v.status?.message?.parts || []).map((p) => p.text).filter(Boolean).join(' ');
              label = `${v.status?.state}${t ? ` · ${t}` : ''}`;
            }
            if (kind === 'artifactUpdate') {
              for (const p of v.artifact.parts) { if (p.text) final.texts.push(p.text); if (p.data) final.data.push(p.data); }
              label = `artifact '${v.artifact.name}' (${v.artifact.parts.length} parts)`;
            }
            if (kind === 'error') { final.state = 'error'; label = v.message; }
            const cls = kind === 'error' ? 'bad' : kind === 'artifactUpdate' ? 'violet' : 'info';
            events.append(h(`<details class="tester-event"><summary><span class="tag ${cls}">${esc(kind)}</span><span class="small">${esc(label)}</span></summary><pre>${esc(json(msg))}</pre></details>`));
          });
        }
      } catch (e) {
        events.append(h(`<div class="msg-err">${esc(e.message)}</div>`));
        final.state = 'error';
      }
      const ms = Math.round(performance.now() - started);
      emit({ kind: 'a2a.response', trace_id: trace, from: 'console', to: state.meta.node, skill: f('skill').value, state: shortState(final.state), duration_ms: ms });
      f('summary').textContent = `trace ${trace} · ${ms}ms`;
      if (final.taskId && shortState(final.state) === 'input_required') f('task').value = final.taskId;
      f('final').textContent = json({ state: final.state, task_id: final.taskId, text: final.texts.join('\n\n'), data: final.data });
      f('send').disabled = false;
    };
  }

  const shortState = (s) => String(s || '').replace('TASK_STATE_', '').toLowerCase();

  async function readSse(response, onMessage) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    const flush = (chunk) => {
      const data = chunk.split('\n').filter((l) => l.startsWith('data:')).map((l) => l.slice(5).trim()).join('\n');
      if (data) onMessage(JSON.parse(data));
    };
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      // SSE 서버에 따라 줄바꿈이 \r\n 이므로 정규화
      buf = (buf + decoder.decode(value, { stream: true })).replace(/\r\n/g, '\n');
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        flush(buf.slice(0, idx));
        buf = buf.slice(idx + 2);
      }
    }
    if (buf.trim()) flush(buf);
  }

  return { $, $$, esc, h, json, fmtTime, api, post: send('POST'), put: send('PUT'), patch: send('PATCH'), del: (p) => api(p, { method: 'DELETE' }),
    init, a2aTester, toast, userOptions, token, state, emit };
})();
