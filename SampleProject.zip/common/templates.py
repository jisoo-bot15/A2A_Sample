"""규칙/템플릿 기반 응답 생성기 (LLM 대용).

쓰이는 곳
- mock vLLM 서버: 요청의 mock_hint 를 보고 업무에 맞는 응답 '내용'을 만든다 (속도는 서버가 토큰 수로 계산)
- PC 오프라인 / LLM 장애 시 대체 응답

운영 코드에서는 실제 LLM 응답으로 대체되는 부분이다.
"""

import json
import re
from collections import OrderedDict

from common.textsearch import overlap

INTENTS: dict[str, str] = {
    "knowledge": "사내 문서/위키를 근거로 답해야 하는 질문",
    "people": "담당자 또는 사람을 찾는 질문",
    "local_search": "사용자 PC 의 작업 폴더/메모에서 찾는 요청",
    "weekly_report": "이번 주 작업을 정리하거나 주간보고를 올리는 요청",
    "send_request": "다른 담당자에게 무언가를 요청/문의해 달라는 요청",
    "help": "비서가 무엇을 할 수 있는지 묻는 질문",
}


def classify(text: str) -> str:
    t = text.replace(" ", "")
    if "주간" in t and any(k in t for k in ("보고", "정리", "리포트")):
        return "weekly_report"
    if "요청" in t and any(k in t for k in ("에게", "한테", "담당자")):
        return "send_request"
    if any(k in t for k in ("내문서", "내파일", "내메모", "메모에서", "로컬", "작업폴더")):
        return "local_search"
    if any(k in t for k in ("담당자", "누가", "누구")):
        return "people"
    if any(k in t for k in ("도움말", "뭘할수", "무엇을할수", "help")):
        return "help"
    return "knowledge"


def extract_request(text: str, people: list[dict]) -> dict:
    to = next((p for p in people if p.get("name") and p["name"] in text), None)
    topic_m = re.search(r"([0-9A-Za-z가-힣 ]+?)\s*담당자", text)
    body_m = re.search(r"(?:에게|한테)\s*(.+?)\s*(?:을|를)?\s*요청", text)
    body = (body_m.group(1) if body_m else text).strip()
    topic = (topic_m.group(1).strip() if topic_m else "") or body
    return {
        "to_user_id": (to.get("user_id") or to.get("id", "")) if to else "",
        "topic": topic,
        "title": body if len(body) <= 40 else body[:40] + "…",
        "body": body,
    }


def answer_with_docs(question: str, docs: list[dict]) -> str:
    top = docs[0]
    sections = re.split(r"\n(?=## )", top["content"])
    body_sections = [s for s in sections if s.startswith("## ")] or sections
    ranked = sorted(body_sections, key=lambda s: overlap(question, s), reverse=True)[:2]
    out = [f"사내 문서 {len(docs)}건을 확인했습니다. 핵심만 정리해 드릴게요.", ""]
    for sec in ranked:
        lines = [ln.strip() for ln in sec.splitlines() if ln.strip() and not ln.startswith("# ")]
        if lines and lines[0].startswith("## "):
            out.append(f"**{lines[0][3:]}** ({top['title']})")
            lines = lines[1:]
        out += lines[:6]
        out.append("")
    if len(docs) > 1:
        out.append("함께 참고할 문서: " + ", ".join(d["title"] for d in docs[1:]))
    return "\n".join(out).strip()


def weekly_items(activities: list[dict]) -> tuple[list[dict], list[str]]:
    """활동 기록에서 구조화 항목을 뽑는다 (LLM 없이 결정적으로 계산)."""
    items: "OrderedDict[str, dict]" = OrderedDict()
    next_week: list[str] = []
    for a in activities:
        status = a.get("status")
        if status in ("완료", "진행중"):
            items[a["title"]] = {"title": a["title"], "status": status, "project": a.get("project", "")}
        elif status == "예정":
            next_week.append(a["title"])
    return list(items.values()), next_week


def weekly_summary(user_name: str, week_label: str, activities: list[dict]) -> str:
    items, next_week = weekly_items(activities)
    etc: dict[str, int] = {}
    for a in activities:
        if not a.get("status"):
            etc[a["kind"]] = etc.get(a["kind"], 0) + 1

    def section(label: str, rows: list[str]) -> list[str]:
        return [f"■ {label}", *(rows or ["- 없음"]), ""]

    done = [f"- [{i['project']}] {i['title']}" for i in items if i["status"] == "완료"]
    doing = [f"- [{i['project']}] {i['title']}" for i in items if i["status"] == "진행중"]
    others = [f"- {k} {v}건" for k, v in etc.items()]
    return "\n".join(
        [f"{week_label} 주간 업무 정리 - {user_name}", ""]
        + section("완료", done)
        + section("진행중", doing)
        + section("다음 주 계획", [f"- {t}" for t in next_week])
        + section("기타 활동", others)
    ).strip()


def draft_reply(me_name: str, request: dict, context_items: list[dict]) -> str:
    lines = [
        f"안녕하세요 {request['from_name']}님, {me_name}입니다.",
        f"문의하신 '{request['title']}' 관련해서 확인한 내용 공유드립니다.",
        "",
    ]
    if context_items:
        for c in context_items:
            when = f"{c['date']} " if c.get("date") else ""
            detail = f" - {c['detail']}" if c.get("detail") else ""
            lines.append(f"- {when}{c['title']}{detail}")
    else:
        lines.append("- (관련 일정/문서를 찾지 못했습니다. 내용을 직접 작성해 주세요.)")
    lines += ["", "추가로 확인이 필요하시면 말씀해 주세요. 감사합니다."]
    return "\n".join(lines)


def for_hint(task: str, hint: dict) -> str:
    """mock vLLM / 대체 응답: 업무(task)와 입력(hint)으로 LLM 출력 문자열을 만든다."""
    if task == "classify":
        return classify(hint.get("text", ""))
    if task == "extract-request":
        return json.dumps(extract_request(hint.get("text", ""), hint.get("people", [])), ensure_ascii=False)
    if task == "answer":
        return answer_with_docs(hint.get("question", ""), hint.get("docs", []))
    if task == "weekly-summary":
        return weekly_summary(hint.get("user_name", ""), hint.get("week_label", ""), hint.get("activities", []))
    if task == "draft-reply":
        return draft_reply(hint.get("me_name", ""), hint.get("request", {}), hint.get("context_items", []))
    return "(mock) 요청을 처리했습니다."
