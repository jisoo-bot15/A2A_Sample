"""사용자별 이벤트 구독 + SSE 직렬화.

목업은 프로세스 메모리 안에서만 동작한다.
운영 전환 시: 서버 인스턴스가 여러 대이므로 Redis Pub/Sub, Kafka 등으로 교체해야
어느 인스턴스에 연결된 PC 에도 이벤트가 전달된다.
"""

import asyncio
import json
from collections.abc import AsyncIterator
from typing import Any

HEARTBEAT_SECONDS = 15


def sse(event: str, data: Any) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


class EventHub:
    def __init__(self) -> None:
        self._subs: dict[str, set[asyncio.Queue]] = {}

    def publish(self, key: str, event: str, data: Any) -> int:
        queues = self._subs.get(key, set())
        for q in queues:
            q.put_nowait((event, data))
        return len(queues)

    def subscriber_count(self, key: str) -> int:
        return len(self._subs.get(key, set()))

    def subscribers(self) -> dict[str, int]:
        return {k: len(v) for k, v in self._subs.items() if v}

    async def stream(self, key: str, hello: Any = None) -> AsyncIterator[str]:
        """SSE 문자열 스트림. 연결 직후 hello 이벤트, 이후 주기적 heartbeat(comment)."""
        q: asyncio.Queue = asyncio.Queue()
        self._subs.setdefault(key, set()).add(q)
        try:
            yield sse("hello", hello or {})
            while True:
                try:
                    event, data = await asyncio.wait_for(q.get(), timeout=HEARTBEAT_SECONDS)
                    yield sse(event, data)
                except asyncio.TimeoutError:
                    yield ": heartbeat\n\n"
        finally:
            self._subs[key].discard(q)
