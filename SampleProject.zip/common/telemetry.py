"""관제용 이벤트 전송.

각 프로세스는 '무슨 일이 어디서 어디로 일어났는지'만 Monitor 로 보낸다.
- 질문 내용, 문서 본문, 답변 같은 업무 데이터는 보내지 않는다 (메타데이터만).
- 전송 실패는 무시한다. 관제가 죽어도 업무 흐름에는 영향이 없어야 한다.

이벤트 공통 필드
  ts, node(보낸 프로세스), kind, trace_id(사용자 동작 1회 단위), from/to(노드 id), ...

운영 전환 시: OpenTelemetry SDK 로 span 을 만들고 Collector -> Jaeger/Tempo/Grafana 로 보낸다.
trace_id 는 W3C traceparent 헤더로 전파한다.
"""

import asyncio
import time
import uuid
from contextvars import ContextVar
from datetime import datetime

import httpx

from common.config import MONITOR_URL

NODE = "unknown"
_client: httpx.AsyncClient | None = None
_pending: set[asyncio.Task] = set()
# 현재 처리 중인 사용자 동작의 trace (asyncio 태스크별로 분리됨)
_trace: ContextVar[str | None] = ContextVar("trace", default=None)


def configure(node: str) -> None:
    global NODE
    NODE = node


def new_trace_id() -> str:
    return uuid.uuid4().hex[:12]


def set_trace(trace_id: str | None) -> None:
    _trace.set(trace_id)


def get_trace() -> str | None:
    return _trace.get()


def now_ms() -> float:
    return time.perf_counter() * 1000


_anchor: tuple[float, float] | None = None


def _wall_clock() -> float:
    """마이크로초 단위 벽시계.

    Windows 의 time.time() 은 약 15ms 단위로만 바뀌어 같은 시각 이벤트가 많이 생긴다.
    첫 호출 때 시계가 바뀌는 순간을 기준점으로 잡고 이후엔 perf_counter 로 경과 시간을 더한다.
    (같은 PC 의 프로세스끼리 1ms 이내로 순서를 맞추기 위함)
    """
    global _anchor
    if _anchor is None:
        t0 = time.time()
        while (t1 := time.time()) == t0:
            pass
        _anchor = (t1, time.perf_counter())
    wall0, perf0 = _anchor
    return wall0 + (time.perf_counter() - perf0)


def emit(kind: str, **fields) -> None:
    if not MONITOR_URL:
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    fields.setdefault("trace_id", get_trace())
    event = {
        "ts": datetime.fromtimestamp(_wall_clock()).isoformat(timespec="microseconds"),
        "node": NODE,
        "kind": kind,
        **{k: v for k, v in fields.items() if v is not None},
    }
    task = loop.create_task(_send(event))
    _pending.add(task)
    task.add_done_callback(_pending.discard)


async def _send(event: dict) -> None:
    global _client
    if _client is None:
        _client = httpx.AsyncClient(timeout=2.0)
    try:
        await _client.post(f"{MONITOR_URL}/ingest", json=event)
    except Exception:  # noqa: BLE001 - 관제 실패는 무시
        pass
