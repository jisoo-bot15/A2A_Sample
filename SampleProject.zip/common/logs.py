import logging


def setup_logging(tag: str) -> None:
    logging.basicConfig(level=logging.INFO, format=f"%(asctime)s [{tag}] %(levelname)s %(message)s")
    for noisy in ("httpx", "a2a"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
