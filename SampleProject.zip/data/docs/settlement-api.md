---
id: DOC-103
title: 정산 API 개요
url: https://wiki.sample.local/pages/DOC-103
acl: dev
tags: 정산, API, 배치, 가맹점
updated: 2026-08-21
---
# 정산 API 개요

## 주요 API
- GET /settlements/{merchantId}?date= : 가맹점 일 정산 내역 조회
- POST /settlements/reports : 기간별 정산 리포트 생성 요청 (비동기)
- GET /settlements/reports/{reportId} : 리포트 생성 상태/다운로드 URL 조회

## 정산 배치
- 일 정산 배치는 매일 02:00 에 실행되며 전일 승인/취소 건을 집계합니다.
- 배치 지연 시 가맹점 정산 리포트 생성이 지연될 수 있습니다.

## 담당
- 정산 API / 정산 배치: 정산팀
- 정산 정책(정산 주기, 수수료): 서비스기획팀
