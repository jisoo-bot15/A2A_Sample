"""목업 전체 실행: 서버 Agent 4개 + 데스크탑 Agent 2개를 각각 별도 프로세스로 띄운다.

  python scripts/run_all.py              # 전체 실행
  python scripts/run_all.py --no-desktop # 서버만 실행
  python scripts/run_all.py --fast       # 지연 시뮬레이션 끄기 (자동 점검용, MOCK_SPEED=0)
  python scripts/run_all.py --demo       # 자동 시연 반복 재생 (매 바퀴 데이터 초기화)

데스크탑 하나만 따로 띄우기:
  $env:DESKTOP_USER_ID="u003"; python -m uvicorn desktop.main:app --port 8002

종료: Ctrl+C
"""

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)

from common.config import (  # noqa: E402
    DESKTOP_URLS, HUB_URL, KNOWLEDGE_AGENT_URL, MONITOR_URL, PEOPLE_AGENT_URL, REQUEST_BROKER_URL, VLLM_BASE_URL,
    VLLM_ORIGIN, port_of,
)

SERVERS = [
    ("monitor (관제)", "services.monitor.main:app", MONITOR_URL, {}),
    ("vllm (mock)", "services.llm_mock.main:app", VLLM_ORIGIN, {}),
    ("knowledge-agent", "services.knowledge_agent.main:app", KNOWLEDGE_AGENT_URL, {}),
    ("people-agent", "services.people_agent.main:app", PEOPLE_AGENT_URL, {}),
    ("request-broker", "services.request_broker.main:app", REQUEST_BROKER_URL, {}),
    ("hub", "services.hub.main:app", HUB_URL, {}),
]
DESKTOPS = [
    ("desktop-u002 (이서준)", "desktop.main:app", DESKTOP_URLS["u002"], {"DESKTOP_USER_ID": "u002"}),
    ("desktop-u003 (박지아)", "desktop.main:app", DESKTOP_URLS["u003"], {"DESKTOP_USER_ID": "u003"}),
]


def start(name: str, target: str, url: str, extra_env: dict) -> subprocess.Popen:
    env = {**os.environ, **extra_env, "PYTHONIOENCODING": "utf-8"}
    cmd = [sys.executable, "-m", "uvicorn", target, "--host", "127.0.0.1",
           "--port", str(port_of(url)), "--log-level", "warning"]
    print(f"  starting {name:<22} {url}")
    return subprocess.Popen(cmd, cwd=ROOT, env=env)


def wait_ready(url: str, path: str, timeout: float = 20.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            if httpx.get(url + path, timeout=1.0).status_code < 500:
                return True
        except httpx.HTTPError:
            pass
        time.sleep(0.3)
    return False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-desktop", action="store_true")
    parser.add_argument("--fast", action="store_true", help="지연 시뮬레이션 끄기 (MOCK_SPEED=0)")
    parser.add_argument("--demo", action="store_true", help="자동 시연 반복 재생 (scripts/autoplay.py)")
    args = parser.parse_args()
    if args.fast:
        os.environ["MOCK_SPEED"] = "0"
    mock_vllm = VLLM_BASE_URL.startswith(VLLM_ORIGIN) and "127.0.0.1" in VLLM_ORIGIN

    servers: list[subprocess.Popen] = []
    desktops: dict[str, subprocess.Popen] = {}
    procs: list[subprocess.Popen] = []
    try:
        print("[1/2] 운영 서버 Agent")
        for name, target, url, env in SERVERS:
            if target.startswith("services.llm_mock") and not mock_vllm:
                print(f"  skip {name} (VLLM_BASE_URL={VLLM_BASE_URL} 사용)")
                continue
            servers.append(start(name, target, url, env))
            procs.append(servers[-1])
            if not wait_ready(url, "/health"):
                raise SystemExit(f"{name} 기동 실패")

        if not args.no_desktop:
            print("[2/2] 데스크탑 Agent")
            for name, target, url, env in DESKTOPS:
                desktops[name] = start(name, target, url, env)
                procs.append(desktops[name])
                if not wait_ready(url, "/api/me"):
                    raise SystemExit(f"{name} 기동 실패")

        print("\n준비 완료")
        print(f"  관제 화면            : {MONITOR_URL}/")
        print(f"  사내 vLLM 콘솔(mock) : {VLLM_ORIGIN}/   (MOCK_SPEED={os.environ.get('MOCK_SPEED', '1.0')})")
        print(f"  Hub 콘솔             : {HUB_URL}/")
        print(f"  Knowledge 콘솔       : {KNOWLEDGE_AGENT_URL}/")
        print(f"  People 콘솔          : {PEOPLE_AGENT_URL}/")
        print(f"  Request Broker 콘솔  : {REQUEST_BROKER_URL}/")
        if not args.no_desktop:
            for name, _, url, _ in DESKTOPS:
                print(f"  {name:<20}: {url}")
        if args.demo:
            print("\n자동 시연 시작 (scripts/autoplay.py) - 관제 화면과 PC 위젯을 열어 두세요")
            procs.append(subprocess.Popen([sys.executable, str(ROOT / "scripts" / "autoplay.py")], cwd=ROOT,
                                          env={**os.environ, "PYTHONIOENCODING": "utf-8"}))
        print("\n종료하려면 Ctrl+C")
        # 서버가 죽으면 전체 중지. 데스크탑은 꺼져도 서버는 계속 동작한다(PC 오프라인 시나리오).
        while all(p.poll() is None for p in servers):
            for name, p in list(desktops.items()):
                if p.poll() is not None:
                    print(f"  {name} 종료됨 (서버는 계속 실행)")
                    del desktops[name]
            time.sleep(1)
        print("서버 프로세스가 종료되어 전체를 중지합니다.")
    except KeyboardInterrupt:
        print("\n중지 중...")
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()


if __name__ == "__main__":
    main()
