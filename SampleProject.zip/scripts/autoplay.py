"""자동 시연: 데이터를 처음 상태로 되돌린 뒤 시나리오를 반복 재생한다 (데이터가 쌓이지 않음).

  python scripts/autoplay.py              # 무한 반복 (Ctrl+C 로 종료)
  python scripts/autoplay.py --once       # 한 바퀴만
  python scripts/autoplay.py --pause 4    # 단계 사이 쉬는 시간(초), 기본 4
  python scripts/autoplay.py --idle 15    # 한 바퀴 끝난 뒤 쉬는 시간(초), 기본 15

업무 오피스(관제) 화면의 시연 배너에서 [일시정지 / 다시 재생] 할 수 있다 (단계 사이에서 멈춤).
PC 위젯 화면이 열려 있으면 화면에서 직접 입력·클릭하며 진행하고,
닫혀 있으면 백그라운드로 진행한다 (업무 오피스 관제 화면에서는 항상 보임).
python scripts/run_all.py --demo 로 전체 실행과 함께 켤 수도 있다.
"""

import argparse
import sys
import time
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)

from common.config import (  # noqa: E402
    DESKTOP_URLS, KNOWLEDGE_AGENT_URL, MONITOR_URL, PEOPLE_AGENT_URL, REQUEST_BROKER_URL, VLLM_ORIGIN,
)

STEPS = [
    {"user": "u002", "action": "chat", "params": {"text": "결제 장애 발생 시 대응 절차 알려줘"},
     "title": "이서준님이 사내 문서에서 결제 장애 대응 절차를 물어봅니다"},
    {"user": "u002", "action": "chat", "params": {"text": "내 메모에서 정산 배치 개선 내용 찾아줘"},
     "title": "이서준님이 내 PC 메모를 찾습니다 — 메모 내용은 PC 밖으로 나가지 않아요"},
    {"user": "u003", "action": "chat", "params": {"text": "배포 담당자 누구야?"},
     "title": "박지아님이 배포 담당자를 확인합니다"},
    {"user": "u002", "action": "compose",
     "params": {"topic": "배포", "title": "정산 배치 개선분 정기 배포 포함 가능 여부",
                "body": "정산 배치 개선분을 다음주 정기 배포에 포함할 수 있는지 일정 확인 부탁드립니다."},
     "title": "이서준님이 배포 담당자에게 일정 확인을 요청합니다 — 담당자는 업무 키워드로 자동 지정"},
    {"user": "u003", "action": "reply", "params": {},
     "title": "박지아님에게 요청이 도착했어요 — 일정과 메모로 답변 초안을 만들어 보냅니다"},
    {"user": "u002", "action": "weekly", "params": {},
     "title": "이서준님이 이번 주 PC 활동으로 주간보고를 만들어 올립니다"},
    {"user": "u002", "action": "compose",
     "params": {"topic": "PG 연동", "title": "PG사 B 연동 일정 문의",
                "body": "PG사 B 연동 2차 개발 완료 예정일을 알려주세요."},
     "title": "PG 연동 담당 김도윤님은 휴가 중 → 대리 한유진님께, PC 가 꺼져 있어 요청함에 보관됩니다"},
]

http = httpx.Client(timeout=10)


def post(url: str, json: dict | None = None, timeout: float = 10) -> dict:
    try:
        r = http.post(url, json=json or {}, timeout=timeout)
        return r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
    except httpx.HTTPError as e:
        return {"error": f"{e.__class__.__name__}: {e}"}


last_narration: dict = {}


def narrate(kind: str, detail: str, step: int = 0, total: int = 0) -> None:
    last_narration.update(kind=kind, detail=detail, step=step, total=total)
    post(f"{MONITOR_URL}/ingest", {"node": "demo", "kind": kind, "detail": detail, "step": step, "total": total})


def is_paused() -> bool:
    try:
        return bool(http.get(f"{MONITOR_URL}/api/demo", params={"poll": "true"}, timeout=3).json().get("paused"))
    except (httpx.HTTPError, ValueError):
        return False


def gate(resume_hint: str, step: int = 0, total: int = 0) -> None:
    """관제 화면에서 '일시정지'를 누르면 여기서 멈추고, '다시 재생'을 누르면 이어서 진행한다."""
    if not is_paused():
        return
    before = dict(last_narration)
    print("   ❚❚ 일시정지")
    status(False)
    post(f"{MONITOR_URL}/ingest", {"node": "demo", "kind": "demo.paused",
                                   "detail": f"일시정지됨 · '다시 재생'을 누르면 {resume_hint}", "step": step, "total": total})
    while is_paused():
        time.sleep(0.5)
    print("   ▶ 다시 재생")
    if before:
        narrate(**before)


def wait(seconds: float, resume_hint: str, step: int = 0, total: int = 0) -> None:
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        gate(resume_hint, step, total)
        time.sleep(max(0.0, min(0.5, end - time.monotonic())))


def status(on: bool, caption: str = "", only: str | None = None) -> None:
    for uid, url in DESKTOP_URLS.items():
        post(f"{url}/api/demo/status", {"on": on and (only is None or uid == only), "caption": caption if uid == only else ""})


def reset_all() -> None:
    for url in (KNOWLEDGE_AGENT_URL, PEOPLE_AGENT_URL, REQUEST_BROKER_URL):
        post(f"{url}/admin/reset")
    post(f"{VLLM_ORIGIN}/admin/reset")
    post(f"{MONITOR_URL}/api/clear")
    for url in DESKTOP_URLS.values():
        post(f"{url}/api/demo/reset")


def play(pause: float) -> None:
    total = len(STEPS)
    for i, s in enumerate(STEPS, start=1):
        gate(f"{i}/{total}단계부터 이어서 진행합니다", i, total)
        print(f"[{i}/{total}] {s['title']}")
        narrate("demo.step", s["title"], i, total)
        status(True, s["title"], only=s["user"])
        t0 = time.time()
        r = post(f"{DESKTOP_URLS[s['user']]}/api/demo/run",
                 {"action": s["action"], "params": s["params"], "title": s["title"]}, timeout=240)
        print(f"        → {r} ({time.time() - t0:.1f}s)")
        status(False)
        if i < total:
            wait(pause, f"{i + 1}/{total}단계부터 이어서 진행합니다", i + 1, total)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--pause", type=float, default=4.0)
    parser.add_argument("--idle", type=float, default=15.0)
    args = parser.parse_args()
    round_no = 0
    try:
        while True:
            round_no += 1
            gate("처음부터 시연합니다")
            print(f"\n=== 자동 시연 {round_no}회차: 데이터 초기화")
            narrate("demo.idle", "데이터를 처음 상태로 되돌리는 중…")
            reset_all()
            time.sleep(4)  # 위젯 화면이 새로 고쳐지고 수신함에 다시 연결될 시간
            play(args.pause)
            if args.once:
                narrate("demo.idle", "자동 시연이 끝났습니다")
                break
            narrate("demo.idle", f"한 바퀴 끝 · {int(args.idle)}초 뒤 처음부터 다시 시연합니다")
            wait(args.idle, "처음부터 다시 시연합니다")
    except KeyboardInterrupt:
        narrate("demo.idle", "자동 시연을 멈췄습니다")
        status(False)


if __name__ == "__main__":
    main()
