"""시나리오 E2E 점검 - 데스크탑 Agent 의 로컬 API 를 통해 전체 흐름을 실행한다.

사전 조건: python scripts/run_all.py 로 전체가 떠 있어야 한다.
  python scripts/demo.py

실행하면서 관제 화면(http://127.0.0.1:9900)을 띄워두면 흐름이 실시간으로 보인다.

데스크탑 A: 이서준(u002, 정산팀)  http://127.0.0.1:8001
데스크탑 B: 박지아(u003, 플랫폼팀) http://127.0.0.1:8002
"""

import sys
import time
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.stdout.reconfigure(encoding="utf-8")

from common.auth import auth_headers, issue_dev_token  # noqa: E402
from common.config import HUB_URL, MONITOR_URL  # noqa: E402

A = httpx.Client(base_url="http://127.0.0.1:8001", timeout=60)
B = httpx.Client(base_url="http://127.0.0.1:8002", timeout=60)
results: list[tuple[str, bool, str]] = []


def step(title: str):
    def deco(fn):
        print(f"\n=== {title}")
        try:
            note = fn() or ""
            results.append((title, True, note))
            print(f"  -> PASS {note}")
        except Exception as e:  # noqa: BLE001
            results.append((title, False, f"{e.__class__.__name__}: {e}"))
            print(f"  -> FAIL {e.__class__.__name__}: {e}")
        return fn
    return deco


def chat(client: httpx.Client, text: str) -> dict:
    print(f"  [{client.base_url.port}] > {text}")
    r = client.post("/api/chat", json={"text": text})
    r.raise_for_status()
    body = r.json()
    print(f"  intent={body.get('intent')} route={body.get('route')}")
    for line in (body.get("text") or "").splitlines()[:6]:
        print(f"    | {line}")
    return body


def wait_until(fn, timeout: float = 10.0, interval: float = 0.3):
    deadline = time.time() + timeout
    while time.time() < deadline:
        value = fn()
        if value:
            return value
        time.sleep(interval)
    return None


@step("1. 서버 문서 기반 질의응답 (출처 + 관련 담당자)")
def _():
    body = chat(A, "결제 장애 발생 시 대응 절차 알려줘")
    ids = [c["doc_id"] for c in body["citations"]]
    assert body["route"] == "server" and "DOC-101" in ids, f"citations={ids}"
    people = [p["name"] for p in body["related_people"]]
    assert "김도윤" in people, f"related_people={people}"
    return f"출처={ids}, 관련 담당자={people}, 진행={body['progress']}"


@step("2. 권한(ACL) 필터링 - 보안팀 전용 문서는 정산팀 사용자에게 제외")
def _():
    body = chat(A, "보안 점검 기준 알려줘")
    ids = [c["doc_id"] for c in body["citations"]]
    assert "DOC-105" not in ids, f"보안팀 전용 문서 노출: {ids}"
    assert body["hidden_count"] >= 1 and "열람 권한이 없는 문서" in body["text"], "제외 안내 없음"
    return f"출처={ids}, 권한 밖 제외={body['hidden_count']}건"


@step("3. 로컬 우선 처리 - 내 작업 폴더 검색 (서버 전송 없음)")
def _():
    body = chat(A, "내 메모에서 정산 배치 개선 내용 찾아줘")
    files = [s["file"] for s in body.get("sources", [])]
    assert body["route"] == "local" and any("정산배치" in f for f in files), f"sources={files}"
    return f"sources={files}"


@step("4. 주간보고 - 초안(로컬) -> 사용자 승인 -> 업로드 -> 담당자 현재 작업 갱신")
def _():
    draft = A.post("/api/weekly/draft").json()
    print("    | " + "\n    | ".join(draft["summary"].splitlines()[:8]))
    assert draft["source_count"] > 0 and draft["items"], "초안 항목 없음"
    receipt = A.post("/api/weekly/submit", json={k: draft[k] for k in ("week", "summary", "items", "next_week")}).json()
    assert receipt["state"] == "completed", receipt
    body = chat(B, "정산 배치 담당자 누구야?")
    seojun = next(m for m in body["matches"] if m["name"] == "이서준")
    assert any("쿼리 튜닝" in w for w in seojun["current_work"]), seojun["current_work"]
    return f"{receipt['report_id']} / 갱신된 현재 작업={seojun['current_work']}"


@step("5. 담당자 요청 - A 요청 -> 담당자 자동 지정 -> B 실시간 수신 -> 답변 초안 -> 승인 전송 -> A 수신")
def _():
    body = chat(A, "배포 담당자에게 정산 배치 개선분을 다음주 정기 배포에 포함할 수 있는지 일정 확인 요청해줘")
    assert body["intent"] == "send_request", body["intent"]
    draft = body["draft"]
    print(f"    draft={draft}")
    created = A.post("/api/requests", json=draft).json()
    assert created["state"] == "completed", created
    req = created["request"]
    rid = req["request_id"]
    assert req["to_user"]["name"] == "박지아", req["to_user"]
    print(f"    요청 생성: {rid} -> {req['to_user']['name']} ({req['routed_reason']})")

    received = wait_until(lambda: next(
        (r for r in B.get("/api/inbox").json()["received"] if r["request_id"] == rid), None))
    assert received, "B 수신함에 요청이 도착하지 않음"

    reply_draft = B.post(f"/api/requests/{rid}/draft").json()
    print("    [B 답변 초안]\n    | " + "\n    | ".join(reply_draft["text"].splitlines()))
    assert reply_draft["context_items"], "답변 근거(일정/문서) 없음"

    sent = B.post(f"/api/requests/{rid}/reply", json={"text": reply_draft["text"]}).json()
    assert sent["state"] == "completed", sent

    answered = wait_until(lambda: next(
        (r for r in A.get("/api/inbox").json()["sent"]
         if r["request_id"] == rid and r["status"] == "answered"), None))
    assert answered, "A 에게 답변 도착 이벤트가 반영되지 않음"
    return f"request={rid} status={answered['status']}"


@step("6. 부재 시 대리 담당자 라우팅 + 오프라인 사용자 수신함 보관")
def _():
    created = A.post("/api/requests", json={
        "topic": "PG 연동", "title": "PG사 B 연동 일정 문의",
        "body": "PG사 B 연동 2차 개발 완료 예정일을 알려주세요.",
    }).json()
    req = created["request"]
    assert req["to_user"]["user_id"] == "u006", req["to_user"]
    # 한유진(u006)은 데스크탑을 켜지 않은 상태 -> 서버 수신함에 보관되어 있어야 함
    token = issue_dev_token("u006")
    inbox = httpx.get(f"{HUB_URL}/api/inbox", headers=auth_headers(token)).json()
    assert any(r["request_id"] == req["request_id"] and r["status"] == "waiting" for r in inbox["received"])
    return f"to={req['to_user']['name']} / {req['routed_reason']}"


@step("7. 담당자가 아닌 사용자의 답변 시도는 거부 (요청은 계속 열려 있음)")
def _():
    rid = next(r for r in A.get("/api/inbox").json()["sent"] if r["status"] == "waiting")["request_id"]
    token = issue_dev_token("u003")  # 박지아는 이 요청(u006 담당)의 담당자가 아님
    from common.a2a_kit import A2AConnector
    import asyncio

    async def attempt():
        c = A2AConnector()
        try:
            return await c.send(HUB_URL, skill="request-reply", token=token, text="제가 대신 답변합니다",
                                data={"request_id": rid})
        finally:
            await c.aclose()

    r = asyncio.run(attempt())
    assert r.state == "failed" and "담당자만" in r.status_text, (r.state, r.status_text)
    inbox = httpx.get(f"{HUB_URL}/api/inbox", headers=auth_headers(issue_dev_token("u006"))).json()
    assert any(x["request_id"] == rid and x["status"] == "waiting" for x in inbox["received"])
    return r.status_text


@step("8. 인증 없는 A2A 호출 차단")
def _():
    r = httpx.post(f"{HUB_URL}/a2a", json={"jsonrpc": "2.0", "id": 1, "method": "SendMessage", "params": {}})
    assert r.status_code == 401, r.status_code
    card = httpx.get(f"{HUB_URL}/.well-known/agent-card.json")
    assert card.status_code == 200
    return "JSON-RPC 401 / Agent Card 공개"


@step("9. 관제 - 요청 1건의 trace 가 PC → Hub → People/Broker → 상대 PC 까지 이어짐")
def _():
    created = A.post("/api/requests", json={"topic": "배포", "title": "관제 확인용 요청", "body": "trace 확인"}).json()
    trace = created["trace_id"]

    def collected():
        evs = httpx.get(f"{MONITOR_URL}/api/events", params={"trace_id": trace}).json()
        kinds = {e["kind"] for e in evs}
        return evs if {"a2a.request", "skill.start", "inbox.publish", "inbox.received", "user.approve"} <= kinds else None

    evs = wait_until(collected, timeout=5)
    assert evs, "관제 이벤트가 모이지 않음"
    nodes = sorted({e["node"] for e in evs})
    assert {"desktop:u002", "hub", "people", "broker", "desktop:u003"} <= set(nodes), nodes
    return f"trace {trace}: 이벤트 {len(evs)}개, 노드 {nodes}"


@step("10. 오프라인 시뮬레이션 - B 오프라인 중 요청 → 복귀 시 자동 동기화")
def _():
    B.post("/api/offline", json={"offline": True})
    try:
        assert B.get("/api/me").json()["offline"] is True
        created = A.post("/api/requests", json={"topic": "배포", "title": "오프라인 중 요청", "body": "복귀 후 보여야 함"}).json()
        rid = created["request"]["request_id"]
        assert not created["delivered_realtime"], "오프라인인데 실시간 전달됨"
        assert B.post("/api/chat", json={"text": "결제 장애 대응 절차 알려줘"}).json()["route"] == "local"
    finally:
        B.post("/api/offline", json={"offline": False})
    synced = wait_until(lambda: any(r["request_id"] == rid for r in B.get("/api/inbox").json()["received"]))
    assert synced, "복귀 후 동기화 안 됨"
    return f"request={rid} 복귀 후 수신함 반영"


@step("11. 운영 콘솔 조작 - People 에서 담당자 부재 처리 → Hub 라우팅이 대리 담당자로 변경")
def _():
    people = "http://127.0.0.1:9102"
    httpx.patch(f"{people}/admin/people/u003", json={"status": "away", "status_note": "교육", "backup": "u004"}).raise_for_status()
    try:
        created = A.post("/api/requests", json={"topic": "배포", "title": "부재 라우팅 확인", "body": "대리 담당자 확인"}).json()
        to = created["request"]["to_user"]
        assert to["user_id"] == "u004", to
    finally:
        httpx.patch(f"{people}/admin/people/u003", json={"status": "available", "status_note": "", "backup": ""})
    return f"박지아 부재 → {to['name']}에게 전달 (원복 완료)"


print("\n" + "=" * 60)
for title, ok, _ in results:
    print(f"{'PASS' if ok else 'FAIL'}  {title}")
failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)}/{len(results)} passed")
sys.exit(1 if failed else 0)
