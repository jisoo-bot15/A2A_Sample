# 개인 비서 Agent + 운영 Hub (A2A) + 사내 vLLM 목업

PC에 설치하는 **개인 비서 Agent**가 운영 서버의 **Hub Agent**와 A2A 프로토콜로 통신하고, 글을 이해하고 쓰는 일은 **사내 vLLM**을 직접 사용하는 구조를 로컬에서 띄워 검증하는 목업입니다.
공식 [`a2a-sdk`](https://pypi.org/project/a2a-sdk/) 1.x(A2A 프로토콜 v1.0)와 OpenAI 호환 API(vLLM)를 사용합니다. 그래서 운영 코드로 옮길 때도 서버/클라이언트 골격을 그대로 참고할 수 있습니다.

PC Agent가 하는 일은 세 가지로 나뉩니다.

| 구분 | 예 | 데이터가 가는 곳 |
|---|---|---|
| **PC 로컬** | 작업 폴더 검색, 활동 기록/일정 수집 | PC 밖으로 나가지 않음 |
| **PC 데이터 + 사내 LLM** | 의도 분류, 요청 내용 정리, 주간보고 초안, 답변 초안 | 사내 vLLM (사내망) |
| **서버 위임 (A2A)** | 사내 문서 질의, 담당자 조회, 주간보고 업로드, 담당자 요청/답변 | Hub → 하위 Agent |

화면은 세 종류입니다.

- **PC 앱 화면**: 사용자가 쓰는 개인 비서 화면
- **서버별 운영 콘솔**: 각 서버(사내 vLLM 포함)의 데이터를 보고 조작하고, 직접 호출해 보는 화면
- **관제 화면**: 전체 노드 사이의 호출과 이벤트를 실시간으로 보는 화면

---

## 1. 구성

```
                              ┌──────────── 관제 Monitor :9900 ────────────┐
                              │ 흐름도 · 이벤트 로그 · trace 시퀀스 · 요청 현황 │
                              └──────▲───────────────▲───────────────▲─────┘
                                     │ 동작 이벤트(메타데이터만, 모든 프로세스가 전송)
┌─ PC 이서준 :8001 ───────┐   ┌─ PC 박지아 :8002 ───────┐
│ 화면 ─ Personal Agent   │   │ (동일 구성)             │
│        └ 로컬 도구       │   └───┬──────────┬──────────┘
└──┬───────────────┬──────┘       │          │
   │ A2A + 수신함 SSE │ OpenAI 호환 API (stream)  │
   ▼               └──────────────┼──────────┼──────────┐
┌─ 운영 서버 ──────────────────────┼──────────┘          ▼
│ Hub :9000  (A2A Gateway + Orchestrator)       ┌─ 사내 vLLM :8800 (mock) ─┐
│        │ A2A (사용자 토큰 전달 = 권한 위임)        │ /v1/chat/completions     │
│   ┌────┴──────────┬───────────────┐           │ 토큰 수 기반 응답 시간     │
│   ▼               ▼               ▼           │ 토큰 스트리밍             │
│ Knowledge :9101  People :9102   Broker :9103   └──────────▲──────────────┘
│  문서 검색+ACL ────────────────────────────────── 답변 생성 ┘
└────────────────────────────────────────────────────────────────────────
```

| 프로세스 | 주소 (화면) | 역할 |
|---|---|---|
| 관제 Monitor | http://127.0.0.1:9900 | 모든 프로세스의 동작 이벤트를 모아 실시간 표시 |
| 사내 vLLM (mock) | http://127.0.0.1:8800 | OpenAI 호환 API. 토큰 수에 따라 응답 시간이 달라지고 토큰을 스트리밍 |
| Hub | http://127.0.0.1:9000 | PC가 접속하는 서버 진입점. 하위 Agent 위임, 수신함 프록시 |
| Knowledge Agent | http://127.0.0.1:9101 | 사내 문서 검색, 사용자 권한(ACL) 필터, 사내 vLLM으로 근거 기반 답변 |
| People Agent | http://127.0.0.1:9102 | 담당자 업무/현재 작업/부재·대리 담당자, 주간보고 접수 |
| Request Broker | http://127.0.0.1:9103 | 담당자 간 요청을 A2A Task로 관리, 수신함 이벤트 발행 |
| PC 이서준 (u002) | http://127.0.0.1:8001 | 정산팀 PC (주로 요청을 보내는 쪽) |
| PC 박지아 (u003) | http://127.0.0.1:8002 | 플랫폼팀 배포 담당 PC (주로 요청을 받는 쪽) |

모든 화면 상단에 다른 화면으로 가는 링크가 있습니다.

## 2. 빠른 시작

Python 3.12 기준입니다.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

python scripts/run_all.py          # 관제 + mock vLLM + 서버 4개 + PC 2대 (현실 속도, Ctrl+C 로 종료)
python scripts/run_all.py --fast   # 지연 없이 실행 (자동 점검용)
```

**관제 화면(:9900)을 먼저 띄워 두고** 다른 터미널에서 시나리오 점검을 실행하면, 흐름이 실시간으로 지나가는 것을 볼 수 있습니다.

```powershell
python scripts/demo.py             # 11개 시나리오 E2E 점검, 전부 PASS 여야 정상
```

- `demo.py`는 현실 속도에서 LLM 호출이 많아 1~2분 걸립니다. 빠르게 확인하려면 `--fast`로 띄운 상태에서 실행하세요.
- `demo.py`는 서버 메모리에 요청과 주간보고를 남깁니다. 처음부터 시연하려면 `run_all.py`를 재시작하세요.
- 데스크탑 하나만 끄거나 켜도 서버는 계속 동작합니다. 단독 실행은 `$env:DESKTOP_USER_ID="u003"; python -m uvicorn desktop.main:app --port 8002`입니다.

### 자동 시연 (틀어 두기)

```powershell
python scripts/run_all.py --demo         # 전체 실행 + 자동 시연 반복 재생
python scripts/autoplay.py               # (이미 실행 중일 때) 자동 시연만 켜기 · --once 한 바퀴 · --pause 4 · --idle 15
```

- **데이터가 쌓이지 않습니다.** 매 바퀴 시작 시 문서, 담당자, 요청, 주간보고, vLLM 통계, 관제 기록, PC 로컬 데이터를 모두 처음 상태로 되돌립니다(각 서버 `/admin/reset`, PC `/api/demo/reset`).
- 한 바퀴는 7단계(약 1분 30초)입니다: 사내 문서 질문 → 내 메모 찾기 → 담당자 확인 → 배포 담당자에게 요청 → 박지아 답변(초안·전송) → 주간보고 → 휴가 중 담당자에게 요청(대리 담당자, 요청함 보관). 끝나면 15초 쉬고 다시 시작합니다.
- **PC 위젯 화면이 보이게 열려 있으면 화면에서 직접 입력·클릭하며 진행합니다**(상단 "자동 시연" 표시와 해설 자막).
  - 창이 가려져 있거나 닫혀 있으면 PC 에이전트가 백그라운드로 진행합니다.
  - 관제 화면은 상단 **AUTO DEMO 배너**에 단계 설명과 진행 점을 보여줍니다.
- **멈추기/이어 보기**: 업무 오피스 화면의 시연 배너 오른쪽 **[❚❚ 시연 일시정지]** 버튼을 누릅니다. 진행 중이던 단계가 끝난 뒤 멈추고, **[▶ 다시 재생]** 을 누르면 다음 단계부터 이어서 진행합니다. 일시정지 상태는 관제 서버가 기억하므로 화면을 새로 열어도 유지됩니다(`GET/POST /api/demo`). 상단의 **[기록 멈춤]** 은 화면 갱신만 멈추는 별개 버튼입니다.
- 시연 자체를 끄려면 `autoplay.py` 프로세스를 종료합니다(직접 실행했다면 Ctrl+C).
- 권장 배치: 업무 오피스(관제)와 두 위젯을 **각각 별도 창**으로 나란히 띄웁니다. 같은 창의 탭이면 앞에 보이는 탭만 화면 시연을 하고, 나머지는 백그라운드로 진행합니다.

## 3. 처리 시간 (현실 속도, `MOCK_SPEED=1`)

모든 프로세스가 한 PC에 있어 그대로 두면 수 ms 만에 끝나므로, 작업 규모에 맞는 지연을 넣었습니다.

**LLM** (mock vLLM이 계산)
- 응답 시간 = 대기 + 입력 토큰 ÷ prefill 속도(2,500 tok/s) + 출력 토큰 ÷ 생성 속도(45 tok/s)
- 동시 요청이 많으면 생성 속도가 떨어집니다(1건당 15%).
- 토큰은 생성되는 대로 스트리밍됩니다.

**그 외** (`common/simulate.py`)

| 작업 | 지연 |
|---|---|
| PC → 서버 | 25~70ms |
| 서버 ↔ 서버 | 2~8ms |
| 문서 임베딩 검색 | 180~450ms |
| 담당자 조회 | 40~110ms |
| DB 저장 | 20~60ms |
| PC 로컬 파일 스캔 | 80~220ms × 파일 수 |

측정 예:

| 작업 | 단계 | 총 시간 | 첫 글자 |
|---|---|---|---|
| 내 메모 검색 | 의도 분류(LLM) → 작업 폴더 검색(PC) | 약 1초 | - |
| 담당자 조회 | 의도 분류 → Hub → People | 약 0.7초 | - |
| 사내 문서 질의 | 의도 분류 → Hub → Knowledge(검색 → LLM 답변) ∥ People | 약 7~8초 | 약 1.4초 |
| 주간보고 초안 | 활동 기록 수집(PC) → LLM 초안 | 약 5~6초 | 약 0.7초 |
| 답변 초안 | 일정·문서 확인(PC) → LLM 초안 | 약 9~10초 | 약 0.9초 |
| 요청 보내기 | Hub → People → Broker → 상대 PC | 약 0.4초 | - |

**속도 조절**
- 전체 배율: `MOCK_SPEED` (1 = 현실 속도, 2 = 2배 빠르게, 0 = 지연 없음)
- LLM 성능: `MOCK_LLM_PREFILL_TPS`, `MOCK_LLM_DECODE_TPS`
- **사내 vLLM 콘솔(:8800)에서 실행 중에 바꿀 수 있습니다.**

## 4. 화면 안내

### 4.1 PC 업무 비서 위젯 (8001 / 8002)

실제 설치하면 **데스크탑 한쪽에 띄워 두는 위젯**(폭 약 430px)을 가정한 화면입니다. 브라우저에서는 가운데에 위젯 미리보기로 보입니다.

| 탭 | 내용 |
|---|---|
| **홈** (처음 화면) | 인사말, **한눈에 보기**(답할 요청 · 답변 기다리는 중 · 이번 주 활동), 질문 입력 버튼, **바로가기 6개**(사내 문서 물어보기, 담당자 찾기, 내 메모 찾기, 주간보고 쓰기, 담당자에게 요청하기, 도움말), **최근 소식**(답할 요청 · 도착한 답변 · 기다리는 요청 · 최근 대화) |
| **대화** | 대화에만 집중하는 화면. 비어 있을 때만 추천 질문을 보여주고, 대화 중에는 **입력창 왼쪽 [+]** 로 바로가기 메뉴를 엽니다 (질문 예시는 입력창에 채워져 고쳐 쓸 수 있음) |
| **요청함** | 받은 요청/보낸 요청 목록(읽지 않은 요청 강조, 상대·시간·상태). 누르면 상세 화면: 요청 내용 → **답변 초안 만들기**(내 일정·메모 + 사내 AI) 또는 직접 쓰기 → 확인 문구와 함께 **보내기**. "새 요청" 화면 |
| **주간보고** | 이번 주 활동 요약(완료/진행 중/예정) → 초안 만들기(생성되는 대로 표시) → 수정 → 팀에 공유될 항목 확인 → **확인했어요, 올리기** → 완료 화면 |
| **내 PC** | **오프라인 모드** 스위치, **PC 밖으로 보낸 기록**(무슨 일로 어디에 보냈는지만), 작업 폴더·일정·활동 기록 보기/추가 |

- **작업 중 표시**
  - "질문을 이해하고 있어요 · 사내 AI", "사내 문서를 찾아 답변을 쓰고 있어요 · 운영 서버"처럼 일상 언어로 보여줍니다.
  - 각 단계의 위치(내 PC / 사내 AI / 운영 서버)를 아이콘으로 구분하고, 경과 시간과 생성 중인 글을 함께 보여줍니다.
- **답변 아래 표시**
  - 처리 위치 배지: **내 PC에서만 처리** / **내 PC + 사내 AI** / **운영 서버 연결**
  - 참고한 문서, 담당자(부재 시 대리 담당자)
  - 접어 둔 **"어떻게 처리했나요?"**: 단계별 시간과 "업무 오피스에서 흐름 보기" 링크
- **알림**: 새 요청이나 답변이 오면 위젯 위에 알림이 뜹니다. 누르면 해당 요청으로 바로 이동합니다.
### 4.2 서버 운영 콘솔 (각 서버 주소의 `/`)

A2A 서버 콘솔에는 공통으로 **A2A 호출 테스트** 탭이 있습니다.
- 사용자(토큰)와 skill을 골라 브라우저에서 JSON-RPC(`SendStreamingMessage`)를 직접 호출합니다.
- 보낸 요청 원문과 SSE 응답 이벤트(task / statusUpdate / artifactUpdate)를 순서대로 보여줍니다.

| 콘솔 | 조작 |
|---|---|
| 사내 vLLM :8800 | **성능 설정 실시간 변경**(속도 배율, prefill/생성 속도, 동시요청 저하율), 실행 중 요청 수, 요청별 입력/출력 토큰·첫 토큰·총 시간·생성 속도, **플레이그라운드**(스트리밍 확인) |
| Hub :9000 | 하위 Agent 레지스트리(상태/skill), PC 수신함 연결 현황, 사용 중인 LLM |
| Knowledge :9101 | 문서 목록/보기/**추가·수정·삭제**(ACL 그룹 지정), **검색/권한 테스트** |
| People :9102 | 담당자 **부재/대리 담당자/담당 업무/현재 작업 편집**(Hub 라우팅에 즉시 반영), 주간보고 목록, **담당자 지정 미리보기** |
| Request Broker :9103 | 요청 현황 + 요청별 **A2A Task 상태/이력**, **리마인드 보내기**, 수신함 연결 현황, **공지 이벤트 보내기** |

### 4.3 업무 오피스 (관제, :9900)

운영 서버 Agent는 **방**으로, 직원 PC는 **책상**으로 그린 평면도입니다. 누가 누구에게 무슨 일을 맡겼는지가 사무실처럼 보입니다.

| 자리 | 해당 구성 |
|---|---|
| 안내 데스크 (로비) | Hub · 오케스트레이터 |
| 자료실 | Knowledge Agent |
| 인사 데스크 | People Agent |
| 요청 우편실 | Request Broker |
| AI 작문실 | 사내 vLLM (생성 중이면 서버 랙 표시등이 깜빡임) |
| 업무층 책상 6개 | 직원 PC (부재자는 "부재" 표지, PC 미실행은 꺼진 모니터) |

| 영역 | 내용 |
|---|---|
| 평면도 | 상태 테두리(초록 일하는 중 · 주황 대기 · 빨강 최근 실패 · 회색 꺼짐/부재). **봉투(요청)·문서(결과)·불꽃(사내 AI)·보라 봉투(요청함 알림)가 복도를 따라 이동**. 자리 위 말풍선에 "자료실에 사내 문서 질의 맡김 · 2.7초" 같은 진행 문장 |
| 지표 | 가동, 진행 중, 처리 완료, 실패·대체, AI 생성 토큰, 평균 응답 |
| 구성원 | 운영 서버 5곳 + 직원 6명의 현재 상태 문장, 경과 시간, 평균 대비 진행 막대 |
| 사무실 소식 | "이서준님이 안내 데스크에 사내 문서 질의를 요청" 같은 문장. 누르면 그 일의 흐름으로 이동 |
| **방 세부 패널** | 방(또는 구성원)을 누르면 열림. 지금 처리 중인 일(요청자, 경과 시간, 진행 단계, 맡긴 하위 호출과 상태), 현재 상태(대기 요청, 부재자, 문서 현황, AI 생성 현황), 최근 처리, 업무별 통계 |
| 아래 탭 | **업무 흐름 상세**(순서도), **담당자 요청 현황**, **원본 로그(개발자)** |
## 5. 해볼 시나리오

| # | 어디서 | 입력 / 동작 | 확인할 점 |
|---|---|---|---|
| 1 | 이서준 PC | `결제 장애 발생 시 대응 절차 알려줘` | 의도 분류(사내 LLM) → Hub → Knowledge 검색 → **답변이 생성되며 실시간 표시**. 관제에서 Knowledge·vLLM이 "처리 중"이고, **Hub 노드를 클릭**하면 Knowledge(진행 중)/People(완료) 하위 호출과 진행 메시지가 실시간으로 보임 |
| 2 | 이서준 PC | `내 메모에서 정산 배치 개선 내용 찾아줘` | 의도 분류만 사내 LLM, 문서 검색은 PC 안에서 처리 (약 1초) |
| 3 | 이서준 PC | 주간보고 초안 → 수정 → **승인 후 업로드** | 초안이 스트리밍으로 작성됨. People 콘솔에서 현재 작업 갱신 확인 |
| 4 | 이서준 PC | `배포 담당자에게 정산 배치 개선분을 다음주 정기 배포에 포함할 수 있는지 일정 확인 요청해줘` → 요청 보내기 | 요청 내용 정리(사내 LLM) → 박지아 자동 지정 |
| 5 | 박지아 PC | 알림 → **답변 초안 만들기** → **승인 후 전송** | 내 일정 기반 초안이 스트리밍으로 작성됨. 이서준 PC "답변 도착" |
| 6 | 사내 vLLM 콘솔 | 생성 속도를 15로 낮추고 1을 다시 실행 / 두 PC에서 동시에 질문 | 응답이 느려지고, 동시 요청 시 생성 속도 저하 |
| 7 | 박지아 PC | 내 PC → **오프라인 시뮬레이션** 후 이서준이 요청 → 다시 온라인 | 오프라인 중엔 보관, 복귀 시 자동 동기화. 오프라인에서 초안은 템플릿으로 즉시 작성 |
| 8 | People 콘솔 | 박지아를 **부재**로 바꾸고 대리 담당자 지정 → 이서준이 배포 요청 | 대리 담당자에게 전달됨 |
| 9 | Broker 콘솔 | **리마인드 보내기** / **공지 보내기** | 해당 PC에 토스트 표시 |

## 6. 폴더 구조

```
common/                    공통 모듈 (운영 코드로 옮길 때 재사용 대상)
  a2a_kit.py               A2A 서버/클라이언트 키트 (Agent Card, skill 라우팅, 인증 가드, 호출기, artifact 스트리밍, 콘솔 마운트)
  llm.py                   LLM 클라이언트 (VLLMClient: OpenAI 호환 스트리밍 / ClaudeLLM / TemplateLLM)
  templates.py             규칙/템플릿 응답 (mock vLLM 내용 생성, 오프라인 대체)
  simulate.py              목업 지연 시뮬레이션 (운영 코드에는 불필요)
  telemetry.py             관제 이벤트 전송 (메타데이터만, trace 전파)
  auth.py                  목업 SSO (dev-token-<user_id>) → 운영: OIDC JWT 검증
  events.py                사용자별 이벤트 구독 + SSE
  textsearch.py            목업 검색(문자 bigram) → 운영: 벡터 검색
  config.py, logs.py
  console_static/          서버 콘솔/관제 공용 CSS·JS (내비게이션, 탭, A2A 호출 테스터)
services/
  llm_mock/                mock 사내 vLLM (/v1/chat/completions, /v1/models, /health, /metrics) + 콘솔
  hub/                     main.py(진입점/REST 확장/관리 API) orchestrator.py(위임) registry.py(레지스트리) console.html
  knowledge_agent/         문서 저장소 + knowledge-search(LLM 답변 스트리밍) + 문서 관리 API + console.html
  people_agent/            담당자 저장소 + people-lookup / weekly-report-submit + 담당자 관리 API + console.html
  request_broker/          요청 저장소 + request-create / request-reply + 수신함 SSE + 관리 API + console.html
  monitor/                 관제 서비스 (이벤트 수집/SSE/헬스체크) + static/(관제 화면)
desktop/
  main.py                  데스크탑 App 백엔드 (로컬 API, 작업별 진행 스트리밍 SSE, 오프라인 제어, 로컬 데이터 API)
  agent.py                 개인 비서 Agent (단계별 진행 표시, 사내 vLLM 직접 호출, Hub 위임, 승인 흐름, trace 생성)
  hub_client.py            Hub 접속 (A2A + REST) + PC 밖으로 나간 기록, 오프라인 차단
  inbox_listener.py        수신함 SSE 구독, 재연결, 재동기화
  local_tools.py           로컬 도구 (작업 폴더/일정/활동) - 운영: 로컬 MCP 서버로 분리
  static/                  화면 (HTML/JS/CSS)
  profiles/<user_id>/      PC별 더미 데이터 (workspace, calendar.json, activity.json)
data/
  users.json               담당자 더미 데이터 (6명)
  docs/*.md                사내 문서 더미 데이터 (front matter 에 acl 지정)
scripts/
  run_all.py               전체 실행 (--fast, --no-desktop)
  demo.py                  E2E 시나리오 점검 (11개)
```

## 7. 설계 요약

### 7.1 Hub skill (PC에서 호출)

| skill | 입력 | 결과 | 위임 대상 |
|---|---|---|---|
| `knowledge-search` | text | 답변 text(**스트리밍**) + `citations`, `hidden_count`, `related_people` | Knowledge + People (병렬) |
| `people-lookup` | text 또는 data `{user_id \| name \| topic \| all}` | `matches[]` | People |
| `weekly-report-submit` | data `{week, summary, items[], next_week[]}` | 접수번호, 갱신된 현재 작업 | People |
| `request-create` | data `{to_user_id?, topic, title, body, due}` | `request`, `delivered_realtime` | People(담당자 결정) → Broker |
| `request-reply` | text + data `{request_id}` | 완료된 `request` | Broker |

**skill 지정 규칙**: A2A 표준 메시지에는 "어떤 skill을 호출하는지"를 나타내는 필드가 없습니다. 그래서 이 프로젝트는 `Message.metadata.skill`에 skill id를 넣습니다. 이 값이 없으면 Hub가 LLM으로 의도를 분류해 skill을 정합니다.

**답변 스트리밍**
- Knowledge Agent는 vLLM 토큰을 받는 대로 A2A `TaskArtifactUpdateEvent(append=true)`로 내보냅니다.
- Hub는 이 조각을 그대로 자기 Task의 artifact로 다시 내보내고, PC는 이를 화면에 바로 그립니다.
- 출처 같은 구조화 데이터는 별도 artifact(`*-meta`)로 마지막에 보냅니다.

### 7.2 사내 vLLM 사용

- PC Agent와 Knowledge Agent(그리고 skill 없는 요청을 분류하는 Hub)가 `common/llm.py`의 `VLLMClient`로 **사내 vLLM을 직접** 호출합니다.
  - 형식은 OpenAI 호환 `/v1/chat/completions`이며 `stream=true`로 받습니다.
  - JSON이 필요한 작업(요청 추출)은 `response_format: json_object`를 씁니다.
- **실제 사내 vLLM으로 바꾸려면** 환경변수만 지정합니다(`run_all.py`는 이때 mock vLLM을 띄우지 않습니다).

  ```powershell
  $env:VLLM_BASE_URL="http://<사내 vLLM>/v1"; $env:VLLM_MODEL="<served-model-name>"; $env:VLLM_API_KEY="<키>"; $env:VLLM_MOCK_HINTS="0"
  python scripts/run_all.py
  ```

- **mock_hint**
  - mock vLLM은 요청 body의 `mock_hint`(업무 종류 + 입력)를 보고 응답 내용을 만듭니다.
  - 실제 vLLM은 모르는 필드를 무시하지만, 운영에서는 `VLLM_MOCK_HINTS=0`으로 끄세요.
- **실패 대응**
  - vLLM 호출이 실패하면 그 호출만 템플릿 응답으로 대체하고, 관제에 `state=fallback`으로 남깁니다.
  - PC가 오프라인이면 처음부터 템플릿으로 처리합니다.
- **주간보고 구조화 항목**(완료/진행중/예정)은 LLM 없이 활동 기록에서 그대로 계산합니다. LLM은 사람이 읽을 본문만 씁니다.
- `LLM_PROVIDER=claude`(Anthropic API)와 `template`(지연 없는 규칙 기반)도 선택할 수 있습니다.

### 7.3 담당자 요청 = A2A Task 생명주기

```
이서준 PC ─request-create→ Hub ─people-lookup→ People (담당자/부재 확인)
                            └─request-create→ Broker: Task 생성 → state=INPUT_REQUIRED
                                                      └ 수신함 이벤트 request.received → 박지아 PC (SSE, 미연결이면 보관)
박지아 PC ─request-reply(task_id=request_id)→ Hub → Broker: 같은 Task 재개 → state=COMPLETED
                                                      └ 이벤트 request.answered → 이서준 PC
```

### 7.4 인증과 권한

- `/a2a`(JSON-RPC)와 `/api/*`는 `Authorization: Bearer <token>`이 필요합니다. 토큰이 없으면 401을 반환합니다. Agent Card는 공개입니다.
- Hub는 하위 Agent를 **요청한 사용자의 토큰으로** 호출합니다. 그래서 Knowledge Agent가 그 사용자가 볼 수 있는 문서만 근거로 씁니다.
- `/admin/*`(콘솔용 관리 API)와 mock vLLM은 **목업이라 인증이 없습니다.** 운영에서는 관리자 권한/내부망 제한과 vLLM `--api-key`(또는 게이트웨이 인증)가 필요합니다.

### 7.5 Hub REST 확장 (A2A 표준 밖)

| 경로 | 용도 |
|---|---|
| `GET /api/inbox` | 받은/보낸 요청 전체 조회 (재연결 시 동기화) |
| `GET /api/inbox/stream` | 수신함 SSE. PC가 서버로 연결을 열어두는 방식이라 PC에 포트를 열 필요가 없음 |
| `GET /api/people` | 요청 작성 시 담당자 명단 |

### 7.6 관제 이벤트 (trace)

- PC에서 사용자 동작 1회마다 `trace_id`를 만듭니다. 이 값은 `X-Trace-Id` 헤더로 Hub와 하위 Agent까지 전파됩니다.
- 각 프로세스 안에서는 `telemetry.set_trace()` 컨텍스트로 LLM 호출까지 같은 trace에 묶입니다.
- 이벤트에는 **노드/종류/skill/상태/소요시간/토큰 수 같은 메타데이터만** 담고, 질문·문서·답변 내용은 담지 않습니다.

| kind | 보내는 곳 | 의미 |
|---|---|---|
| `a2a.request` / `a2a.response` | 호출하는 쪽 | A2A 호출 시작 / 종료(상태, ms) |
| `skill.start` / `skill.progress` / `skill.end` | 호출받는 Agent | skill 실행 단계 |
| `llm.request` / `llm.response` | LLM 을 호출한 쪽 (PC, Knowledge, Hub) | 사내 vLLM 호출(task, 입력/출력 토큰, 첫 토큰 ms, 총 ms, completed/fallback) |
| `inbox.publish` / `inbox.received` | Broker / PC | 수신함 이벤트 발행(실시간 전달 여부) / PC 수신 |
| `inbox.connect` / `inbox.disconnect` | Hub | PC 수신함 연결 상태 |
| `desktop.intent` / `local.tool` / `user.approve` | PC | 의도 분류 결과(경로), 로컬 도구 사용, 사용자 승인 |
| `desktop.offline` / `desktop.online` | PC | 오프라인 시뮬레이션 전환 |

## 8. 운영 전환 가이드

| 목업 구성 | 운영 전환 |
|---|---|
| mock vLLM (`services/llm_mock`) | 사내 vLLM 주소로 교체 (`VLLM_BASE_URL`/`VLLM_MODEL`/`VLLM_API_KEY`, `VLLM_MOCK_HINTS=0`). 사용량 제한·감사가 필요하면 OpenAI 호환 게이트웨이(LiteLLM 등)를 앞에 두고 주소만 변경 |
| `common/simulate.py` 지연 | 제거 (운영에는 불필요) |
| `common/templates.py` | 오프라인 대체용으로만 유지하거나 제거 |
| `dev-token-<user_id>` (`common/auth.py`) | 사내 SSO(OIDC) - PC는 Authorization Code + PKCE, 토큰은 OS 키체인 보관. 서버는 JWT 검증. 하위 Agent 호출은 Token Exchange(OBO) |
| `/admin/*` 무인증 + 콘솔 | 관리자 역할 기반 접근 제어 + 내부망/VPN 한정 + 변경 감사 로그 |
| `common/telemetry.py` + Monitor | OpenTelemetry(span) + W3C `traceparent` → Collector → Jaeger/Tempo, Prometheus/Grafana(vLLM `/metrics` 포함). 관제 화면은 업무 흐름 대시보드로 유지 |
| `InMemoryTaskStore` | a2a-sdk `DatabaseTaskStore` (PostgreSQL 등) |
| `RequestStore`, `PeopleStore`, 문서 저장소 (메모리) | RDB + 인사/Jira/캘린더 연동, 문서 커넥터(Confluence/SharePoint) |
| `EventHub` (프로세스 메모리) | Redis Pub/Sub, Kafka 등 |
| `textsearch.py` (bigram) | 청크 + 임베딩(사내 임베딩 모델) + 벡터 검색 + ACL 색인 |
| 데스크탑 = 로컬 웹서버 | Tauri/Electron 셸. 로컬 API는 IPC로, 진행 스트리밍은 IPC 이벤트로 대체. `local_tools.py`는 로컬 MCP 서버로 분리 |
| HTTP | HTTPS(사내 인증서), rate limit, 감사 로그 |

### 새 하위 Agent 추가하기

1. `common.a2a_kit`으로 Agent를 만듭니다.

   ```python
   card = build_agent_card(name="Deploy Agent", description="...", base_url=URL,
                           skills=[{"id": "deploy-status", "name": "배포 현황", "description": "..."}])
   async def deploy_status(req: SkillRequest) -> None:
       await req.progress("조회 중")                  # 진행 메시지 (PC 진행 패널/관제에 표시)
       await get_llm().answer_with_docs(q, docs, on_delta=req.stream_text)  # 답변 스트리밍
       await req.reply(data={...}, name="deploy-meta")
   app = create_agent_app(card, SkillRouterExecutor("deploy", {"deploy-status": deploy_status}),
                          node="deploy", console_html=Path(__file__).parent / "console.html")
   ```

2. `common/config.py`에서 다음 두 곳에 추가합니다.
   - `DOWNSTREAM_AGENT_URLS`에 주소를 추가하면 Hub 레지스트리가 skill을 자동 등록합니다.
   - `NODES`에 노드를 추가하면 콘솔 내비게이션과 관제 헬스체크에 표시됩니다. 관제 흐름도에 그리려면 `monitor.js`의 `POS`/`EDGES`에도 추가합니다.
3. PC에서 직접 호출할 skill이면 `services/hub/orchestrator.py`에 위임 핸들러를 추가합니다.

## 9. 알려진 제약 (목업 범위)

- 모든 저장소가 메모리라서 서버를 재시작하면 요청, 주간보고, 콘솔에서 바꾼 문서·담당자 정보가 초기화됩니다. 관제 이벤트는 최근 3,000건만 보관합니다.
- 토큰 수는 글자 수 기반 추정치입니다(모델 토크나이저마다 다름). 실제 vLLM 연결 시 `/metrics`와 응답 `usage`를 기준으로 보세요.
- 더미 데이터는 2026-10-12 주간 기준입니다. `MOCK_TODAY`(기본 `2026-10-16`)로 기준일을 고정했습니다.
- 데스크탑 로컬 API, 서버 `/admin/*`, mock vLLM은 인증이 없습니다. 127.0.0.1에서만 쓰는 전제입니다.
- mock vLLM의 응답 내용은 템플릿이라 질문 문장이 많이 달라도 같은 틀로 답합니다. 실제 사내 vLLM에 연결하면 자연스러운 답변이 생성됩니다.
- 관제 시각은 같은 PC의 프로세스끼리 맞춘 고해상도 시각입니다. 여러 서버로 나뉘면 NTP 동기화와 OpenTelemetry span 관계로 순서를 판단해야 합니다.
