"""담당자 정보 저장소 (목업: data/users.json + 메모리).

운영 전환 시: 인사 시스템(조직/직무) + Jira/캘린더(현재 작업/부재) + 주간보고 DB 를 조합.
'현재 작업'은 본인이 승인해 올린 주간보고와 업무 시스템 데이터로만 갱신한다 (PC 모니터링 금지).
"""

import json
import uuid
from datetime import datetime
from pathlib import Path

from common.textsearch import bigrams, overlap


class PeopleStore:
    def __init__(self, users_file: Path):
        users = json.loads(users_file.read_text(encoding="utf-8"))
        self.people: dict[str, dict] = {u["id"]: u for u in users}
        self.reports: dict[str, list[dict]] = {}

    def public_profile(self, person: dict) -> dict:
        backup = self.people.get(person.get("backup") or "")
        return {
            "user_id": person["id"],
            "name": person["name"],
            "team": person["team"],
            "title": person["title"],
            "email": person["email"],
            "responsibilities": person["responsibilities"],
            "current_work": person["current_work"],
            "status": person["status"],
            "status_note": person.get("status_note", ""),
            "backup": {"user_id": backup["id"], "name": backup["name"]} if backup else None,
            "last_report_at": person.get("last_report_at", ""),
        }

    def all(self) -> list[dict]:
        return [self.public_profile(p) for p in self.people.values()]

    def find_by_name(self, text: str) -> list[dict]:
        return [self.public_profile(p) for p in self.people.values() if p["name"] in text]

    def find_by_topic(self, topic: str, limit: int = 3, threshold: float = 0.3) -> list[dict]:
        q = bigrams(topic)
        scored = []
        for p in self.people.values():
            score = max(
                overlap(q, " ".join(p["responsibilities"])),
                0.6 * overlap(q, " ".join(p["current_work"])),
                0.3 * overlap(q, p["team"]),
            )
            if score >= threshold:
                scored.append((score, p))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [{**self.public_profile(p), "score": round(s, 3)} for s, p in scored[:limit]]

    def submit_report(self, user_id: str, report: dict) -> dict:
        person = self.people[user_id]
        record = {
            "report_id": f"WR-{uuid.uuid4().hex[:8]}",
            "user_id": user_id,
            "submitted_at": datetime.now().isoformat(timespec="seconds"),
            **report,
        }
        self.reports.setdefault(user_id, []).append(record)

        # 주간보고의 '진행중' 항목과 다음 주 계획으로 현재 작업을 갱신
        in_progress = [i["title"] for i in report.get("items", []) if i.get("status") == "진행중"]
        updated = in_progress + list(report.get("next_week", []))
        if updated:
            person["current_work"] = updated
        person["last_report_at"] = record["submitted_at"]
        return record
