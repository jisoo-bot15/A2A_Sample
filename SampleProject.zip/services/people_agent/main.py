"""People Agent (A2A 서버) - 담당자 정보와 주간보고 관리.

skill
- people-lookup        : data {user_id? | name? | topic? | all?} 또는 text -> data.matches
- weekly-report-submit : data {week, summary, items[], next_week[]} -> 접수 결과

실행: python -m uvicorn services.people_agent.main:app --port 9102
"""

from pathlib import Path

from fastapi import HTTPException
from pydantic import BaseModel

from common import simulate
from common.a2a_kit import SkillError, SkillRequest, SkillRouterExecutor, build_agent_card, create_agent_app
from common.config import DATA_DIR, PEOPLE_AGENT_URL
from common.logs import setup_logging
from services.people_agent.store import PeopleStore

setup_logging("people")

store = PeopleStore(DATA_DIR / "users.json")


def _describe(p: dict) -> str:
    status = f" · 부재: {p['status_note']}" if p["status"] == "away" else ""
    return (f"- {p['name']} ({p['team']} {p['title']}){status}\n"
            f"  담당: {', '.join(p['responsibilities'])}\n"
            f"  현재 작업: {', '.join(p['current_work'])}")


async def people_lookup(req: SkillRequest) -> None:
    await simulate.delay("directory")
    if req.data.get("all"):
        matches = store.all()
    elif req.data.get("user_id"):
        person = store.people.get(req.data["user_id"])
        matches = [store.public_profile(person)] if person else []
    elif req.data.get("name"):
        matches = store.find_by_name(req.data["name"])
    else:
        query = req.data.get("topic") or req.text
        matches = store.find_by_name(query) or store.find_by_topic(query)

    text = ("관련 담당자:\n" + "\n".join(_describe(m) for m in matches)) if matches else \
        "해당 업무의 담당자를 찾지 못했습니다."
    await req.reply(text=text, data={"matches": matches}, name="people")


async def weekly_report_submit(req: SkillRequest) -> None:
    report = req.data
    if not report.get("summary"):
        raise SkillError("주간보고 본문(summary)이 비어 있습니다.")
    await req.progress("주간보고 저장 및 현재 작업 갱신")
    await simulate.delay("db_write", factor=2)
    record = store.submit_report(req.principal.user_id, report)
    profile = store.public_profile(store.people[req.principal.user_id])
    await req.reply(
        text=f"{record['week']} 주간보고가 접수되었습니다. (접수번호 {record['report_id']})",
        data={"report_id": record["report_id"], "current_work": profile["current_work"]},
        name="weekly-report-receipt",
    )


card = build_agent_card(
    name="People Agent",
    description="담당자의 업무 범위, 현재 작업, 부재/대리 담당자 정보를 관리합니다.",
    base_url=PEOPLE_AGENT_URL,
    skills=[
        {
            "id": "people-lookup",
            "name": "담당자 조회",
            "description": "이름 또는 업무 키워드로 담당자와 현재 작업을 조회합니다.",
            "tags": ["people", "directory"],
            "examples": ["배포 담당자 누구야?", "정산 API 담당자"],
        },
        {
            "id": "weekly-report-submit",
            "name": "주간보고 접수",
            "description": "사용자가 승인한 주간보고를 저장하고 현재 작업 정보를 갱신합니다.",
            "tags": ["report"],
        },
    ],
)

app = create_agent_app(
    card,
    SkillRouterExecutor("people", {
        "people-lookup": people_lookup,
        "weekly-report-submit": weekly_report_submit,
    }),
    node="people",
    console_html=Path(__file__).parent / "console.html",
)


# ----------------------------------------------------------------- 콘솔용 관리 API


class PersonPatch(BaseModel):
    status: str | None = None          # available | away
    status_note: str | None = None
    backup: str | None = None          # user_id, 빈 문자열이면 해제
    responsibilities: list[str] | None = None
    current_work: list[str] | None = None


@app.get("/admin/people", tags=["admin"])
async def admin_people() -> list[dict]:
    return store.all()


@app.patch("/admin/people/{user_id}", tags=["admin"])
async def admin_patch_person(user_id: str, body: PersonPatch) -> dict:
    person = store.people.get(user_id)
    if not person:
        raise HTTPException(404, "담당자 없음")
    changes = body.model_dump(exclude_none=True)
    if "backup" in changes:
        changes["backup"] = changes["backup"] or None
    person.update(changes)
    return store.public_profile(person)


@app.get("/admin/reports", tags=["admin"])
async def admin_reports() -> list[dict]:
    rows = [r for reports in store.reports.values() for r in reports]
    return sorted(rows, key=lambda r: r["submitted_at"], reverse=True)


@app.get("/admin/lookup", tags=["admin"])
async def admin_lookup(topic: str) -> dict:
    """담당자 결정 미리보기: Hub 가 request-create 때 쓰는 규칙(최고 점수 → 부재 시 대리)."""
    matches = store.find_by_topic(topic)
    route = None
    if matches:
        target = matches[0]
        route = {"primary": target["name"], "final": target["name"], "reason": "업무 키워드 최고 점수"}
        if target["status"] == "away" and target.get("backup"):
            route.update(final=target["backup"]["name"], reason=f"{target['name']} 부재 → 대리 담당자")
    return {"matches": matches, "route": route}


@app.post("/admin/reset", tags=["admin"])
async def reset() -> dict:
    """시연용: 담당자 정보(부재·현재 작업)와 주간보고를 data/users.json 기준으로 되돌린다."""
    store.__init__(DATA_DIR / "users.json")
    return {"people": len(store.people)}