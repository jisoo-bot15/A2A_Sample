"""mock 사내 vLLM 서버 - vLLM 의 OpenAI 호환 API 모양을 흉내낸다.

- POST /v1/chat/completions : stream=true 면 SSE 로 토큰을 조금씩 보냄 (vLLM 과 같은 chunk 형식)
- GET  /v1/models, /health, /metrics(Prometheus, vllm:num_requests_running 등)

응답 시간 모델 (요청 1건)
  대기(queue) + 입력 처리(prefill: 입력 토큰 / PREFILL_TPS) + 생성(decode: 출력 토큰 / DECODE_TPS)
  동시 요청이 많을수록 생성 속도가 떨어진다 (배치 처리 흉내).
  → 질문 분류처럼 출력이 짧은 일은 빠르고, 문서 기반 답변/주간보고처럼 길게 쓰는 일은 수 초가 걸린다.

응답 '내용'은 요청의 mock_hint(업무 종류 + 입력)를 보고 common.templates 로 만든다.
실제 vLLM 으로 바꾸면 이 서버는 필요 없다 (VLLM_BASE_URL 만 변경).

실행: python -m uvicorn services.llm_mock.main:app --port 8800
"""

import asyncio
import json
import random
import time
import uuid
from collections import deque
from pathlib import Path

from fastapi import Body, FastAPI
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, StreamingResponse
from pydantic import BaseModel

from common import config, templates
from common.a2a_kit import mount_console
from common.llm import estimate_tokens
from common.logs import setup_logging

setup_logging("vllm-mock")

app = FastAPI(title="mock vLLM (OpenAI compatible)")
mount_console(app, "llm")

settings = {
    "speed": config.MOCK_SPEED,
    "prefill_tps": config.MOCK_LLM_PREFILL_TPS,
    "decode_tps": config.MOCK_LLM_DECODE_TPS,
    "concurrency_penalty": 0.15,   # 동시 요청 1건당 생성 속도 저하 비율
}
stats = {"running": 0, "total": 0, "prompt_tokens": 0, "completion_tokens": 0}
recent: deque[dict] = deque(maxlen=60)


def _sleep_for(seconds: float) -> float:
    return 0.0 if settings["speed"] <= 0 else seconds / settings["speed"]


def _chunks(text: str, size: int = 3) -> list[str]:
    return [text[i:i + size] for i in range(0, len(text), size)]


def _content_for(body: dict) -> tuple[str, str]:
    hint = body.get("mock_hint") or {}
    task = hint.get("task", "")
    if task:
        return task, templates.for_hint(task, hint)
    last = body["messages"][-1]["content"] if body.get("messages") else ""
    return "chat", f"(mock vLLM) 요청을 받았습니다. 입력 {estimate_tokens(last)} 토큰.\n\n" + last[:300]


@app.get("/", include_in_schema=False)
async def console() -> FileResponse:
    return FileResponse(Path(__file__).parent / "console.html")


@app.get("/health")
async def health() -> PlainTextResponse:
    return PlainTextResponse("")  # vLLM 과 같이 200 + 빈 본문


@app.get("/v1/models")
async def models() -> dict:
    return {"object": "list", "data": [{"id": config.VLLM_MODEL, "object": "model", "owned_by": "corp"}]}


@app.get("/metrics")
async def metrics() -> PlainTextResponse:
    lines = [
        f'vllm:num_requests_running{{model_name="{config.VLLM_MODEL}"}} {stats["running"]}',
        f'vllm:num_requests_waiting{{model_name="{config.VLLM_MODEL}"}} 0',
        f'vllm:prompt_tokens_total{{model_name="{config.VLLM_MODEL}"}} {stats["prompt_tokens"]}',
        f'vllm:generation_tokens_total{{model_name="{config.VLLM_MODEL}"}} {stats["completion_tokens"]}',
    ]
    return PlainTextResponse("\n".join(lines) + "\n")


@app.post("/v1/chat/completions")
async def chat_completions(body: dict = Body(...)):
    task, content = _content_for(body)
    prompt_text = "".join(m.get("content", "") for m in body.get("messages", []))
    pt, ct = estimate_tokens(prompt_text), estimate_tokens(content)
    rid = f"chatcmpl-{uuid.uuid4().hex[:16]}"
    record = {"id": rid, "task": task, "prompt_tokens": pt, "completion_tokens": ct,
              "started": time.strftime("%H:%M:%S"), "state": "running", "ttft_ms": None, "duration_ms": None}
    recent.appendleft(record)

    async def generate():
        stats["running"] += 1
        stats["total"] += 1
        t0 = time.perf_counter()
        try:
            # 대기 + 입력 처리(prefill)
            await asyncio.sleep(_sleep_for(random.uniform(0.05, 0.2) + 0.04 * (stats["running"] - 1)
                                           + pt / settings["prefill_tps"]))
            record["ttft_ms"] = round((time.perf_counter() - t0) * 1000)
            for piece in _chunks(content):
                load = 1 + settings["concurrency_penalty"] * (stats["running"] - 1)
                tps = settings["decode_tps"] / load
                await asyncio.sleep(_sleep_for(estimate_tokens(piece) / tps * random.uniform(0.7, 1.3)))
                yield piece
            record["state"] = "completed"
        finally:
            stats["running"] -= 1
            stats["prompt_tokens"] += pt
            stats["completion_tokens"] += ct
            record["duration_ms"] = round((time.perf_counter() - t0) * 1000)
            if record["state"] == "running":
                record["state"] = "aborted"

    def chunk(delta: dict, finish: str | None = None) -> str:
        return "data: " + json.dumps({
            "id": rid, "object": "chat.completion.chunk", "created": int(time.time()),
            "model": config.VLLM_MODEL,
            "choices": [{"index": 0, "delta": delta, "finish_reason": finish}],
        }, ensure_ascii=False) + "\n\n"

    if body.get("stream"):
        async def sse():
            yield chunk({"role": "assistant", "content": ""})
            async for piece in generate():
                yield chunk({"content": piece})
            yield chunk({}, "stop")
            if (body.get("stream_options") or {}).get("include_usage"):
                yield "data: " + json.dumps({"id": rid, "object": "chat.completion.chunk", "choices": [],
                                             "usage": {"prompt_tokens": pt, "completion_tokens": ct,
                                                       "total_tokens": pt + ct}}) + "\n\n"
            yield "data: [DONE]\n\n"

        return StreamingResponse(sse(), media_type="text/event-stream")

    async for _ in generate():
        pass
    return JSONResponse({
        "id": rid, "object": "chat.completion", "created": int(time.time()), "model": config.VLLM_MODEL,
        "choices": [{"index": 0, "message": {"role": "assistant", "content": content}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": pt, "completion_tokens": ct, "total_tokens": pt + ct},
    })


# ----------------------------------------------------------------- 콘솔용 관리 API


class SettingsIn(BaseModel):
    speed: float | None = None
    prefill_tps: float | None = None
    decode_tps: float | None = None
    concurrency_penalty: float | None = None


@app.get("/admin/status")
async def admin_status() -> dict:
    return {"model": config.VLLM_MODEL, "settings": settings, "stats": stats, "recent": list(recent)}


@app.patch("/admin/settings")
async def admin_settings(body: SettingsIn) -> dict:
    settings.update(body.model_dump(exclude_none=True))
    return settings


@app.post("/admin/reset")
async def admin_reset() -> dict:
    """시연용: 요청 기록과 누적 통계를 지운다."""
    recent.clear()
    stats.update(total=0, prompt_tokens=0, completion_tokens=0)
    return stats