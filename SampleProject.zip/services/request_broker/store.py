"""담당자 요청 저장소 (목업: 메모리).

요청 1건 = A2A Task 1개 (request_id == task_id)
  waiting   : Task input_required  (담당자 답변 대기)
  answered  : Task completed       (답변 완료)

운영 전환 시: RDB(요청/이력 테이블) + a2a-sdk DatabaseTaskStore 로 영속화.
"""

from datetime import datetime


class RequestStore:
    def __init__(self) -> None:
        self.requests: dict[str, dict] = {}

    def create(self, *, request_id: str, context_id: str, from_user: dict, to_user: dict,
               title: str, body: str, topic: str, due: str, routed_reason: str,
               trace_id: str = "") -> dict:
        record = {
            "request_id": request_id,
            "context_id": context_id,
            "from_user": from_user,
            "to_user": to_user,
            "title": title,
            "body": body,
            "topic": topic,
            "due": due,
            "routed_reason": routed_reason,
            "status": "waiting",
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "answered_at": "",
            "reply": "",
            "trace_id": trace_id,        # 요청 생성 동작의 trace (관제 화면 연결용)
            "reply_trace_id": "",
        }
        self.requests[request_id] = record
        return record

    def get(self, request_id: str) -> dict | None:
        return self.requests.get(request_id)

    def answer(self, request_id: str, reply: str, trace_id: str = "") -> dict:
        record = self.requests[request_id]
        record.update(status="answered", reply=reply, reply_trace_id=trace_id,
                      answered_at=datetime.now().isoformat(timespec="seconds"))
        return record

    def received_by(self, user_id: str) -> list[dict]:
        return sorted((r for r in self.requests.values() if r["to_user"]["user_id"] == user_id),
                      key=lambda r: r["created_at"], reverse=True)

    def sent_by(self, user_id: str) -> list[dict]:
        return sorted((r for r in self.requests.values() if r["from_user"]["user_id"] == user_id),
                      key=lambda r: r["created_at"], reverse=True)
