"""Request Broker Agent (A2A 서버) - 담당자 간 요청 전달/추적.

skill
- request-create : data {to_user, title, body, topic, due, routed_reason}
                   -> Task 를 input_required 로 열어두고 담당자 수신함에 이벤트 발행
- request-reply  : 기존 Task(task_id = request_id)에 담당자의 답변(text)을 보내면 completed

REST 확장 (A2A 표준 밖, PC 수신함용 - Hub 가 프록시)
- GET /api/inbox         : 내가 받은/보낸 요청 목록 (재연결 시 동기화용)
- GET /api/inbox/stream  : SSE 실시간 이벤트 (request.received / request.answered ...)

실행: python -m uvicorn services.request_broker.main:app --port 9103
"""

from pathlib import Path

from a2a.server.context import ServerCallContext
from a2a.server.tasks import InMemoryTaskStore
from fastapi import Depends, HTTPException
from fastapi.responses import StreamingResponse
from google.protobuf.json_format import MessageToDict
from pydantic import BaseModel

from common import simulate, telemetry
from common.a2a_kit import SkillError, SkillRequest, SkillRouterExecutor, build_agent_card, create_agent_app
from common.auth import Principal, directory, require_principal
from common.config import REQUEST_BROKER_URL
from common.events import EventHub
from common.logs import setup_logging
from services.request_broker.store import RequestStore

setup_logging("broker")

store = RequestStore()
events = EventHub()
# 요청 Task 는 요청자/담당자 두 사람이 접근하므로 사용자별이 아닌 서비스 단위로 저장하고,
# 접근 제어는 핸들러에서 수행한다.
task_store = InMemoryTaskStore(owner_resolver=lambda ctx: "request-broker")


def publish(user_id: str, event: str, data: dict, trace_id: str | None) -> int:
    delivered = events.publish(user_id, event, data)
    telemetry.emit("inbox.publish", trace_id=trace_id, **{"from": "broker", "to": f"desktop:{user_id}"},
                   user=user_id, event=event, request_id=data.get("request_id"), delivered=delivered > 0)
    return delivered


async def request_create(req: SkillRequest) -> None:
    d = req.data
    to_user = d.get("to_user") or {}
    if not to_user.get("user_id"):
        raise SkillError("받는 사람(to_user)이 지정되지 않았습니다.")

    await simulate.delay("db_write")
    record = store.create(
        request_id=req.task.id,
        context_id=req.task.context_id,
        from_user={"user_id": req.principal.user_id, "name": req.principal.name, "team": req.principal.team},
        to_user=to_user,
        title=d.get("title") or d.get("body", "")[:40],
        body=d.get("body", ""),
        topic=d.get("topic", ""),
        due=d.get("due", ""),
        routed_reason=d.get("routed_reason", ""),
        trace_id=req.trace_id,
    )
    delivered = publish(to_user["user_id"], "request.received", record, req.trace_id)
    publish(req.principal.user_id, "request.sent", record, req.trace_id)
    if not delivered:
        await req.progress(f"{to_user['name']}님 PC 미연결 - 수신함에 보관")

    await req.reply(data={"request": record, "delivered_realtime": delivered > 0}, name="request")
    await req.wait_for_input(f"{to_user['name']}님의 답변 대기 중")


async def request_reply(req: SkillRequest) -> None:
    record = store.get(req.task.id)
    if req.is_new_task or record is None:
        raise SkillError("답변할 요청(task_id)을 찾을 수 없습니다.")
    if record["to_user"]["user_id"] != req.principal.user_id:
        # 요청은 계속 열어둔 채 거절 사유만 알린다
        await req.wait_for_input("이 요청의 담당자만 답변할 수 있습니다.")
        return
    if not req.text.strip():
        await req.wait_for_input("답변 내용이 비어 있습니다.")
        return

    await simulate.delay("db_write")
    record = store.answer(req.task.id, req.text.strip(), trace_id=req.trace_id)
    publish(record["from_user"]["user_id"], "request.answered", record, req.trace_id)
    publish(record["to_user"]["user_id"], "request.closed", record, req.trace_id)
    await req.reply(text=record["reply"], data={"request": record}, name="reply")


card = build_agent_card(
    name="Request Broker Agent",
    description="담당자 간 요청을 A2A Task 로 관리합니다. 답변 전까지 input_required 상태로 유지됩니다.",
    base_url=REQUEST_BROKER_URL,
    skills=[
        {
            "id": "request-create",
            "name": "요청 생성",
            "description": "담당자에게 요청을 전달하고 답변 대기 Task 를 생성합니다.",
            "tags": ["request", "workflow"],
        },
        {
            "id": "request-reply",
            "name": "요청 답변",
            "description": "열려 있는 요청 Task 에 담당자의 답변을 등록하고 완료합니다.",
            "tags": ["request", "workflow"],
        },
    ],
)

app = create_agent_app(
    card,
    SkillRouterExecutor("broker", {"request-create": request_create, "request-reply": request_reply}),
    node="broker",
    console_html=Path(__file__).parent / "console.html",
    task_store=task_store,
)


@app.get("/api/inbox", tags=["inbox (extension)"])
async def inbox(me: Principal = Depends(require_principal)) -> dict:
    return {"received": store.received_by(me.user_id), "sent": store.sent_by(me.user_id)}


@app.get("/api/inbox/stream", tags=["inbox (extension)"])
async def inbox_stream(me: Principal = Depends(require_principal)) -> StreamingResponse:
    return StreamingResponse(
        events.stream(me.user_id, hello={"user_id": me.user_id}),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ----------------------------------------------------------------- 콘솔용 관리 API


class NoticeIn(BaseModel):
    user_id: str
    message: str


@app.get("/admin/requests", tags=["admin"])
async def admin_requests() -> list[dict]:
    return sorted(store.requests.values(), key=lambda r: r["created_at"], reverse=True)


@app.get("/admin/requests/{request_id}", tags=["admin"])
async def admin_request(request_id: str) -> dict:
    record = store.get(request_id)
    if not record:
        raise HTTPException(404, "요청 없음")
    task = await task_store.get(request_id, ServerCallContext())
    return {"request": record, "a2a_task": MessageToDict(task) if task else None}


@app.post("/admin/requests/{request_id}/remind", tags=["admin"])
async def admin_remind(request_id: str) -> dict:
    record = store.get(request_id)
    if not record:
        raise HTTPException(404, "요청 없음")
    if record["status"] != "waiting":
        raise HTTPException(400, "답변 대기 중인 요청만 리마인드할 수 있습니다.")
    delivered = publish(record["to_user"]["user_id"], "request.reminded", record, record.get("trace_id"))
    return {"delivered_realtime": delivered > 0}


@app.get("/admin/subscribers", tags=["admin"])
async def admin_subscribers() -> list[dict]:
    counts = events.subscribers()
    return [
        {"user_id": u["id"], "name": u["name"], "team": u["team"], "connections": counts.get(u["id"], 0),
         "waiting": sum(1 for r in store.received_by(u["id"]) if r["status"] == "waiting")}
        for u in directory().values()
    ]


@app.post("/admin/notice", tags=["admin"])
async def admin_notice(body: NoticeIn) -> dict:
    """특정 사용자 PC 로 공지 이벤트 발행 (수신함 실시간 채널 점검용)."""
    delivered = publish(body.user_id, "notice", {"message": body.message}, telemetry.new_trace_id())
    return {"delivered_realtime": delivered > 0}


@app.post("/admin/reset", tags=["admin"])
async def reset() -> dict:
    """시연용: 요청과 A2A Task 를 모두 지운다 (수신함 연결은 유지)."""
    store.requests.clear()
    task_store._impl.tasks.clear()  # a2a-sdk InMemoryTaskStore 내부 저장소
    return {"requests": 0}