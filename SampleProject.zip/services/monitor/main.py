"""관제(Monitor) 서비스 - 모든 프로세스의 동작 이벤트를 모아 실시간으로 보여준다.

- POST /ingest           : 각 프로세스(서버/PC/콘솔)가 이벤트를 보냄 (메타데이터만)
- GET  /api/events       : 최근 이벤트 (trace_id 로 필터 가능)
- GET  /api/stream       : 관제 화면용 SSE (event / health)
- GET  /api/nodes        : 노드 목록 + 상태(헬스체크 결과)
- GET  /api/requests     : Request Broker 의 요청 현황
- GET  /                 : 관제 화면

A2A Agent 가 아니라 운영 도구다. 운영 전환 시: OpenTelemetry Collector + Jaeger/Tempo(트레이스),
Prometheus/Grafana(지표), Loki(로그) 조합으로 대체하고, 이 화면은 업무 흐름 관점의 대시보드로 남긴다.

실행: python -m uvicorn services.monitor.main:app --port 9900
"""

import asyncio
import time
from collections import deque
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

import httpx
from fastapi import Body, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from common.a2a_kit import mount_console
from common.config import NODES, REQUEST_BROKER_URL
from common.events import EventHub
from common.logs import setup_logging

setup_logging("monitor")

STATIC_DIR = Path(__file__).parent / "static"
MAX_EVENTS = 3000
HEALTH_INTERVAL = 1.0

events: deque[dict] = deque(maxlen=MAX_EVENTS)
seq = 0
hub = EventHub()
health: dict[str, dict] = {node_id: {"up": False} for node_id in NODES}
DEMO_ALIVE_SEC = 30
demo: dict = {"paused": False, "last": None, "seen": -1e9}
http = httpx.AsyncClient(timeout=1.5)


async def _check(node_id: str, node: dict) -> dict:
    try:
        r = await http.get(node["url"] + node["health"])
        status = {"up": r.status_code == 200}
        if node["kind"] == "desktop" and r.status_code == 200:
            me = r.json()
            status.update(hub_connected=me.get("hub_connected", False), offline=me.get("offline", False))
        if node["kind"] == "llm" and r.status_code == 200:
            # vLLM Prometheus 지표에서 실행/대기 요청 수 (실제 vLLM 도 같은 이름으로 제공)
            m = await http.get(node["url"] + "/metrics")
            for line in m.text.splitlines():
                if line.startswith("vllm:num_requests_running"):
                    status["running"] = int(float(line.rsplit(" ", 1)[1]))
                elif line.startswith("vllm:num_requests_waiting"):
                    status["waiting"] = int(float(line.rsplit(" ", 1)[1]))
        return status
    except httpx.HTTPError:
        return {"up": False}


async def health_loop() -> None:
    while True:
        results = await asyncio.gather(*(_check(k, v) for k, v in NODES.items()))
        changed = False
        for node_id, status in zip(NODES, results, strict=True):
            if health.get(node_id) != status:
                health[node_id] = status
                changed = True
        if changed:
            hub.publish("monitor", "health", health)
        await asyncio.sleep(HEALTH_INTERVAL)


@asynccontextmanager
async def lifespan(_: FastAPI):
    task = asyncio.create_task(health_loop())
    yield
    task.cancel()


app = FastAPI(title="A2A Monitor", lifespan=lifespan)
# 브라우저 콘솔(다른 포트)에서도 이벤트를 보낼 수 있도록 허용 (목업 한정)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
mount_console(app, "monitor")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", include_in_schema=False)
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/health")
async def own_health() -> dict:
    return {"status": "ok", "events": len(events)}


@app.post("/ingest")
async def ingest(event: dict = Body(...)) -> dict:
    global seq
    seq += 1
    event["seq"] = seq
    event.setdefault("ts", datetime.now().isoformat(timespec="microseconds"))
    if event.get("node") == "demo":
        # 자동 시연 해설은 관제 기록에 남기지 않고 마지막 상태만 보관 (새로 연 화면에 바로 표시)
        demo["last"] = event
        demo["seen"] = time.monotonic()
        hub.publish("monitor", "event", event)
        return {"ok": True, "seq": seq}
    events.append(event)
    hub.publish("monitor", "event", event)
    return {"ok": True, "seq": seq}


@app.get("/api/events")
async def list_events(trace_id: str | None = None, limit: int = 1000) -> list[dict]:
    rows = [e for e in events if trace_id is None or e.get("trace_id") == trace_id]
    return rows[-limit:]


@app.post("/api/clear")
async def clear() -> dict:
    events.clear()
    hub.publish("monitor", "cleared", {})
    return {"ok": True}


# ------------------------------------------------------------------ 자동 시연 제어 (scripts/autoplay.py 가 확인)

def _demo_state() -> dict:
    running = time.monotonic() - demo["seen"] < DEMO_ALIVE_SEC
    return {"paused": demo["paused"], "running": running, "last": demo["last"] if running else None}


@app.get("/api/demo")
async def demo_state(poll: bool = False) -> dict:
    if poll:  # autoplay 의 주기적 확인 = 시연이 살아 있다는 신호
        demo["seen"] = time.monotonic()
    return _demo_state()


@app.post("/api/demo")
async def demo_control(body: dict = Body(...)) -> dict:
    demo["paused"] = bool(body.get("paused"))
    state = _demo_state()
    hub.publish("monitor", "demo", state)
    return state


@app.get("/api/nodes")
async def nodes() -> dict:
    return {"nodes": NODES, "health": health}


# 노드 세부 패널의 '서버 상태' 영역에 쓰는 각 서버의 관리 API (브라우저 대신 Monitor 가 대신 조회)
DETAIL_SOURCES = {
    "hub": ["/admin/overview"],
    "knowledge": ["/admin/docs"],
    "people": ["/admin/people"],
    "broker": ["/admin/requests", "/admin/subscribers"],
    "llm": ["/admin/status"],
}


@app.get("/api/nodes/{node_id}/detail")
async def node_detail(node_id: str) -> dict:
    node = NODES.get(node_id)
    if node is None:
        raise HTTPException(404, "알 수 없는 노드")
    sources: dict[str, object] = {}
    for path in DETAIL_SOURCES.get(node_id, []):
        try:
            r = await http.get(node["url"] + path)
            sources[path] = r.json() if r.status_code == 200 else None
        except (httpx.HTTPError, ValueError):
            sources[path] = None  # 실제 vLLM 처럼 관리 API 가 없는 경우
    return {"node": node, "health": health.get(node_id, {}), "sources": sources}


@app.get("/api/requests")
async def requests() -> list[dict]:
    try:
        r = await http.get(f"{REQUEST_BROKER_URL}/admin/requests")
        return r.json() if r.status_code == 200 else []
    except httpx.HTTPError:
        return []


@app.get("/api/stream")
async def stream() -> StreamingResponse:
    return StreamingResponse(hub.stream("monitor", hello={"health": health}),
                             media_type="text/event-stream", headers={"Cache-Control": "no-cache"})
