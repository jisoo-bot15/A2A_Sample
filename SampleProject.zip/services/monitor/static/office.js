// 업무 오피스 관제 화면
// - 평면도: 운영 서버 Agent 는 방, 직원 PC 는 책상. 요청/결과/AI 작업이 복도를 따라 이동한다.
// - 오른쪽: 구성원 상태, 지표, 쉬운 문장으로 쓴 사무실 소식
// - 아래: 업무 흐름(trace 순서도), 담당자 요청 현황, 원본 로그
const { $, $$, esc, h, api, post } = C;
const SVGNS = 'http://www.w3.org/2000/svg';
const VW = 1000;
const VH = 600;

// ------------------------------------------------------------------ 평면도 배치

const HALL_Y = 300;
const SPINE_X = 366;
const ROOMS = {
  people: { x: 376, y: 16, w: 250, h: 180, seat: [500, 112], door: [500, 196], title: '인사 데스크', role: 'People Agent', fill: 'var(--r-people)', icon: 'people' },
  knowledge: { x: 646, y: 16, w: 338, h: 180, seat: [770, 112], door: [770, 196], title: '자료실', role: 'Knowledge Agent', fill: 'var(--r-knowledge)', icon: 'book' },
  llm: { x: 376, y: 404, w: 250, h: 180, seat: [500, 470], door: [500, 404], title: 'AI 작문실', role: '사내 vLLM', fill: 'var(--r-llm)', icon: 'spark' },
  broker: { x: 646, y: 404, w: 338, h: 180, seat: [770, 470], door: [770, 404], title: '요청 우편실', role: 'Request Broker', fill: 'var(--r-broker)', icon: 'mail' },
};
const HUB = { seat: [520, HALL_Y], title: '안내 데스크', role: 'Hub · 오케스트레이터', icon: 'hub' };
const CONSOLE = { seat: [912, HALL_Y], title: '관제 콘솔', role: '운영자 브라우저', icon: 'screen' };
const DESK_SLOTS = [[104, 130], [268, 130], [104, 305], [268, 305], [104, 480], [268, 480]];
const AGENTS = ['hub', 'knowledge', 'people', 'broker', 'llm'];

const SKILL_KO = {
  'knowledge-search': '사내 문서 질의', 'people-lookup': '담당자 조회', 'weekly-report-submit': '주간보고 등록',
  'request-create': '요청 전달', 'request-reply': '요청 답변',
};
const TASK_KO = {
  classify: '질문 이해', 'extract-request': '요청 정리', answer: '문서 기반 답변',
  'weekly-summary': '주간보고 초안', 'draft-reply': '답변 초안',
};
const INTENT_KO = {
  knowledge: '사내 문서 질문', people: '담당자 찾기', local_search: '내 PC 검색',
  weekly_report: '주간보고', send_request: '요청 보내기', help: '도움말',
};
const TOOL_KO = { search_workspace: '작업 폴더 검색', week_activities: '활동 기록 수집', related_context: '관련 일정 확인' };
const STATE_KO = { completed: '완료', failed: '실패', error: '오류', input_required: '답변 대기', rejected: '거절', fallback: '대체 응답' };
const BAD = ['failed', 'error', 'rejected', 'canceled'];
const COLOR = { work: 'var(--ok)', idle: 'var(--warn)', alert: 'var(--crit)', off: 'var(--idle)' };

const S = {
  meta: null, nodes: {}, health: {}, events: [], requests: [], people: {},
  paused: false, buffer: [], trace: null, model: null, dirty: true,
  say: {}, selected: null, filters: { a2a: true, skill: true, inbox: true, llm: true, local: true },
};

// ------------------------------------------------------------------ 유틸

function tsMs(ts) {
  const [base, frac = '0'] = String(ts).split('.');
  return new Date(`${base}.000`).getTime() + Number(`0.${frac}`) * 1000;
}
const sinceMs = (ts) => Date.now() - tsMs(ts);
const fmtDur = (ms) => (ms == null ? '-' : ms < 1000 ? `${Math.round(ms)}ms` : `${(ms / 1000).toFixed(1)}초`);
const debounce = (fn, ms) => { let t; return () => { clearTimeout(t); t = setTimeout(fn, ms); }; };
function traceColor(t) {
  let x = 0;
  for (const c of t || '') x = (x * 31 + c.charCodeAt(0)) >>> 0;
  return `hsl(${x % 360} 45% 46%)`;
}
const chip = (t, label = '') => (t ? `<span class="trace-chip" style="background:${traceColor(t)}" data-trace="${esc(t)}">${label}${esc(t.slice(0, 6))}</span>` : '');
const byTime = (events) => [...events].sort((a, b) => (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : a.seq - b.seq));
const userName = (uid) => S.meta?.users.find((u) => u.id === uid)?.name || uid || '';
const stripAgent = (t) => String(t || '').replace(/^\[[^\]]+\]\s*/, '');

function actorName(id) {
  if (!id) return '';
  if (id === 'hub') return HUB.title;
  if (ROOMS[id]) return ROOMS[id].title;
  if (id === 'console') return CONSOLE.title;
  if (id.startsWith('desktop:')) return `${userName(id.slice(8))} PC`;
  return id;
}
const personName = (id) => (id?.startsWith('desktop:') ? `${userName(id.slice(8))}님` : actorName(id));

function svg(tag, attrs = {}, parent = null) {
  const el = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  if (parent) parent.append(el);
  return el;
}
const pos = (x, y) => `left:${(x / VW) * 100}%;top:${(y / VH) * 100}%`;

// ------------------------------------------------------------------ 자리 / 경로

const desks = {}; // 'desktop:u002' -> [x, y]

function seatOf(id) {
  if (id === 'hub') return HUB.seat;
  if (id === 'console') return CONSOLE.seat;
  if (ROOMS[id]) return ROOMS[id].seat;
  return desks[id] || null;
}
function doorOf(id) {
  if (ROOMS[id]) return ROOMS[id].door;
  if (desks[id]) return [SPINE_X, desks[id][1]];
  return seatOf(id);
}
function hallOf(id) {
  if (desks[id]) return [SPINE_X, HALL_Y];
  const d = doorOf(id);
  return d ? [d[0], HALL_Y] : null;
}
function pathBetween(a, b) {
  const pts = [seatOf(a), doorOf(a), hallOf(a), hallOf(b), doorOf(b), seatOf(b)];
  if (pts.some((p) => !p)) return null;
  return pts.filter((p, i) => i === 0 || p[0] !== pts[i - 1][0] || p[1] !== pts[i - 1][1]);
}

// ------------------------------------------------------------------ 평면도 그리기

const ICONS = {
  hub: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="4.5" r="2"/><circle cx="4.5" cy="18" r="2"/><circle cx="19.5" cy="18" r="2"/><path d="M12 9V6.5M9.6 13.6 6.2 16.6M14.4 13.6l3.4 3"/>',
  book: '<path d="M4 5h6a2 2 0 0 1 2 2v12a2 2 0 0 0-2-2H4zM20 5h-6a2 2 0 0 0-2 2v12a2 2 0 0 1 2-2h6z"/>',
  people: '<circle cx="9" cy="8" r="3"/><path d="M3 19c0-3 2.7-5 6-5s6 2 6 5"/><circle cx="17" cy="9" r="2.2"/><path d="M16 14.3c2.6 0 5 1.6 5 4.4"/>',
  mail: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="m3 7 9 6 9-6"/>',
  spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM18.5 15l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z"/>',
  screen: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
};

function drawFloor() {
  const f = $('#floor');
  f.innerHTML = '';
  // 업무층
  svg('rect', { x: 16, y: 16, width: 340, height: 568, rx: 16, fill: 'var(--floor-desk)', class: 'roomfloor' }, f);
  svg('text', { x: 34, y: 554, class: 'sign' }, f).textContent = '업무층 · 직원 자리';
  svg('text', { x: 34, y: 571, class: 'signsub' }, f).textContent = 'PC 비서가 설치된 책상';
  [[334, 38], [334, 562]].forEach(([x, y]) => svg('circle', { cx: x, cy: y, r: 11, class: 'plant' }, f));
  // 로비
  svg('rect', { x: 376, y: 214, width: 608, height: 172, rx: 14, fill: 'var(--floor-lobby)', class: 'roomfloor' }, f);
  svg('text', { x: 690, y: 238, class: 'lobbytitle' }, f).textContent = 'LOBBY · 운영 서버 층';
  svg('ellipse', { cx: HUB.seat[0], cy: HUB.seat[1], rx: 92, ry: 52, class: 'rug' }, f);
  svg('rect', { x: 860, y: 262, width: 104, height: 76, rx: 10, class: 'furn' }, f);
  [[396, 370], [968, 230], [968, 370]].forEach(([x, y]) => svg('circle', { cx: x, cy: y, r: 9, class: 'plant' }, f));
  // 방
  for (const [id, r] of Object.entries(ROOMS)) {
    const g = svg('g', { class: 'room', 'data-room': id }, f);
    svg('rect', { x: r.x, y: r.y, width: r.w, height: r.h, rx: 14, fill: r.fill, class: 'roomfloor' }, g);
    svg('text', { x: r.x + 16, y: r.y + r.h - 30, class: 'sign' }, g).textContent = r.title;
    svg('text', { x: r.x + 16, y: r.y + r.h - 13, class: 'signsub' }, g).textContent = r.role;
    furnish(id, r, g);
    g.addEventListener('click', () => openNode(id));
  }
  // 안내 데스크(Hub) 클릭 영역
  const hubHit = svg('g', { class: 'room', 'data-room': 'hub' }, f);
  svg('rect', { x: 430, y: 250, width: 180, height: 100, fill: 'transparent' }, hubHit);
  hubHit.addEventListener('click', () => openNode('hub'));

  // 책상
  S.meta.users.forEach((u, i) => {
    const slot = DESK_SLOTS[i];
    if (!slot) return;
    const id = `desktop:${u.id}`;
    desks[id] = slot;
    const [cx, cy] = slot;
    const g = svg('g', { 'data-desk': id }, f);
    svg('rect', { x: cx - 50, y: cy - 74, width: 100, height: 34, rx: 6, class: 'desk' }, g);
    svg('rect', { x: cx - 17, y: cy - 70, width: 34, height: 18, rx: 3, class: 'screen', 'data-screen': id }, g);
    svg('rect', { x: cx - 4, y: cy - 52, width: 8, height: 6, class: 'furn2' }, g);
    const sign = svg('g', { 'data-away': id, visibility: 'hidden' }, g);
    svg('rect', { x: cx + 26, y: cy - 30, width: 40, height: 18, rx: 4, class: 'awaysign' }, sign);
    svg('text', { x: cx + 46, y: cy - 17, 'text-anchor': 'middle', class: 'awaytext' }, sign).textContent = '부재';
    if (S.nodes[id]) {
      g.style.cursor = 'pointer';
      g.addEventListener('click', () => window.open(S.nodes[id].url, '_blank'));
    }
  });

  // 자리(원형 아바타) 레이어
  const actors = svg('g', { id: 'actors' }, f);
  for (const id of [...AGENTS, 'console']) {
    const [x, y] = seatOf(id);
    const g = svg('g', { id: `av-${cssId(id)}`, class: 's-off', transform: `translate(${x},${y})` }, actors);
    svg('circle', { r: 27, class: 'ringfill' }, g);
    svg('circle', { r: 27, class: 'ring' }, g);
    const ic = svg('g', { class: 'icon', transform: 'translate(-12,-12)' }, g);
    ic.innerHTML = ICONS[id === 'hub' ? HUB.icon : id === 'console' ? CONSOLE.icon : ROOMS[id].icon];
  }
  for (const [id, [x, y]] of Object.entries(desks)) {
    const g = svg('g', { id: `av-${cssId(id)}`, class: 'avatar s-off', transform: `translate(${x},${y})` }, actors);
    svg('circle', { r: 22, class: 'ringfill' }, g);
    svg('circle', { r: 22, class: 'ring' }, g);
    svg('text', { 'text-anchor': 'middle', dy: '0.35em' }, g).textContent = userName(id.slice(8)).slice(-2);
  }
  S.fx = svg('g', { id: 'fx' }, f);

  // 이름표 + 말풍선
  const lab = $('#labels');
  lab.innerHTML = '';
  for (const id of [...AGENTS, 'console', ...Object.keys(desks)]) {
    const [x, y] = seatOf(id);
    const isDesk = Boolean(desks[id]);
    const label = isDesk ? userName(id.slice(8)) : actorName(id);
    // 방은 바닥에 이름이 있으므로 이름표를 생략 (상태는 원형 테두리 색으로 표시)
    const tag = ROOMS[id] ? '' : `<div class="pin" style="${pos(x, y + (isDesk ? 26 : 32))}"><span class="nametag" id="tag-${cssId(id)}"><i></i>${esc(label)}</span></div>`;
    lab.insertAdjacentHTML('beforeend',
      `${tag}<div class="bubble" id="bub-${cssId(id)}" style="${pos(x, y - (isDesk ? 78 : 34))}"></div>`);
  }
}

function furnish(id, r, g) {
  if (id === 'knowledge') {
    for (let i = 0; i < 5; i += 1) {
      svg('rect', { x: r.x + 150 + i * 36, y: r.y + 14, width: 30, height: 40, rx: 3, class: 'furn' }, g);
      for (let k = 0; k < 3; k += 1) svg('rect', { x: r.x + 154 + i * 36, y: r.y + 20 + k * 11, width: 22, height: 4, class: 'furn2' }, g);
    }
    svg('rect', { x: r.x + 210, y: r.y + 110, width: 90, height: 44, rx: 8, class: 'furn' }, g);
  } else if (id === 'people') {
    for (let i = 0; i < 3; i += 1) svg('rect', { x: r.x + 160 + i * 26, y: r.y + 14, width: 22, height: 34, rx: 3, class: 'furn' }, g);
    svg('circle', { cx: r.x + 196, cy: r.y + 124, r: 26, class: 'furn' }, g);
  } else if (id === 'llm') {
    for (let i = 0; i < 3; i += 1) {
      svg('rect', { x: r.x + 160 + i * 28, y: r.y + 70, width: 22, height: 96, rx: 3, class: 'furn' }, g);
      for (let k = 0; k < 5; k += 1) svg('circle', { cx: r.x + 171 + i * 28, cy: r.y + 82 + k * 17, r: 2.6, class: 'led' }, g);
    }
  } else if (id === 'broker') {
    for (let row = 0; row < 3; row += 1) {
      for (let col = 0; col < 5; col += 1) svg('rect', { x: r.x + 200 + col * 24, y: r.y + 70 + row * 26, width: 20, height: 20, rx: 2, class: 'furn', 'data-slot': `${row}-${col}` }, g);
    }
  }
}
const cssId = (id) => String(id).replace(/[^a-z0-9]/gi, '_');

// ------------------------------------------------------------------ 상태 모델 (이벤트 → 처리 중/완료)

function model() {
  if (!S.dirty && S.model) return S.model;
  const skill = {};
  const callIndex = new Map();
  const traceRun = {};
  const pending = {};
  const lastFail = {};
  const llmCalls = [];
  const ensure = (n) => (skill[n] ||= { runs: new Map(), done: [] });
  for (const e of byTime(S.events)) {
    const n = e.node;
    switch (e.kind) {
      case 'skill.start': {
        const r = { start: e, progress: [], calls: [] };
        ensure(n).runs.set(e.task_id, r);
        (traceRun[n] ||= {})[e.trace_id] = r;
        break;
      }
      case 'skill.progress': ensure(n).runs.get(e.task_id)?.progress.push(e); break;
      case 'skill.end': {
        const s = ensure(n);
        const r = s.runs.get(e.task_id);
        if (r) { r.end = e; s.runs.delete(e.task_id); s.done.push(r); }
        if (e.state === 'failed') lastFail[n] = e.ts;
        break;
      }
      case 'a2a.request':
      case 'llm.request': {
        if (!e.call_id) break;
        const c = { req: e, res: null };
        callIndex.set(e.call_id, c);
        (pending[n] ||= new Map()).set(e.call_id, c);
        const r = traceRun[n]?.[e.trace_id];
        if (r && !r.end) r.calls.push(c);
        if (e.kind === 'llm.request') llmCalls.push(c);
        break;
      }
      case 'a2a.response':
      case 'llm.response': {
        const c = callIndex.get(e.call_id);
        if (c) { c.res = e; pending[n]?.delete(e.call_id); }
        if (BAD.includes(e.state)) lastFail[e.kind === 'llm.response' ? 'llm' : e.to] = e.ts;
        break;
      }
      default: break;
    }
  }
  const fresh = (ts) => sinceMs(ts) < 180000; // 3분 넘게 끝나지 않은 것은 기록 누락으로 보고 제외
  const out = { skill: {}, pending: {}, lastFail, llm: { running: [], done: [] } };
  for (const [n, s] of Object.entries(skill)) {
    out.skill[n] = { running: [...s.runs.values()].filter((r) => fresh(r.start.ts)).reverse(), done: s.done };
  }
  for (const [n, m] of Object.entries(pending)) out.pending[n] = [...m.values()].filter((c) => fresh(c.req.ts));
  for (const c of llmCalls) {
    if (c.res) out.llm.done.push(c);
    else if (fresh(c.req.ts)) out.llm.running.push(c);
  }
  out.llm.running.reverse();
  S.model = out;
  S.dirty = false;
  return out;
}

function avgDur(list, durOf) {
  const v = list.map(durOf).filter((x) => x != null);
  return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
}

// 구성원 1명의 현재 상태: { state, text, elapsed, ratio }
function actorStatus(id) {
  const m = model();
  const st = S.health[id] || {};
  if (id === 'llm') {
    const run = m.llm.running[0];
    const up = st.up;
    if (!up) return { state: 'off', text: '응답 없음' };
    if (run) {
      const avg = avgDur(m.llm.done.filter((c) => c.req.task === run.req.task), (c) => c.res.duration_ms) || 5000;
      const n = m.llm.running.length;
      return { state: 'work', text: `${TASK_KO[run.req.task] || run.req.task} 작성 중${n > 1 ? ` 외 ${n - 1}건` : ''}`,
        elapsed: sinceMs(run.req.ts), ratio: sinceMs(run.req.ts) / avg };
    }
    return { state: recentFail(m, 'llm') ? 'alert' : 'idle', text: lastDoneText(id) };
  }
  if (AGENTS.includes(id)) {
    if (!st.up) return { state: 'off', text: '응답 없음' };
    const sk = m.skill[id] || { running: [], done: [] };
    const run = sk.running[0];
    if (run) {
      const own = run.progress.filter((p) => !String(p.detail).startsWith('['));
      const last = own[own.length - 1];
      const waiting = run.calls.filter((c) => !c.res);
      let what;
      if (waiting.length) {
        what = waiting.map((c) => (c.req.kind === 'llm.request'
          ? `AI 작문실에 ${TASK_KO[c.req.task] || c.req.task} 요청`
          : `${actorName(c.req.to)}에 ${SKILL_KO[c.req.skill] || c.req.skill} 맡김`)).join(', ');
      } else {
        what = last ? stripAgent(last.detail) : `${SKILL_KO[run.start.skill] || run.start.skill} 처리 중`;
      }
      const avg = avgDur(sk.done.filter((r) => r.start.skill === run.start.skill), (r) => r.end.duration_ms) || 3000;
      const more = sk.running.length > 1 ? ` 외 ${sk.running.length - 1}건` : '';
      return { state: 'work', text: `${what}${more}`, elapsed: sinceMs(run.start.ts), ratio: sinceMs(run.start.ts) / avg };
    }
    return { state: recentFail(m, id) ? 'alert' : 'idle', text: lastDoneText(id) };
  }
  if (id.startsWith('desktop:')) {
    const uid = id.slice(8);
    const away = S.people[uid]?.status === 'away';
    if (!S.nodes[id]) return { state: 'off', text: away ? `부재 · ${S.people[uid].status_note}` : 'PC 비서 미실행 (요청은 보관됨)', away };
    if (!st.up) return { state: 'off', text: 'PC 꺼짐', away };
    if (st.offline) return { state: 'off', text: '오프라인 모드', away };
    const pend = m.pending[id] || [];
    if (pend.length) {
      const c = pend[pend.length - 1];
      const what = c.req.kind === 'llm.request'
        ? `사내 AI에 ${TASK_KO[c.req.task] || c.req.task} 요청 중`
        : `${actorName(c.req.to)}에 ${SKILL_KO[c.req.skill] || c.req.skill} 요청 중`;
      return { state: 'work', text: what, elapsed: sinceMs(c.req.ts), ratio: sinceMs(c.req.ts) / 6000, away };
    }
    return { state: 'idle', text: st.hub_connected ? '대기 · 요청함 연결됨' : '대기 · 연결 확인 중', away };
  }
  return { state: 'off', text: '' };
}

function recentFail(m, id) {
  const ts = m.lastFail[id];
  return ts && sinceMs(ts) < 20000;
}

function lastDoneText(id) {
  const m = model();
  if (id === 'llm') {
    const c = m.llm.done[m.llm.done.length - 1];
    return c ? `대기 · 최근 ${TASK_KO[c.req.task] || c.req.task} ${fmtDur(c.res.duration_ms)}` : '대기';
  }
  const d = m.skill[id]?.done;
  const r = d?.[d.length - 1];
  return r ? `대기 · 최근 ${SKILL_KO[r.start.skill] || r.start.skill} ${STATE_KO[r.end.state] || r.end.state} ${fmtDur(r.end.duration_ms)}` : '대기';
}

// ------------------------------------------------------------------ 화면 갱신 (0.5초마다)

function say(id, text, tone = 'ok', ms = 6000) {
  if (!id) return;
  S.say[id] = { text, tone, until: Date.now() + ms };
}

function renderLive() {
  if (!S.meta) return;
  const ids = [...AGENTS, ...Object.keys(desks)];
  let running = 0;
  for (const id of ids) {
    const a = actorStatus(id);
    if (a.state === 'work') running += 1;
    const av = document.getElementById(`av-${cssId(id)}`);
    if (av) av.setAttribute('class', `${desks[id] ? 'avatar ' : ''}s-${a.state}`);
    const tag = document.getElementById(`tag-${cssId(id)}`);
    if (tag) tag.style.setProperty('--c', COLOR[a.state]);
    if (desks[id]) {
      $(`[data-screen="${id}"]`)?.setAttribute('class', `screen s-${a.state}`);
      $(`[data-away="${id}"]`)?.setAttribute('visibility', a.away ? 'visible' : 'hidden');
    }
    // 말풍선: 일하는 중이면 진행 문장 + 경과 시간, 아니면 최근 소식(6초)
    const bub = document.getElementById(`bub-${cssId(id)}`);
    if (bub) {
      const s = S.say[id];
      if (a.state === 'work') {
        bub.className = 'bubble on t-work';
        bub.innerHTML = `${esc(a.text)} · <b>${fmtDur(a.elapsed)}</b>`;
      } else if (s && s.until > Date.now()) {
        bub.className = `bubble on t-${s.tone}`;
        bub.textContent = s.text;
      } else {
        bub.className = 'bubble';
      }
    }
  }
  // 관제 콘솔: 최근 콘솔 호출이 있으면 표시
  const cs = S.say.console;
  const cav = document.getElementById('av-console');
  if (cav) cav.setAttribute('class', cs && cs.until > Date.now() ? 's-work' : 's-idle');
  const cb = document.getElementById('bub-console');
  if (cb) {
    cb.className = cs && cs.until > Date.now() ? `bubble on t-${cs.tone}` : 'bubble';
    if (cs) cb.textContent = cs.text;
  }
  // AI 작문실 서버 LED
  const llmBusy = actorStatus('llm').state === 'work';
  $$('#floor .led').forEach((l) => l.classList.toggle('on', llmBusy));

  $('#headcount').textContent = ` · 운영 ${AGENTS.length} · 직원 ${Object.keys(desks).length} · 일하는 중 ${running}`;
  $('#clock').textContent = new Date().toLocaleTimeString('ko-KR');
  renderMembers();
  renderKpis();
  if (S.selected) renderDrawer();
}

function renderMembers() {
  const row = (id, name, role) => {
    const a = actorStatus(id);
    const pct = a.state === 'work' ? Math.min(95, Math.round((a.ratio || 0) * 100)) : 0;
    return `<div class="arow ${S.selected === id ? 'sel' : ''}" data-member="${esc(id)}" style="--c:${COLOR[a.state]}">
      <div class="a1"><span class="dot"></span><b>${esc(name)}</b><u>${esc(role)}</u></div>
      <div class="why">${esc(a.text)}${a.state === 'work' ? ` · <span class="el">${fmtDur(a.elapsed)}</span>` : ''}</div>
      <div class="prog"><i style="width:${pct}%"></i></div></div>`;
  };
  const agents = AGENTS.map((id) => row(id, id === 'hub' ? HUB.title : ROOMS[id].title,
    id === 'hub' ? 'Hub' : id === 'llm' ? 'vLLM' : ROOMS[id].role.replace(' Agent', ''))).join('');
  const people = Object.keys(desks).map((id) => {
    const u = S.meta.users.find((x) => x.id === id.slice(8));
    return row(id, u.name, u.team);
  }).join('');
  $('#members').innerHTML = `<div class="zonehead"><span>운영 서버</span><span>${AGENTS.length}</span></div>${agents}
    <div class="zonehead"><span>직원 PC</span><span>${Object.keys(desks).length}</span></div>${people}`;
  $('#memcount').textContent = ` ${AGENTS.length + Object.keys(desks).length}`;
  $$('#members [data-member]').forEach((el) => {
    el.onclick = () => {
      const id = el.dataset.member;
      if (AGENTS.includes(id)) openNode(id);
      else if (S.nodes[id]) window.open(S.nodes[id].url, '_blank');
    };
  });
}

function renderKpis() {
  const m = model();
  const servers = AGENTS.filter((id) => S.health[id]?.up).length;
  const done = Object.values(m.skill).flatMap((s) => s.done);
  const fails = done.filter((r) => BAD.includes(r.end.state)).length + m.llm.done.filter((c) => c.res.state !== 'completed').length;
  const running = Object.values(m.skill).reduce((a, s) => a + s.running.length, 0) + m.llm.running.length;
  const tokens = m.llm.done.reduce((a, c) => a + (c.res.completion_tokens || 0), 0);
  const answers = S.events.filter((e) => e.kind === 'a2a.response' && String(e.from).startsWith('desktop:') && e.duration_ms != null);
  const avg = avgDur(answers, (e) => e.duration_ms);
  const items = [
    ['가동', `${servers}/${AGENTS.length}`, servers < AGENTS.length],
    ['진행 중', running],
    ['처리 완료', done.filter((r) => r.end.state !== 'failed').length],
    ['실패·대체', fails, fails > 0],
    ['AI 생성 토큰', tokens.toLocaleString()],
    ['평균 응답', avg == null ? '-' : fmtDur(avg)],
  ];
  $('#kpis').innerHTML = items.map(([k, v, bad]) => `<div><b>${k}</b><span class="${bad ? 'bad' : ''}">${esc(v)}</span></div>`).join('');
}

// ------------------------------------------------------------------ 이동 애니메이션

const TOKEN = {
  req: { color: 'var(--blue)', shape: 'env' },
  ok: { color: 'var(--ok)', shape: 'doc' },
  bad: { color: 'var(--crit)', shape: 'doc' },
  wait: { color: 'var(--warn)', shape: 'doc' },
  ai: { color: 'var(--orange)', shape: 'spark' },
  mail: { color: 'var(--violet)', shape: 'env' },
};

function travel(from, to, kind, label = '', delay = 0) {
  const pts = pathBetween(from, to);
  if (!pts || S.paused) return;
  const segs = [];
  let total = 0;
  for (let i = 1; i < pts.length; i += 1) {
    const len = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    segs.push([pts[i - 1], pts[i], len]);
    total += len;
  }
  const dur = Math.min(1600, Math.max(600, total * 1.4));
  const t = TOKEN[kind];
  setTimeout(() => {
    const g = svg('g', { class: 'token' }, S.fx);
    if (t.shape === 'env') {
      svg('rect', { x: -9, y: -6.5, width: 18, height: 13, fill: t.color }, g);
      svg('path', { d: 'M-9 -6 0 1 9 -6', fill: 'none', stroke: '#fff', 'stroke-width': 1.5 }, g);
    } else if (t.shape === 'doc') {
      svg('rect', { x: -7, y: -9, width: 14, height: 18, fill: t.color }, g);
      svg('path', { d: 'M-4 -4h8M-4 0h8M-4 4h5', stroke: '#fff', 'stroke-width': 1.4 }, g);
    } else {
      svg('path', { d: 'M0 -10 2.4 -2.4 10 0 2.4 2.4 0 10 -2.4 2.4 -10 0 -2.4 -2.4z', fill: t.color }, g);
    }
    if (label) svg('text', { y: -14, 'text-anchor': 'middle', class: 'lab', fill: t.color }, g).textContent = label;
    const t0 = performance.now();
    const step = (now) => {
      const p = Math.min(1, (now - t0) / dur);
      const e = p < 0.5 ? 2 * p * p : 1 - ((-2 * p + 2) ** 2) / 2;
      let d = e * total;
      let x = pts[0][0];
      let y = pts[0][1];
      for (const [a, b, len] of segs) {
        if (d <= len) { x = a[0] + (b[0] - a[0]) * (d / len); y = a[1] + (b[1] - a[1]) * (d / len); break; }
        d -= len;
        [x, y] = b;
      }
      g.setAttribute('transform', `translate(${x},${y})`);
      if (p < 1) requestAnimationFrame(step);
      else g.remove();
    };
    requestAnimationFrame(step);
  }, delay);
}

// ------------------------------------------------------------------ 이벤트 → 애니메이션 / 말풍선 / 소식

function react(ev) {
  const to = ev.to;
  const from = ev.from;
  switch (ev.kind) {
    case 'a2a.request':
      travel(from, to, 'req', SKILL_KO[ev.skill] || ev.skill);
      if (from === 'console') say('console', `${actorName(to)}에 직접 호출`, 'accent', 4000);
      break;
    case 'a2a.response': {
      const kind = BAD.includes(ev.state) ? 'bad' : ev.state === 'input_required' ? 'wait' : 'ok';
      travel(to, from, kind);
      if (String(from).startsWith('desktop:')) say(from, BAD.includes(ev.state) ? `실패: ${ev.detail || ev.state}` : `결과 도착 · ${fmtDur(ev.duration_ms)}`, BAD.includes(ev.state) ? 'crit' : 'ok');
      break;
    }
    case 'llm.request': travel(from, 'llm', 'ai', TASK_KO[ev.task] || ev.task); break;
    case 'llm.response':
      travel('llm', from, ev.state === 'completed' ? 'ai' : 'bad');
      say('llm', `${TASK_KO[ev.task] || ev.task} 완성 · ${ev.completion_tokens}토큰 · ${fmtDur(ev.duration_ms)}`, ev.state === 'completed' ? 'ok' : 'warn');
      break;
    case 'skill.end':
      if (ev.state === 'failed') say(ev.node, `실패: ${ev.detail || ''}`, 'crit', 9000);
      else if (ev.state === 'input_required') say(ev.node, '답변 대기 Task 를 열어 두었어요', 'warn');
      else say(ev.node, `${SKILL_KO[ev.skill] || ev.skill} 완료 · ${fmtDur(ev.duration_ms)}`, 'ok');
      break;
    case 'inbox.publish':
      if (ev.delivered) {
        travel('broker', to, 'mail', ev.event === 'request.received' ? '새 요청' : '');
        say('broker', `${personName(to)}께 ${eventKo(ev.event)} 알림`, 'accent');
      } else {
        say('broker', `${personName(to)} PC 꺼짐 · 요청함에 보관`, 'warn');
        say(to, '요청함에 보관된 알림 있음', 'warn', 9000);
      }
      break;
    case 'inbox.received': say(ev.node, `${eventKo(ev.event)}!`, 'accent'); break;
    case 'inbox.connect': say(from, '요청함 연결됨', 'ok', 3000); break;
    case 'inbox.disconnect': say(from, '요청함 연결 끊김', 'warn', 4000); break;
    case 'desktop.intent':
      say(ev.node, ev.route === 'local' ? `내 PC에서 처리: ${INTENT_KO[ev.intent] || ev.intent}` : `요청 이해: ${INTENT_KO[ev.intent] || ev.intent}`, 'accent', 3500);
      break;
    case 'local.tool': say(ev.node, `내 PC: ${TOOL_KO[ev.tool] || ev.tool}${ev.hits != null ? ` ${ev.hits}건` : ''}`, 'ok', 4000); break;
    case 'user.approve': say(ev.node, `승인: ${ev.action}`, 'accent', 4000); break;
    case 'desktop.offline': say(ev.node, '오프라인 모드로 전환', 'warn'); break;
    case 'desktop.online': say(ev.node, '다시 연결됨', 'ok'); break;
    default: break;
  }
}

function eventKo(e) {
  return { 'request.received': '새 요청 도착', 'request.sent': '요청 발송 확인', 'request.answered': '답변 도착',
    'request.closed': '답변 완료 처리', 'request.reminded': '리마인드', notice: '공지' }[e] || e;
}

// 사무실 소식: 사람이 읽는 문장 (내부 단계 이벤트는 생략)
function sentence(ev) {
  const sk = SKILL_KO[ev.skill] || ev.skill;
  switch (ev.kind) {
    case 'a2a.request':
      if (ev.from === 'console') return ['var(--accent)', `<b>관제 콘솔</b>에서 ${esc(actorName(ev.to))}에 직접 호출 (${esc(sk)})`];
      if (String(ev.from).startsWith('desktop:')) return ['var(--blue)', `<b>${esc(personName(ev.from))}</b>이 ${esc(actorName(ev.to))}에 <b>${esc(sk)}</b>을 요청`];
      return ['var(--blue)', `${esc(actorName(ev.from))} → <b>${esc(actorName(ev.to))}</b>: ${esc(sk)} 맡김`];
    case 'a2a.response':
      if (BAD.includes(ev.state)) return ['var(--crit)', `<b>${esc(actorName(ev.to))}</b> ${esc(sk)} 실패 — ${esc(ev.detail || '')}`];
      if (String(ev.from).startsWith('desktop:')) return ['var(--ok)', `<b>${esc(personName(ev.from))}</b>에게 ${esc(sk)} 결과 도착 (${fmtDur(ev.duration_ms)})`];
      return null;
    case 'skill.progress':
      return ev.node === 'hub' ? null : ['var(--muted)', `${esc(actorName(ev.node))}: ${esc(stripAgent(ev.detail))}`];
    case 'llm.request':
      return ['var(--orange)', `${esc(actorName(ev.from))} → <b>AI 작문실</b>: ${esc(TASK_KO[ev.task] || ev.task)} (입력 ${ev.prompt_tokens}토큰)`];
    case 'llm.response':
      return [ev.state === 'completed' ? 'var(--orange)' : 'var(--warn)',
        `<b>AI 작문실</b> ${esc(TASK_KO[ev.task] || ev.task)} ${ev.state === 'completed' ? '완성' : '대체 응답'} · ${ev.completion_tokens}토큰 · ${fmtDur(ev.duration_ms)}`];
    case 'inbox.publish':
      return ev.delivered ? ['var(--violet)', `요청 우편실 → <b>${esc(personName(ev.to))}</b>: ${eventKo(ev.event)}`]
        : ['var(--warn)', `<b>${esc(personName(ev.to))}</b> PC 가 꺼져 있어 ${eventKo(ev.event)} 알림을 보관`];
    case 'user.approve': return ['var(--accent)', `<b>${esc(personName(ev.node))}</b>이 '${esc(ev.action)}'을 승인`];
    case 'desktop.intent':
      return ['var(--muted)', `${esc(actorName(ev.node))}: '${esc(INTENT_KO[ev.intent] || ev.intent)}'(으)로 이해${ev.route === 'local' ? ' · 내 PC 에서 처리' : ''}`];
    case 'local.tool': return ['var(--ok)', `${esc(actorName(ev.node))}: ${esc(TOOL_KO[ev.tool] || ev.tool)}${ev.hits != null ? ` ${ev.hits}건` : ''} (PC 안에서만)`];
    case 'inbox.connect': return ['var(--ok)', `${esc(actorName(ev.from))} 요청함 연결`];
    case 'inbox.disconnect': return ['var(--muted)', `${esc(actorName(ev.from))} 요청함 연결 끊김`];
    case 'desktop.offline': return ['var(--warn)', `${esc(actorName(ev.node))} 오프라인 모드`];
    case 'desktop.online': return ['var(--ok)', `${esc(actorName(ev.node))} 다시 연결`];
    case 'skill.end': return ev.state === 'failed' ? ['var(--crit)', `<b>${esc(actorName(ev.node))}</b> ${esc(sk)} 실패: ${esc(ev.detail || '')}`] : null;
    default: return null;
  }
}

function newsHtml(ev, isNew) {
  const s = sentence(ev);
  if (!s) return '';
  const t = (ev.ts || '').slice(11, 19);
  return `<div class="news ${ev.trace_id ? 'clk' : ''} ${isNew ? 'new' : ''}" ${ev.trace_id ? `data-trace="${esc(ev.trace_id)}"` : ''} style="--c:${s[0]}">
    <span class="t">${esc(t)}</span><span class="d"></span><span class="x">${s[1]}</span></div>`;
}

function renderFeed() {
  const html = S.events.slice(-400).reverse().map((e) => newsHtml(e, false)).filter(Boolean).slice(0, 120).join('');
  $('#feed').innerHTML = html || '<div class="empty">아직 소식이 없어요. 직원 PC 에서 질문하거나 요청을 보내 보세요.</div>';
  bindTraceLinks($('#feed'));
}

function addNews(ev) {
  const html = newsHtml(ev, true);
  if (!html) return;
  const feed = $('#feed');
  if (feed.querySelector('.empty')) feed.innerHTML = '';
  feed.insertAdjacentHTML('afterbegin', html);
  bindTraceLinks(feed.firstElementChild);
  while (feed.children.length > 120) feed.lastElementChild.remove();
}

function bindTraceLinks(el) {
  if (!el) return;
  const nodes = el.matches?.('[data-trace]') ? [el] : [];
  nodes.push(...$$('[data-trace]', el));
  nodes.forEach((n) => { n.onclick = (e) => { e.stopPropagation(); selectTrace(n.dataset.trace); }; });
}

// ------------------------------------------------------------------ 초기화 / 이벤트 수신

async function init() {
  S.meta = await api('/_console/meta');
  const n = await api('/api/nodes');
  S.nodes = n.nodes;
  S.health = n.health;
  $('#quick').innerHTML = '<span>바로가기</span>' + Object.entries(S.nodes)
    .map(([id, x]) => `<a href="${esc(x.kind === 'desktop' ? x.url : `${x.url}/`)}" target="_blank">${esc(actorName(id))}</a>`).join('');
  drawFloor();
  S.events = await api('/api/events');
  S.dirty = true;
  S.trace = new URLSearchParams(location.search).get('trace');
  renderFeed();
  renderRaw();
  renderTrace();
  await Promise.all([loadRequests(), loadPeople()]);
  setInterval(loadRequests, 10000);
  setInterval(loadPeople, 8000);
  setInterval(renderLive, 500);
  setInterval(loadDemo, 10000); // 자동 시연이 꺼지면 배너를 숨김
  renderLive();
  loadDemo();
  connect();

  $('#pause').onclick = () => {
    S.paused = !S.paused;
    $('#pause').setAttribute('aria-pressed', String(S.paused));
    $('#pause').textContent = S.paused ? `기록 재개 (${S.buffer.length})` : '기록 멈춤';
    if (!S.paused) {
      S.events.push(...S.buffer);
      S.buffer = [];
      S.dirty = true;
      renderFeed();
      renderRaw();
      renderTrace();
    }
  };
  $('#clear').onclick = () => { if (confirm('관제 기록을 모두 지울까요?')) post('/api/clear'); };
  $('#drawer-close').onclick = closeNode;
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeNode(); });
  $$('.tabs button').forEach((b) => { b.onclick = () => showTab(b.dataset.tab); });
  renderFilters();
}

function connect() {
  const es = new EventSource('/api/stream');
  es.onopen = () => $('#live').classList.remove('off');
  es.onerror = () => $('#live').classList.add('off');
  es.addEventListener('hello', (e) => { S.health = JSON.parse(e.data).health; });
  es.addEventListener('health', (e) => { S.health = JSON.parse(e.data); });
  es.addEventListener('demo', (e) => { Object.assign(S.demo, JSON.parse(e.data)); renderDemo(); });
  es.addEventListener('cleared', () => {
    S.events = [];
    S.dirty = true;
    S.trace = null;
    renderFeed();
    renderRaw();
    renderTrace();
  });
  es.addEventListener('event', (e) => {
    const ev = JSON.parse(e.data);
    if (ev.node === 'demo') { showDemo(ev); return; }
    if (S.paused) {
      S.buffer.push(ev);
      $('#pause').textContent = `기록 재개 (${S.buffer.length})`;
      return;
    }
    S.events.push(ev);
    if (S.events.length > 3000) S.events.shift();
    S.dirty = true;
    react(ev);
    addNews(ev);
    appendRaw(ev);
    if (ev.kind === 'inbox.publish') requestsLater();
    if (ev.trace_id && ev.trace_id === S.trace) traceLater();
  });
}

const requestsLater = debounce(() => loadRequests(), 400);
const traceLater = debounce(() => renderTrace(), 200);

async function loadPeople() {
  try {
    const d = await api('/api/nodes/people/detail');
    const list = d.sources['/admin/people'] || [];
    S.people = Object.fromEntries(list.map((p) => [p.user_id, p]));
  } catch { /* People 미가동 */ }
}

// ------------------------------------------------------------------ 아래 탭

function showTab(name) {
  $$('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
  $$('.lower .pane').forEach((p) => p.classList.toggle('hidden', p.id !== `pane-${name}`));
}

function selectTrace(t) {
  S.trace = t;
  showTab('trace');
  renderTrace();
  renderRaw();
  $('.lower').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function loadRequests() {
  try { S.requests = await api('/api/requests'); } catch { S.requests = []; }
  const rows = S.requests.map((r) => `<tr>
    <td>${r.status === 'waiting' ? '<span class="tag warn">답변 대기</span>' : '<span class="tag ok">답변 완료</span>'}</td>
    <td><b>${esc(r.title)}</b></td><td>${esc(r.from_user.name)} → <b>${esc(r.to_user.name)}</b></td>
    <td class="muted">${esc(r.routed_reason)}</td><td>${esc((r.created_at || '').slice(5, 16).replace('T', ' '))}</td>
    <td>${esc((r.answered_at || '').slice(5, 16).replace('T', ' ')) || '-'}</td>
    <td>${chip(r.trace_id, '생성 ')} ${chip(r.reply_trace_id, '답변 ')}</td></tr>`).join('');
  $('#requests').innerHTML = `<table class="m"><thead><tr><th>상태</th><th>제목</th><th>보낸 사람 → 받는 사람</th><th>지정 사유</th><th>생성</th><th>답변</th><th>흐름</th></tr></thead>
    <tbody>${rows || '<tr><td colspan="7" class="muted">아직 담당자 요청이 없습니다.</td></tr>'}</tbody></table>`;
  bindTraceLinks($('#requests'));
}

// ---- 원본 로그 (개발자용)

const group = (k) => (k.startsWith('a2a.') ? 'a2a' : k.startsWith('skill.') ? 'skill'
  : k.startsWith('inbox.') ? 'inbox' : k.startsWith('llm.') ? 'llm' : 'local');
const GROUP_LABEL = { a2a: 'A2A', skill: 'Skill', inbox: '요청함', llm: 'LLM', local: 'PC 로컬' };
const visible = (ev) => S.filters[group(ev.kind)] && (!S.trace || ev.trace_id === S.trace);

function renderFilters() {
  $('#filters').innerHTML = Object.entries(GROUP_LABEL).map(([k, v]) =>
    `<label><input type="checkbox" data-f="${k}" ${S.filters[k] ? 'checked' : ''}> ${v}</label>`).join('')
    + '<span class="muted">· 업무 흐름 탭에서 고른 trace 만 표시됩니다</span>';
  $$('[data-f]').forEach((c) => { c.onchange = () => { S.filters[c.dataset.f] = c.checked; renderRaw(); }; });
}

function rawRow(ev) {
  const flow = ev.from && ev.to ? `${esc(actorName(ev.from))} → ${esc(actorName(ev.to))}` : '';
  const d = [ev.skill, ev.task, ev.event, ev.intent, ev.tool, ev.action, ev.state, ev.duration_ms != null ? `${ev.duration_ms}ms` : '', ev.detail]
    .filter(Boolean).map(esc).join(' · ');
  return `<tr><td class="mono">${esc((ev.ts || '').slice(11, 23))}</td><td>${chip(ev.trace_id)}</td><td>${esc(actorName(ev.node))}</td>
    <td class="mono">${esc(ev.kind)}</td><td>${flow}</td><td>${d}</td></tr>`;
}
function renderRaw() {
  const tb = $('#rawlog tbody');
  tb.innerHTML = S.events.filter(visible).slice(-400).reverse().map(rawRow).join('') || '<tr><td colspan="6" class="muted">이벤트 없음</td></tr>';
  bindTraceLinks(tb);
}
function appendRaw(ev) {
  if (!visible(ev)) return;
  const tb = $('#rawlog tbody');
  if (tb.rows.length === 1 && tb.rows[0].cells.length === 1) tb.innerHTML = '';
  tb.insertAdjacentHTML('afterbegin', rawRow(ev));
  bindTraceLinks(tb.firstElementChild);
  while (tb.rows.length > 400) tb.deleteRow(-1);
}

// ---- 업무 흐름 (trace 순서도)

const ORDER = ['console', 'desktop:u001', 'desktop:u002', 'desktop:u003', 'desktop:u004', 'desktop:u005', 'desktop:u006', 'hub', 'llm', 'knowledge', 'people', 'broker'];

function traceSteps(evs) {
  const steps = [];
  const parts = new Set();
  const use = (id) => { if (id) parts.add(id); return id; };
  for (const e of evs) {
    const base = { ts: e.ts };
    switch (e.kind) {
      case 'a2a.request': steps.push({ ...base, type: 'msg', from: use(e.from), to: use(e.to), label: `${SKILL_KO[e.skill] || e.skill} 요청`, color: 'var(--blue)' }); break;
      case 'a2a.response':
        steps.push({ ...base, type: 'msg', from: use(e.to), to: use(e.from), dashed: true, label: `${STATE_KO[e.state] || e.state} · ${fmtDur(e.duration_ms)}`,
          color: BAD.includes(e.state) ? 'var(--crit)' : e.state === 'input_required' ? 'var(--warn)' : 'var(--ok)' });
        break;
      case 'llm.request': steps.push({ ...base, type: 'msg', from: use(e.from), to: use('llm'), label: `${TASK_KO[e.task] || e.task} (입력 ${e.prompt_tokens}토큰)`, color: 'var(--orange)' }); break;
      case 'llm.response':
        steps.push({ ...base, type: 'msg', from: use('llm'), to: use(e.from), dashed: true,
          label: `${e.completion_tokens}토큰 · 첫 글자 ${fmtDur(e.ttft_ms)} · ${fmtDur(e.duration_ms)}`, color: e.state === 'completed' ? 'var(--orange)' : 'var(--crit)' });
        break;
      case 'inbox.publish': steps.push({ ...base, type: 'msg', from: use('broker'), to: use(e.to), dashed: true, label: `${eventKo(e.event)}${e.delivered ? '' : ' (보관)'}`, color: 'var(--violet)' }); break;
      case 'skill.progress': steps.push({ ...base, type: 'note', at: use(e.node), label: stripAgent(e.detail), color: 'var(--muted)' }); break;
      case 'skill.end': if (e.state === 'failed') steps.push({ ...base, type: 'note', at: use(e.node), label: `실패: ${e.detail || ''}`, color: 'var(--crit)' }); break;
      case 'desktop.intent': steps.push({ ...base, type: 'note', at: use(e.node), label: `이해: ${INTENT_KO[e.intent] || e.intent}${e.route === 'local' ? ' · 내 PC 처리' : ''}`, color: 'var(--accent)' }); break;
      case 'local.tool': steps.push({ ...base, type: 'note', at: use(e.node), label: `내 PC: ${TOOL_KO[e.tool] || e.tool}${e.hits != null ? ` ${e.hits}건` : ''}`, color: 'var(--ok)' }); break;
      case 'user.approve': steps.push({ ...base, type: 'note', at: use(e.node), label: `승인: ${e.action}`, color: 'var(--accent)' }); break;
      case 'inbox.received': steps.push({ ...base, type: 'note', at: use(e.node), label: `수신: ${eventKo(e.event)}`, color: 'var(--violet)' }); break;
      default: break;
    }
  }
  const cols = ORDER.filter((p) => parts.has(p)).concat([...parts].filter((p) => !ORDER.includes(p)));
  return { steps, cols };
}

function renderTrace() {
  const box = $('#seq');
  if (!S.trace) {
    $('#trace-head').innerHTML = '<span class="muted">사무실 소식이나 요청 현황에서 항목을 누르면, 그 일이 누구를 거쳐 어떻게 처리됐는지 순서대로 보여줍니다.</span>';
    box.innerHTML = '';
    $('#trace-raw').textContent = '';
    return;
  }
  const evs = byTime(S.events.filter((e) => e.trace_id === S.trace));
  const { steps, cols } = traceSteps(evs);
  const t0 = evs.length ? tsMs(evs[0].ts) : 0;
  const total = evs.length ? tsMs(evs[evs.length - 1].ts) - t0 : 0;
  $('#trace-head').innerHTML = `${chip(S.trace)} <b>${cols.map((c) => esc(actorName(c))).join(' · ')}</b>
    <span class="muted">· ${steps.length}단계 · 총 ${fmtDur(total)}</span> <button class="btn ghost" id="untrace">닫기</button>`;
  $('#untrace').onclick = () => { S.trace = null; renderTrace(); renderRaw(); };

  const COLW = Math.max(120, Math.min(170, Math.floor((box.clientWidth - 280) / Math.max(cols.length, 1))));
  const ROWH = 32;
  const TOP = 54;
  const LEFT = 70;
  const W = LEFT + cols.length * COLW + 220;
  const H = TOP + steps.length * ROWH + 20;
  const x = (id) => LEFT + cols.indexOf(id) * COLW + COLW / 2;
  const root = svg('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}` });
  cols.forEach((id) => {
    svg('line', { class: 'life', x1: x(id), y1: 42, x2: x(id), y2: H - 6 }, root);
    const g = svg('g', { class: 'ph' }, root);
    svg('rect', { x: x(id) - COLW / 2 + 8, y: 8, width: COLW - 16, height: 30 }, g);
    svg('text', { x: x(id), y: 28, 'text-anchor': 'middle' }, g).textContent = actorName(id);
  });
  steps.forEach((s, i) => {
    const y = TOP + i * ROWH + 14;
    svg('text', { x: 6, y: y + 4, class: 'time' }, root).textContent = `+${fmtDur(tsMs(s.ts) - t0)}`;
    if (s.type === 'msg') {
      const x1 = x(s.from);
      const x2 = x(s.to);
      const g = svg('g', { class: 'msg' }, root);
      svg('line', { x1, y1: y, x2, y2: y, stroke: s.color, 'stroke-width': 2, ...(s.dashed ? { 'stroke-dasharray': '5 4' } : {}) }, g);
      const d = Math.sign(x2 - x1) || 1;
      svg('polygon', { points: `${x2},${y} ${x2 - 9 * d},${y - 5} ${x2 - 9 * d},${y + 5}`, fill: s.color }, g);
      svg('text', { x: (x1 + x2) / 2, y: y - 6, 'text-anchor': 'middle' }, g).textContent = s.label;
    } else {
      const cx = x(s.at);
      const label = s.label.length > 40 ? `${s.label.slice(0, 40)}…` : s.label;
      const g = svg('g', { class: 'note' }, root);
      svg('rect', { x: cx + 6, y: y - 11, width: Math.min(360, 16 + label.length * 11.5), height: 22, rx: 6, fill: 'var(--surface)', stroke: s.color }, g);
      svg('text', { x: cx + 14, y: y + 4, fill: s.color === 'var(--muted)' ? 'var(--ink-2)' : s.color }, g).textContent = label;
    }
  });
  box.innerHTML = '';
  box.append(root);
  $('#trace-raw').textContent = JSON.stringify(evs, null, 2);
}

// ------------------------------------------------------------------ 방 세부 패널

function openNode(id) {
  S.selected = id;
  S.detail = null;
  $('#drawer').classList.remove('hidden');
  document.body.classList.add('drawer-open');
  $$('#floor .room').forEach((g) => g.classList.toggle('sel', g.dataset.room === id));
  renderDrawer();
  loadDetail();
  clearInterval(S.detailPoll);
  S.detailPoll = setInterval(loadDetail, 3000);
}

function closeNode() {
  S.selected = null;
  $('#drawer').classList.add('hidden');
  document.body.classList.remove('drawer-open');
  clearInterval(S.detailPoll);
  $$('#floor .room').forEach((g) => g.classList.remove('sel'));
}

async function loadDetail() {
  const id = S.selected;
  if (!id) return;
  try {
    const d = await api(`/api/nodes/${encodeURIComponent(id)}/detail`);
    if (S.selected === id) S.detail = d;
  } catch { S.detail = null; }
  renderDrawer();
}

function callLine(c, t0) {
  const e = c.req;
  const isLlm = e.kind === 'llm.request';
  const what = isLlm ? `AI 작문실 · ${esc(TASK_KO[e.task] || e.task)}` : `${esc(actorName(e.to))} · ${esc(SKILL_KO[e.skill] || e.skill)}`;
  let status;
  if (!c.res) status = `<span class="pulse-dot"></span> <b>${isLlm ? '작성 중' : '진행 중'} ${fmtDur(sinceMs(e.ts))}</b>`;
  else {
    const extra = isLlm ? ` · ${c.res.completion_tokens}토큰` : '';
    status = `<span class="tag ${BAD.includes(c.res.state) ? 'bad' : c.res.state === 'input_required' ? 'warn' : 'ok'}">${esc(STATE_KO[c.res.state] || c.res.state)}</span> ${fmtDur(c.res.duration_ms)}${extra}`;
  }
  return { ts: e.ts, html: `<li><span class="t">+${fmtDur(tsMs(e.ts) - t0)}</span><span class="call">→ ${what}</span> ${status}</li>` };
}

function runCard(r) {
  const s = r.start;
  const t0 = tsMs(s.ts);
  const lines = [
    ...r.progress.map((p) => ({ ts: p.ts, html: `<li><span class="t">+${fmtDur(tsMs(p.ts) - t0)}</span>${esc(stripAgent(p.detail))}</li>` })),
    ...r.calls.map((c) => callLine(c, t0)),
  ].sort((a, b) => (a.ts < b.ts ? -1 : 1));
  return `<div class="run"><div class="run-head"><b>${esc(SKILL_KO[s.skill] || s.skill)}</b>
      <span class="muted">${esc(userName(s.user))}님 요청</span><span class="elapsed">${fmtDur(sinceMs(s.ts))}</span></div>
    <div class="muted" style="font-size:12px">${chip(s.trace_id)} ${s.continued ? '· 열려 있던 요청 Task 이어서 처리' : ''}</div>
    <ol class="timeline">${lines.map((l) => l.html).join('') || '<li class="muted">접수됨</li>'}</ol></div>`;
}

function llmCard(c) {
  const e = c.req;
  return `<div class="run" style="border-left-color:var(--orange)"><div class="run-head"><b>${esc(TASK_KO[e.task] || e.task)}</b>
      <span class="muted">${esc(actorName(e.from))} 요청 · 입력 ${e.prompt_tokens}토큰</span><span class="elapsed" style="color:var(--orange)">${fmtDur(sinceMs(e.ts))}</span></div>
    <div class="muted" style="font-size:12px">${chip(e.trace_id)}</div></div>`;
}

function table(rows, cols) {
  if (!rows.length) return '<p class="muted" style="font-size:13px">아직 기록이 없어요</p>';
  return `<table class="m"><thead><tr>${cols.map((c) => `<th>${c}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}

function stats(items, keyOf, durOf, errOf, label) {
  const g = {};
  for (const it of items) {
    const k = keyOf(it);
    g[k] ||= { n: 0, sum: 0, max: 0, err: 0 };
    const d = durOf(it) || 0;
    g[k].n += 1;
    g[k].sum += d;
    g[k].max = Math.max(g[k].max, d);
    if (errOf(it)) g[k].err += 1;
  }
  return table(Object.entries(g).sort((a, b) => b[1].n - a[1].n)
    .map(([k, v]) => [esc(label(k)), v.n, fmtDur(v.sum / v.n), fmtDur(v.max), v.err || '-']), ['업무', '건수', '평균', '최대', '실패']);
}

function serverState(id) {
  const det = S.detail;
  if (!det) return '<p class="muted">불러오는 중…</p>';
  const s = det.sources;
  const st = S.health[id] || {};
  if (id === 'hub') {
    const o = s['/admin/overview'];
    if (!o) return '<p class="muted">응답 없음</p>';
    return `<div class="kv"><span>사용 중인 AI</span><b>${esc(o.llm.model)}</b>
        <span>요청함 연결</span><b>${o.connections.length ? o.connections.map((c) => `${esc(c.name)}님`).join(', ') : '없음'}</b></div>
      ${table(o.agents.map((a) => [esc(actorName({ 'Knowledge Agent': 'knowledge', 'People Agent': 'people', 'Request Broker Agent': 'broker' }[a.name] || a.name)),
        a.status === 'up' ? '<span class="tag ok">정상</span>' : '<span class="tag bad">응답 없음</span>',
        (a.skills || []).map((k) => esc(SKILL_KO[k.id] || k.id)).join(', ')]), ['맡길 수 있는 곳', '상태', '할 수 있는 일'])}`;
  }
  if (id === 'knowledge') {
    const docs = s['/admin/docs'];
    if (!docs) return '<p class="muted">응답 없음</p>';
    const pub = docs.filter((d) => d.acl.includes('all')).length;
    return `<div class="kv"><span>보유 문서</span><b>${docs.length}건</b><span>전체 공개</span><b>${pub}건</b><span>권한 제한</span><b>${docs.length - pub}건</b></div>`;
  }
  if (id === 'people') {
    const ppl = s['/admin/people'];
    if (!ppl) return '<p class="muted">응답 없음</p>';
    const away = ppl.filter((p) => p.status === 'away');
    return `<div class="kv"><span>담당자</span><b>${ppl.length}명</b><span>부재</span><b>${away.length}명</b></div>
      ${away.length ? table(away.map((p) => [esc(p.name), esc(p.status_note), p.backup ? `${esc(p.backup.name)}님이 대신` : '-']), ['부재자', '사유', '대리']) : ''}`;
  }
  if (id === 'broker') {
    const reqs = s['/admin/requests'] || [];
    const subs = s['/admin/subscribers'] || [];
    const waiting = reqs.filter((r) => r.status === 'waiting');
    return `<div class="kv"><span>답변 대기</span><b>${waiting.length}건</b><span>요청함 연결</span><b>${subs.filter((u) => u.connections).map((u) => `${esc(u.name)}님`).join(', ') || '없음'}</b></div>
      ${waiting.length ? table(waiting.slice(0, 8).map((r) => [esc(r.title), `${esc(r.from_user.name)} → <b>${esc(r.to_user.name)}</b>`,
        fmtDur(Date.now() - new Date(r.created_at).getTime()), chip(r.trace_id)]), ['답변 기다리는 요청', '보낸 → 받는', '기다린 시간', '흐름']) : ''}`;
  }
  if (id === 'llm') {
    const v = s['/admin/status'];
    if (!v) return `<div class="kv"><span>생성 중</span><b>${st.running ?? '-'}건</b><span>대기</span><b>${st.waiting ?? '-'}건</b></div>`;
    return `<div class="kv"><span>모델</span><b>${esc(v.model)}</b><span>생성 중</span><b>${v.stats.running}건</b>
      <span>속도 설정</span><b>x${v.settings.speed} · 초당 ${v.settings.decode_tps}토큰 생성</b>
      <span>누적</span><b>${v.stats.total}건 · 생성 ${v.stats.completion_tokens.toLocaleString()}토큰</b></div>`;
  }
  return '';
}

function renderDrawer() {
  const id = S.selected;
  if (!id) return;
  const m = model();
  const isLlm = id === 'llm';
  const info = id === 'hub' ? HUB : ROOMS[id];
  const node = S.nodes[id] || {};
  const a = actorStatus(id);
  $('#drawer-title').textContent = info.title;
  $('#drawer-sub').innerHTML = `${esc(info.role)} · <span style="color:${COLOR[a.state]}">● ${a.state === 'work' ? '일하는 중' : a.state === 'off' ? '응답 없음' : a.state === 'alert' ? '최근 실패' : '대기'}</span>`;
  $('#drawer-links').innerHTML = `<a href="${esc(node.url)}/" target="_blank">운영 콘솔 ↗</a>`;
  const body = $('#drawer-body');
  const scroll = body.scrollTop;

  const running = isLlm ? m.llm.running : (m.skill[id]?.running || []);
  const done = isLlm ? m.llm.done : (m.skill[id]?.done || []);
  const runHtml = running.length ? running.map((r) => (isLlm ? llmCard(r) : runCard(r))).join('')
    : '<p class="muted" style="font-size:13px">지금 처리 중인 일이 없어요. 직원 PC 에서 질문하면 여기에 실시간으로 나타납니다.</p>';
  const recent = done.slice(-10).reverse();
  const recentHtml = isLlm
    ? table(recent.map((c) => [esc(c.res.ts.slice(11, 19)), esc(TASK_KO[c.req.task] || c.req.task), esc(actorName(c.req.from)),
      `${c.res.completion_tokens}토큰`, fmtDur(c.res.duration_ms), chip(c.req.trace_id)]), ['시각', '업무', '요청한 곳', '생성', '시간', '흐름'])
    : table(recent.map((r) => [esc(r.end.ts.slice(11, 19)), esc(SKILL_KO[r.start.skill] || r.start.skill), `${esc(userName(r.start.user))}님`,
      `<span class="tag ${BAD.includes(r.end.state) ? 'bad' : r.end.state === 'input_required' ? 'warn' : 'ok'}">${esc(STATE_KO[r.end.state] || r.end.state)}</span>`,
      fmtDur(r.end.duration_ms), chip(r.start.trace_id)]), ['시각', '업무', '요청자', '결과', '시간', '흐름']);
  const statHtml = isLlm
    ? stats(done, (c) => c.req.task, (c) => c.res.duration_ms, (c) => c.res.state !== 'completed', (k) => TASK_KO[k] || k)
    : stats(done, (r) => r.start.skill, (r) => r.end.duration_ms, (r) => BAD.includes(r.end.state), (k) => SKILL_KO[k] || k);

  body.innerHTML = `<h4>${running.length ? '<span class="pulse-dot"></span>' : ''} 지금 처리 중 ${running.length}건</h4>${runHtml}
    <h4>현재 상태</h4>${serverState(id)}
    <h4>최근 처리</h4>${recentHtml}
    <h4>업무별 통계</h4>${statHtml}`;
  bindTraceLinks(body);
  body.scrollTop = scroll;
}


// ------------------------------------------------------------------ 자동 시연 해설 (scripts/autoplay.py)

S.demo = { paused: false, running: false, last: null };

function showDemo(ev) {
  S.demo.last = ev;
  S.demo.running = true;
  renderDemo();
}

function renderDemo() {
  const b = $('#demo-banner');
  const { paused, running, last: ev } = S.demo;
  if (!running || !ev) { b.classList.add('hidden'); return; }
  const dots = ev.total
    ? `<span class="dots">${Array.from({ length: ev.total }, (_, i) => `<i class="${i + 1 < ev.step ? 'done' : i + 1 === ev.step ? 'on' : ''}"></i>`).join('')}</span>`
    : '';
  const stepno = ev.kind === 'demo.step' ? `<span class="stepno">${ev.step}/${ev.total}</span>` : '';
  // 단계 진행 중에 누르면 그 단계가 끝난 뒤 멈춘다
  const note = paused && ev.kind !== 'demo.paused' ? '<span class="note">이 단계가 끝나면 멈춥니다</span>' : '';
  b.classList.toggle('paused', paused);
  b.innerHTML = `<span class="badge">${paused ? 'PAUSED' : 'AUTO DEMO'}</span>${stepno}<span>${esc(ev.detail || '')}</span>${note}`
    + `<span class="sp"></span>${dots}`
    + `<button class="demo-btn" id="demo-toggle" aria-pressed="${paused}">${paused ? '▶ 다시 재생' : '❚❚ 시연 일시정지'}</button>`;
  b.classList.remove('hidden');
}

async function loadDemo() {
  try { Object.assign(S.demo, await api('/api/demo')); } catch { /* 관제 서버 재시작 중 */ }
  renderDemo();
}

$('#demo-banner').addEventListener('click', async (e) => {
  if (!e.target.closest('#demo-toggle')) return;
  Object.assign(S.demo, await post('/api/demo', { paused: !S.demo.paused }));
  renderDemo();
});

init();