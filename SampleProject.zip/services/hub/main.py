"""운영 Hub (A2A Gateway + Orchestrator) - PC Agent 가 접속하는 유일한 서버 진입점.

A2A
- GET  /.well-known/agent-card.json   : Hub Agent Card (공개)
- POST /a2a                            : JSON-RPC (Bearer 필수)
    skill: knowledge-search, people-lookup, weekly-report-submit, request-create, request-reply

LLM 은 PC/서버 Agent 가 사내 vLLM(OpenAI 호환)을 직접 호출한다 (Hub 를 거치지 않음).

REST 확장 (Bearer 필수)
- GET  /api/inbox, /api/inbox/stream   : 수신함 동기화 / SSE (Request Broker 프록시)
- GET  /api/people                     : 담당자 목록 (요청 작성 화면용)

운영 확인용 (목업: 인증 없음)
- GET  /                               : 운영 콘솔 화면
- GET  /registry, /admin/overview      : 연결된 하위 Agent/skill, PC 수신함 연결 현황

실행: python -m uvicorn services.hub.main:app --port 9000
"""

from datetime import datetime
from pathlib import Path

import httpx
from fastapi import Depends, Request
from fastapi.responses import StreamingResponse

from common import telemetry
from common.a2a_kit import A2AConnector, SkillRouterExecutor, build_agent_card, create_agent_app
from common.auth import Principal, auth_headers, directory, require_principal
from common.config import DOWNSTREAM_AGENT_URLS, HUB_URL, VLLM_BASE_URL, VLLM_MODEL
from common.llm import get_llm
from common.logs import setup_logging
from services.hub.orchestrator import Orchestrator
from services.hub.registry import AgentRegistry

setup_logging("hub")

connector = A2AConnector()
registry = AgentRegistry(connector, DOWNSTREAM_AGENT_URLS)
orchestrator = Orchestrator(connector, registry)
proxy_http = httpx.AsyncClient(timeout=httpx.Timeout(10.0, read=None))

card = build_agent_card(
    name="Ops Hub Agent",
    description="사내 운영 Orchestrator. 지식 검색, 담당자 조회, 주간보고, 담당자 요청을 하위 Agent 에 위임합니다.",
    base_url=HUB_URL,
    skills=[
        {"id": "knowledge-search", "name": "사내 지식 질의응답",
         "description": "사내 문서 근거 답변 + 관련 담당자", "examples": ["결제 장애 대응 절차 알려줘"]},
        {"id": "people-lookup", "name": "담당자 조회",
         "description": "업무 키워드/이름으로 담당자와 현재 작업 조회", "examples": ["배포 담당자 누구야?"]},
        {"id": "weekly-report-submit", "name": "주간보고 업로드",
         "description": "사용자가 승인한 주간보고(text+json)를 접수"},
        {"id": "request-create", "name": "담당자 요청 전달",
         "description": "업무 키워드로 담당자를 찾아(부재 시 대리 담당자) 요청을 전달"},
        {"id": "request-reply", "name": "요청 답변",
         "description": "받은 요청에 답변 (data.request_id 필수)"},
    ],
)

app = create_agent_app(
    card,
    SkillRouterExecutor("hub", orchestrator.handlers, classifier=orchestrator.classify),
    node="hub",
    console_html=Path(__file__).parent / "console.html",
)

# 현재 열려 있는 PC 수신함 연결 (user_id -> 연결 시각 목록)
connections: dict[str, list[str]] = {}


def _trace(request: Request) -> str | None:
    return request.headers.get("x-trace-id")


# ----------------------------------------------------------------- 운영 확인용


@app.get("/registry", tags=["ops"])
async def get_registry() -> dict:
    await registry.refresh()
    return {"agents": list(registry.agents.values()), "skill_map": registry.skill_map}


@app.get("/admin/overview", tags=["admin"])
async def admin_overview() -> dict:
    await registry.refresh()
    users = directory()
    return {
        "agents": list(registry.agents.values()),
        "skill_map": registry.skill_map,
        "hub_skills": [{"id": s.id, "name": s.name, "description": s.description} for s in card.skills],
        "connections": [
            {"user_id": uid, "name": users[uid]["name"], "since": since}
            for uid, items in connections.items() for since in items
        ],
        "llm": {"provider": get_llm().name, "base_url": VLLM_BASE_URL, "model": VLLM_MODEL},
    }


# ----------------------------------------------------------------- 수신함 프록시


async def _broker_base() -> str:
    url, _ = await registry.resolve("request-create")
    return url


@app.get("/api/inbox", tags=["inbox (extension)"])
async def inbox(me: Principal = Depends(require_principal)) -> dict:
    r = await proxy_http.get(f"{await _broker_base()}/api/inbox", headers=auth_headers(me.token))
    r.raise_for_status()
    return r.json()


@app.get("/api/inbox/stream", tags=["inbox (extension)"])
async def inbox_stream(me: Principal = Depends(require_principal)) -> StreamingResponse:
    upstream = f"{await _broker_base()}/api/inbox/stream"
    pc = {"from": f"desktop:{me.user_id}", "to": "hub"}

    async def relay():
        since = datetime.now().isoformat(timespec="seconds")
        connections.setdefault(me.user_id, []).append(since)
        telemetry.emit("inbox.connect", user=me.user_id, **pc)
        try:
            async with proxy_http.stream("GET", upstream, headers=auth_headers(me.token)) as r:
                async for chunk in r.aiter_raw():
                    yield chunk
        finally:
            connections[me.user_id].remove(since)
            telemetry.emit("inbox.disconnect", user=me.user_id, **pc)

    return StreamingResponse(relay(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/api/people", tags=["people (extension)"])
async def people(request: Request, me: Principal = Depends(require_principal)) -> list[dict]:
    url, _ = await registry.resolve("people-lookup")
    r = await connector.send(url, skill="people-lookup", token=me.token, data={"all": True},
                             trace_id=_trace(request))
    return r.first_data.get("matches", [])
