"""Hub Orchestrator - PC Agent 의 요청을 받아 하위 Agent 로 위임하고 결과를 합친다.

모든 하위 호출은 '요청한 사용자의 토큰'으로 수행한다(권한 위임).
그래서 Knowledge Agent 는 사용자가 볼 수 있는 문서만 답변 근거로 사용한다.
"""

import asyncio

from common.a2a_kit import A2AConnector, AgentResult, SkillError, SkillRequest
from common.llm import get_llm
from services.hub.registry import AgentRegistry


class Orchestrator:
    def __init__(self, connector: A2AConnector, registry: AgentRegistry):
        self.connector = connector
        self.registry = registry

    @property
    def handlers(self):
        return {
            "knowledge-search": self.knowledge_search,
            "people-lookup": self.people_lookup,
            "weekly-report-submit": self.weekly_report_submit,
            "request-create": self.request_create,
            "request-reply": self.request_reply,
        }

    async def classify(self, text: str) -> str:
        """skill 이 지정되지 않은 자유 질의 -> skill id."""
        intent = await get_llm().classify_intent(text)
        return {"people": "people-lookup"}.get(intent, "knowledge-search")

    async def _call(self, req: SkillRequest, skill: str, **kwargs) -> AgentResult:
        url, agent_name = await self.registry.resolve(skill)

        async def forward_progress(text: str) -> None:
            await req.progress(f"[{agent_name}] {text}")

        return await self.connector.send(
            url, skill=skill, token=req.principal.token, trace_id=req.trace_id,
            on_progress=forward_progress, **kwargs,
        )

    async def _person(self, req: SkillRequest, user_id: str) -> dict | None:
        r = await self._call(req, "people-lookup", data={"user_id": user_id})
        matches = r.first_data.get("matches", [])
        return matches[0] if matches else None

    # ------------------------------------------------------------------ skills

    async def knowledge_search(self, req: SkillRequest) -> None:
        query = req.text or req.data.get("query", "")
        await req.progress("Knowledge Agent / People Agent 병렬 조회")
        knowledge, people = await asyncio.gather(
            # Knowledge 가 스트리밍하는 답변 조각을 그대로 PC 쪽으로 흘려보낸다
            self._call(req, "knowledge-search", text=query, on_text=req.stream_text),
            self._call(req, "people-lookup", data={"topic": query}),
        )
        if not knowledge.ok:
            raise SkillError(knowledge.status_text or "지식 검색에 실패했습니다.")

        related = [
            {k: m[k] for k in ("user_id", "name", "team", "status", "status_note", "backup")}
            for m in people.first_data.get("matches", [])[:2]
        ] if people.ok else []

        await req.reply(data={**knowledge.first_data, "related_people": related}, name="answer-meta")

    async def people_lookup(self, req: SkillRequest) -> None:
        r = await self._call(req, "people-lookup", text=req.text, data=req.data or None)
        await req.reply(text=r.text, data=r.first_data, name="people")

    async def weekly_report_submit(self, req: SkillRequest) -> None:
        r = await self._call(req, "weekly-report-submit", data=req.data)
        if not r.ok:
            raise SkillError(r.status_text or "주간보고 접수에 실패했습니다.")
        await req.reply(text=r.text, data=r.first_data, name="weekly-report-receipt")

    async def request_create(self, req: SkillRequest) -> None:
        d = req.data
        topic = d.get("topic") or req.text

        # 1) 담당자 결정: 직접 지정 > 업무 키워드로 People Agent 조회
        if d.get("to_user_id"):
            target = await self._person(req, d["to_user_id"])
            reason = "요청자가 직접 지정"
        else:
            r = await self._call(req, "people-lookup", data={"topic": topic})
            matches = r.first_data.get("matches", [])
            target = matches[0] if matches else None
            reason = f"'{topic}' 업무 담당자로 자동 지정"
        if not target:
            raise SkillError(f"'{topic}' 업무의 담당자를 찾지 못했습니다.")

        # 2) 부재 시 대리 담당자에게 전달
        if target["status"] == "away" and target.get("backup"):
            backup = await self._person(req, target["backup"]["user_id"])
            if backup:
                reason += f" → {target['name']}님 부재({target['status_note']})로 대리 담당자에게 전달"
                target = backup
        if target["user_id"] == req.principal.user_id:
            raise SkillError("본인에게는 요청을 보낼 수 없습니다.")
        await req.progress(f"담당자 확인: {target['name']} ({target['team']})")

        # 3) Request Broker 에 요청 Task 생성 (담당자 답변 전까지 input_required)
        r = await self._call(
            req, "request-create",
            data={
                "to_user": {k: target[k] for k in ("user_id", "name", "team")},
                "title": d.get("title", ""),
                "body": d.get("body") or req.text,
                "topic": topic,
                "due": d.get("due", ""),
                "routed_reason": reason,
            },
        )
        if r.state != "input_required":
            raise SkillError(r.status_text or "요청 생성에 실패했습니다.")
        record = r.first_data["request"]
        realtime = bool(r.first_data.get("delivered_realtime"))
        delivery = "상대 PC 에 실시간 전달됨" if realtime else "상대 PC 미연결 - 수신함에 보관 (접속 시 확인)"
        await req.reply(
            text=f"{target['name']}({target['team']})님에게 요청을 전달했습니다.\n- 지정 사유: {reason}\n- {delivery}",
            data={"request": record, "broker_task_state": r.state, "delivered_realtime": realtime},
            name="request",
        )

    async def request_reply(self, req: SkillRequest) -> None:
        request_id = req.data.get("request_id")
        if not request_id:
            raise SkillError("request_id 가 필요합니다.")
        r = await self._call(req, "request-reply", text=req.text, task_id=request_id)
        if not r.ok:
            raise SkillError(r.status_text or "답변 전송에 실패했습니다.")
        await req.reply(text="답변이 요청자에게 전달되었습니다.", data=r.first_data, name="reply")
