"""하위 Agent 레지스트리.

설정된 Agent 주소에서 Agent Card 를 읽어 'skill id -> Agent' 매핑을 만든다.
새 Agent 를 붙일 때 Orchestrator 코드를 고치지 않고 주소만 추가하면 된다.

운영 전환 시: 주소 목록을 설정/DB 로 관리하고, 주기적 헬스체크와 카드 서명 검증을 추가.
"""

import logging

from common.a2a_kit import A2AConnector, SkillError

logger = logging.getLogger(__name__)


class AgentRegistry:
    def __init__(self, connector: A2AConnector, urls: list[str]):
        self._connector = connector
        self._urls = urls
        self.agents: dict[str, dict] = {}
        self.skill_map: dict[str, str] = {}

    async def refresh(self) -> None:
        for url in self._urls:
            try:
                card = await self._connector.card(url, refresh=True)
            except Exception as e:  # noqa: BLE001
                logger.warning("Agent Card 조회 실패 %s: %s", url, e)
                self.agents[url] = {"url": url, "status": "down", "error": str(e)}
                continue
            self.agents[url] = {
                "url": url,
                "status": "up",
                "name": card.name,
                "description": card.description,
                "skills": [{"id": s.id, "name": s.name, "description": s.description} for s in card.skills],
            }
            for skill in card.skills:
                self.skill_map[skill.id] = url

    async def resolve(self, skill: str) -> tuple[str, str]:
        """skill 을 제공하는 Agent 의 (base_url, name)."""
        if skill not in self.skill_map:
            await self.refresh()
        url = self.skill_map.get(skill)
        if not url or self.agents.get(url, {}).get("status") != "up":
            raise SkillError(f"'{skill}' skill 을 제공하는 Agent 에 연결할 수 없습니다.")
        return url, self.agents[url]["name"]
