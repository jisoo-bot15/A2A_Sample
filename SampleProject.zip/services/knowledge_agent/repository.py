"""문서 저장소 (목업: data/docs/*.md 를 메모리에 적재).

운영 전환 시: Confluence/SharePoint 커넥터로 수집 → 청크 분할 → 벡터 인덱스.
ACL 은 원본 시스템의 권한 정보를 함께 색인해 검색 시점에 필터링한다.
"""

from dataclasses import dataclass
from pathlib import Path

from common.auth import Principal
from common.textsearch import bigrams, best_snippet, overlap


@dataclass
class Document:
    id: str
    title: str
    url: str
    acl: tuple[str, ...]
    tags: str
    updated: str
    content: str

    def visible_to(self, principal: Principal) -> bool:
        return "all" in self.acl or bool(set(self.acl) & set(principal.groups))


def _parse(path: Path) -> Document:
    raw = path.read_text(encoding="utf-8")
    _, front, body = raw.split("---", 2)
    meta = {}
    for line in front.strip().splitlines():
        key, _, value = line.partition(":")
        meta[key.strip()] = value.strip()
    return Document(
        id=meta["id"],
        title=meta["title"],
        url=meta["url"],
        acl=tuple(a.strip() for a in meta.get("acl", "all").split(",")),
        tags=meta.get("tags", ""),
        updated=meta.get("updated", ""),
        content=body.strip(),
    )


class DocumentRepository:
    def __init__(self, docs_dir: Path):
        self.docs = [_parse(p) for p in sorted(docs_dir.glob("*.md"))]

    # ---- 콘솔용 관리 (목업: 메모리에만 반영) ----

    def get(self, doc_id: str) -> Document | None:
        return next((d for d in self.docs if d.id == doc_id), None)

    def upsert(self, doc: Document) -> Document:
        self.docs = [d for d in self.docs if d.id != doc.id] + [doc]
        return doc

    def delete(self, doc_id: str) -> bool:
        before = len(self.docs)
        self.docs = [d for d in self.docs if d.id != doc_id]
        return len(self.docs) < before

    def next_id(self) -> str:
        nums = [int(d.id.split("-")[1]) for d in self.docs if d.id.startswith("DOC-")]
        return f"DOC-{max(nums, default=100) + 1}"

    # ---- 검색 ----

    def score_all(self, query: str, threshold: float = 0.25) -> list[tuple[float, Document]]:
        q = bigrams(query)
        scored = []
        for doc in self.docs:
            score = (
                overlap(q, doc.content)
                + 0.6 * overlap(q, doc.title)
                + 0.3 * overlap(q, doc.tags)
            )
            if score >= threshold:
                scored.append((score, doc))
        return sorted(scored, key=lambda x: x[0], reverse=True)

    def search(self, query: str, principal: Principal, limit: int = 3,
               threshold: float = 0.25) -> tuple[list[dict], int]:
        """(권한 있는 문서 결과, 권한 때문에 제외된 문서 수)"""
        scored = self.score_all(query, threshold)
        visible = [(s, d) for s, d in scored if d.visible_to(principal)]
        hidden = len(scored) - len(visible)
        results = [
            {
                "doc_id": d.id,
                "title": d.title,
                "url": d.url,
                "updated": d.updated,
                "score": round(s, 3),
                "snippet": best_snippet(query, d.content),
                "content": d.content,
            }
            for s, d in visible[:limit]
        ]
        return results, hidden
