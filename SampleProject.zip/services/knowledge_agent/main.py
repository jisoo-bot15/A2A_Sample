"""Knowledge Agent (A2A 서버) - 사내 문서/위키 검색 및 근거 기반 답변.

skill
- knowledge-search : 질문(text) -> 답변(text) + 출처(data.citations)

실행: python -m uvicorn services.knowledge_agent.main:app --port 9101
"""

from pathlib import Path

from fastapi import HTTPException
from pydantic import BaseModel

from common import simulate
from common.a2a_kit import SkillRequest, SkillRouterExecutor, build_agent_card, create_agent_app
from common.auth import issue_dev_token, verify_token
from common.config import DATA_DIR, KNOWLEDGE_AGENT_URL, MOCK_TODAY
from common.llm import get_llm
from common.logs import setup_logging
from common.textsearch import best_snippet, bigrams
from services.knowledge_agent.repository import Document, DocumentRepository

setup_logging("knowledge")

repo = DocumentRepository(DATA_DIR / "docs")


async def knowledge_search(req: SkillRequest) -> None:
    query = req.text or req.data.get("query", "")
    await req.progress("문서 검색 중 (임베딩 검색)")
    await simulate.delay("vector_search", factor=len(repo.docs) / 7)
    results, hidden = repo.search(query, req.principal)
    await req.progress(
        f"문서 {len(results)}건 검색" + (f" (권한 밖 문서 {hidden}건 제외)" if hidden else "")
    )

    citations = [{k: r[k] for k in ("doc_id", "title", "url", "updated", "score", "snippet")}
                 for r in results]
    if not results:
        msg = "관련된 사내 문서를 찾지 못했습니다. 다른 키워드로 질문하시거나 담당자에게 문의해 보세요."
        if hidden:
            msg += f"\n(열람 권한이 없는 문서 {hidden}건은 결과에서 제외되었습니다.)"
        await req.stream_text(msg)
    else:
        size = sum(len(r["content"]) for r in results)
        await req.progress(f"답변 생성 중 (사내 vLLM, 참고 문서 {len(results)}건 · 약 {size:,}자)")
        # LLM 이 만드는 토큰을 그대로 A2A artifact 조각으로 흘려보낸다 (Hub → PC 까지 실시간 표시)
        await get_llm().answer_with_docs(query, results, on_delta=req.stream_text)
        if hidden:
            await req.stream_text(f"\n\n※ 열람 권한이 없는 문서 {hidden}건은 답변 근거에서 제외되었습니다.")

    await req.reply(data={"citations": citations, "hidden_count": hidden}, name="knowledge-meta")


card = build_agent_card(
    name="Knowledge Agent",
    description="사내 문서/위키를 검색해 사용자 권한 범위 내에서 근거와 함께 답변합니다.",
    base_url=KNOWLEDGE_AGENT_URL,
    skills=[
        {
            "id": "knowledge-search",
            "name": "사내 지식 검색",
            "description": "질문과 관련된 사내 문서를 찾아 요약 답변과 출처를 반환합니다.",
            "tags": ["wiki", "docs", "rag"],
            "examples": ["결제 장애 발생 시 대응 절차 알려줘", "정기 배포 일정이 어떻게 돼?"],
        }
    ],
)

app = create_agent_app(
    card,
    SkillRouterExecutor("knowledge", {"knowledge-search": knowledge_search}),
    node="knowledge",
    console_html=Path(__file__).parent / "console.html",
)


# ----------------------------------------------------------------- 콘솔용 관리 API


class DocIn(BaseModel):
    title: str
    acl: list[str] = ["all"]
    tags: str = ""
    content: str


def _doc_dict(d: Document, with_content: bool = False) -> dict:
    out = {"id": d.id, "title": d.title, "url": d.url, "acl": list(d.acl), "tags": d.tags,
           "updated": d.updated, "length": len(d.content)}
    if with_content:
        out["content"] = d.content
    return out


@app.get("/admin/docs", tags=["admin"])
async def list_docs() -> list[dict]:
    return [_doc_dict(d) for d in repo.docs]


@app.get("/admin/docs/{doc_id}", tags=["admin"])
async def get_doc(doc_id: str) -> dict:
    doc = repo.get(doc_id)
    if not doc:
        raise HTTPException(404, "문서 없음")
    return _doc_dict(doc, with_content=True)


@app.put("/admin/docs/{doc_id}", tags=["admin"])
async def save_doc(doc_id: str, body: DocIn) -> dict:
    """doc_id 가 'new' 이면 새 문서 생성. 목업이라 메모리에만 반영된다."""
    doc_id = repo.next_id() if doc_id == "new" else doc_id
    doc = repo.upsert(Document(
        id=doc_id, title=body.title, url=f"https://wiki.sample.local/pages/{doc_id}",
        acl=tuple(body.acl or ["all"]), tags=body.tags, updated=MOCK_TODAY.isoformat(),
        content=body.content,
    ))
    return _doc_dict(doc, with_content=True)


@app.delete("/admin/docs/{doc_id}", tags=["admin"])
async def delete_doc(doc_id: str) -> dict:
    if not repo.delete(doc_id):
        raise HTTPException(404, "문서 없음")
    return {"deleted": doc_id}


@app.get("/admin/search", tags=["admin"])
async def search_debug(q: str, user_id: str) -> dict:
    """LLM 없이 검색 단계만 실행: 점수와 권한 필터 결과를 모두 보여준다."""
    principal = verify_token(issue_dev_token(user_id))
    rows = [
        {**_doc_dict(d), "score": round(s, 3), "visible": d.visible_to(principal),
         "snippet": best_snippet(q, d.content)}
        for s, d in repo.score_all(q)
    ]
    return {"user": principal.to_dict(), "query_bigrams": sorted(bigrams(q)), "results": rows}


@app.post("/admin/reset", tags=["admin"])
async def reset() -> dict:
    """시연용: 콘솔에서 바꾼 문서를 버리고 data/docs 로 다시 읽는다."""
    repo.docs = DocumentRepository(DATA_DIR / "docs").docs
    return {"docs": len(repo.docs)}