"""개인 비서 Agent (PC).

처리 원칙
1. 로컬 데이터는 PC 에서 수집/검색한다 (작업 폴더, 일정, 활동 기록).
2. 글을 이해하고 쓰는 일(의도 분류, 요청 정리, 주간보고·답변 초안)은 사내 vLLM 을 직접 호출한다.
3. 사내 문서, 담당자 정보, 담당자 요청은 Hub 에 A2A 로 위임한다.
4. 주간보고 업로드, 요청 전송, 답변 전송은 초안을 보여주고 사용자 승인 후에만 전송한다.
5. 오프라인(서버/vLLM 연결 불가)이면 PC 안의 템플릿으로 초안을 만든다.

각 작업은 진행 단계(step)와 생성 중인 텍스트(delta)를 emit 으로 내보내 화면에 실시간 표시한다.
사용자 동작 1회마다 trace_id 를 만들어 Hub/vLLM 호출과 관제 이벤트를 하나로 묶는다.
"""

import logging
from collections.abc import Awaitable, Callable
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from a2a.client import A2AClientError

from common import simulate, telemetry, templates
from common.auth import issue_dev_token, verify_token
from common.config import MOCK_TODAY, VLLM_MODEL
from common.events import EventHub
from common.llm import BaseLLM, TemplateLLM, estimate_tokens, get_llm
from desktop.hub_client import HubClient, HubOffline
from desktop.local_tools import LocalTools

logger = logging.getLogger(__name__)

HUB_DOWN_MESSAGE = "운영 서버(Hub)에 연결할 수 없습니다. 로컬 기능만 사용할 수 있습니다."
OFFLINE_MESSAGE = "오프라인 모드입니다. 서버가 필요한 기능은 온라인 상태에서 다시 시도해 주세요."

Emit = Callable[[str, dict], Awaitable[None]]


class Progress:
    """화면으로 진행 상황을 내보내는 도우미.

    step : 단계 시작/종료 (where = pc | llm | hub)
    info : 서버 쪽에서 올라온 진행 메시지 (해당 단계 아래에 표시)
    delta: LLM 이 생성 중인 텍스트 조각
    """

    def __init__(self, emit: Emit | None):
        self._emit = emit
        self._n = 0

    async def send(self, event: str, data: dict) -> None:
        if self._emit:
            await self._emit(event, data)

    @asynccontextmanager
    async def step(self, label: str, where: str, detail: str = ""):
        """label: 사용자에게 보여줄 문장, detail: 어디서 어떻게 처리되는지(자세히 보기용)"""
        self._n += 1
        sid = self._n
        t0 = telemetry.now_ms()
        await self.send("step", {"id": sid, "label": label, "where": where, "detail": detail, "status": "running"})
        try:
            yield sid
        except Exception:
            await self.send("step", {"id": sid, "status": "error", "ms": round(telemetry.now_ms() - t0)})
            raise
        await self.send("step", {"id": sid, "status": "done", "ms": round(telemetry.now_ms() - t0)})

    async def info(self, sid: int, text: str) -> None:
        await self.send("info", {"parent": sid, "text": text})

    async def delta(self, text: str) -> None:
        await self.send("delta", {"text": text})


def begin_trace() -> str:
    trace_id = telemetry.new_trace_id()
    telemetry.set_trace(trace_id)
    return trace_id


class PersonalAgent:
    def __init__(self, user_id: str, hub_url: str, profile_dir: Path):
        # 운영: OIDC 로그인으로 받은 토큰을 OS 키체인에서 읽는다
        self.token = issue_dev_token(user_id)
        self.me = verify_token(self.token)
        self.hub = HubClient(hub_url, self.token)
        self.tools = LocalTools(profile_dir, MOCK_TODAY)
        self.vllm = get_llm()
        self.template = TemplateLLM()
        self.ui = EventHub()
        self.hub_connected = False
        self.inbox: dict[str, list[dict]] = {"received": [], "sent": []}
        self._people_cache: list[dict] | None = None

    @property
    def offline(self) -> bool:
        return self.hub.offline

    def _emit(self, kind: str, **fields) -> None:
        telemetry.emit(kind, user=self.me.user_id, **fields)

    def _llm(self, task: str, summary: str) -> tuple[BaseLLM, str]:
        """사용할 LLM 과 화면 표시용 위치. 온라인이면 사내 vLLM (나간 기록 남김)."""
        if self.offline:
            return self.template, "pc"
        self.hub.record("LLM", f"사내 vLLM · {task}", summary)
        return self.vllm, "llm"

    @staticmethod
    def _llm_label(where: str) -> str:
        return f"사내 AI (vLLM · {VLLM_MODEL})" if where == "llm" else "오프라인 - PC 안의 기본 문장틀"

    # ------------------------------------------------------------ chat 진입점

    async def chat(self, text: str, emit: Emit | None = None) -> dict:
        p = Progress(emit)
        trace_id = begin_trace()
        try:
            intent = await self._classify(text, p)
            route = {"local_search": "local", "help": "local", "weekly_report": "local_llm",
                     "send_request": "local_llm"}.get(intent, "server")
            self._emit("desktop.intent", intent=intent, route=route)
            if route == "server" and self.offline:
                return {"intent": intent, "route": "local", "text": OFFLINE_MESSAGE, "trace_id": trace_id}
            handler = {
                "local_search": self._local_search,
                "knowledge": self._knowledge,
                "people": self._people,
                "weekly_report": self._weekly,
                "send_request": self._send_request,
                "help": self._help,
            }[intent]
            return {"intent": intent, "route": route, "trace_id": trace_id, **await handler(text, p)}
        except HubOffline:
            return {"intent": "error", "route": "local", "text": OFFLINE_MESSAGE, "trace_id": trace_id}
        except (httpx.HTTPError, A2AClientError) as e:
            logger.warning("Hub 호출 실패: %s", e)
            return {"intent": "error", "route": "local", "text": HUB_DOWN_MESSAGE, "trace_id": trace_id}

    async def _classify(self, text: str, p: Progress) -> str:
        llm, where = self._llm("classify", f"질문 {len(text)}자")
        async with p.step("질문을 이해하고 있어요", where, self._llm_label(where)):
            return await llm.classify_intent(text)

    async def _local_search(self, text: str, p: Progress) -> dict:
        async with p.step("내 작업 폴더에서 찾고 있어요", "pc", "PC 안에서만 처리 · 서버로 보내지 않음"):
            await simulate.delay("local_scan", factor=len(self.tools.workspace))
            hits = self.tools.search_workspace(text)
        self._emit("local.tool", tool="search_workspace", hits=len(hits))
        if hits:
            return {"text": f"내 작업 폴더에서 관련 문서 {len(hits)}건을 찾았습니다. (문서 내용은 서버로 전송하지 않음)",
                    "sources": hits}
        if self.offline:
            return {"text": "작업 폴더에서 찾지 못했습니다. (오프라인이라 사내 문서 검색은 생략)"}
        result = await self._knowledge(text, p)
        result["route"] = "server"
        result["text"] = "작업 폴더에서 찾지 못해 사내 문서를 검색했습니다.\n\n" + result["text"]
        return result

    async def _knowledge(self, text: str, p: Progress) -> dict:
        async with p.step("사내 문서를 찾아 답변을 쓰고 있어요", "hub", "운영 서버 Hub → 자료실(Knowledge) · A2A") as sid:
            r = await self.hub.send("knowledge-search", text=text,
                                    on_progress=lambda t: p.info(sid, t), on_text=p.delta)
        return {
            "state": r.state,
            "text": r.text or r.status_text,
            "progress": r.progress,
            "citations": r.first_data.get("citations", []),
            "hidden_count": int(r.first_data.get("hidden_count", 0)),
            "related_people": r.first_data.get("related_people", []),
        }

    async def _people(self, text: str, p: Progress) -> dict:
        async with p.step("담당자를 찾고 있어요", "hub", "운영 서버 Hub → 인사 데스크(People) · A2A") as sid:
            r = await self.hub.send("people-lookup", text=text, on_progress=lambda t: p.info(sid, t))
        return {"state": r.state, "text": r.text, "matches": r.first_data.get("matches", [])}

    async def _weekly(self, text: str, p: Progress) -> dict:
        return {
            "text": "이번 주 작업 내역을 정리했습니다. 내용을 확인/수정한 뒤 승인하면 서버에 업로드합니다.",
            "draft": await self._draft_weekly(p),
        }

    async def _send_request(self, text: str, p: Progress) -> dict:
        if self._people_cache is None and not self.offline:
            async with p.step("담당자 명단을 확인하고 있어요", "hub", "운영 서버 Hub · 담당자 목록"):
                self._people_cache = await self.hub.people()
        llm, where = self._llm("extract-request", f"요청 문장 {len(text)}자 + 명단")
        async with p.step("보낼 요청을 정리하고 있어요", where, self._llm_label(where)):
            draft = await llm.extract_request(text, self._people_cache or [])
        return {"text": "아래 내용으로 요청을 보낼까요? 받는 사람을 비워두면 업무 키워드로 담당자를 자동 지정합니다.",
                "draft": draft}

    async def _help(self, text: str, p: Progress) -> dict:
        return {
            "text": (
                "할 수 있는 일:\n"
                "- 사내 문서 질문: \"결제 장애 대응 절차 알려줘\"\n"
                "- 담당자 찾기: \"배포 담당자 누구야?\"\n"
                "- 내 작업 폴더 검색: \"내 메모에서 정산 배치 개선 내용 찾아줘\"\n"
                "- 주간보고: \"이번 주 작업 주간보고로 정리해줘\"\n"
                "- 담당자 요청: \"배포 담당자에게 ○○ 확인 요청해줘\""
            ),
        }

    # ------------------------------------------------------------ 주간보고

    async def draft_weekly(self, emit: Emit | None = None) -> dict:
        trace_id = begin_trace()
        return {**await self._draft_weekly(Progress(emit)), "trace_id": trace_id}

    async def _draft_weekly(self, p: Progress) -> dict:
        async with p.step("이번 주 활동을 모으고 있어요", "pc", "PC 안의 활동 기록 · 서버로 보내지 않음"):
            await simulate.delay("local_scan")
            week, week_label, acts = self.tools.week_activities()
            items, next_week = templates.weekly_items(acts)  # 구조화 항목은 기록에서 그대로 계산
        self._emit("local.tool", tool="week_activities", hits=len(acts))
        llm, where = self._llm("weekly-summary", f"활동 기록 {len(acts)}건 (약 {estimate_tokens(str(acts))} 토큰)")
        async with p.step("주간보고 초안을 쓰고 있어요", where, self._llm_label(where)):
            summary = await llm.weekly_summary(self.me.name, week_label, acts, on_delta=p.delta)
        return {"week": week, "week_label": week_label, "source_count": len(acts),
                "summary": summary, "items": items, "next_week": next_week}

    async def submit_weekly(self, report: dict, emit: Emit | None = None) -> dict:
        p = Progress(emit)
        trace_id = begin_trace()
        self._emit("user.approve", action="주간보고 업로드")
        async with p.step("주간보고를 올리고 있어요", "hub", "운영 서버 Hub → 인사 데스크(People) · A2A") as sid:
            r = await self.hub.send("weekly-report-submit", data=report, on_progress=lambda t: p.info(sid, t))
        return {"state": r.state, "text": r.text or r.status_text, "trace_id": trace_id, **r.first_data}

    # ------------------------------------------------------------ 담당자 요청 (보내기)

    async def create_request(self, draft: dict, emit: Emit | None = None) -> dict:
        p = Progress(emit)
        trace_id = begin_trace()
        self._emit("user.approve", action="요청 보내기")
        async with p.step("담당자를 찾아 요청을 전달하고 있어요", "hub", "운영 서버 Hub → People → 요청 우편실(Broker) · A2A") as sid:
            r = await self.hub.send("request-create", text=draft.get("body", ""), data=draft,
                                    on_progress=lambda t: p.info(sid, t))
        if r.ok:
            await self.sync_inbox()
        return {"state": r.state, "text": r.text or r.status_text, "progress": r.progress,
                "trace_id": trace_id, **r.first_data}

    # ------------------------------------------------------------ 담당자 요청 (받기/답변)

    def _received(self, request_id: str) -> dict:
        rec = next((r for r in self.inbox["received"] if r["request_id"] == request_id), None)
        if rec is None:
            raise KeyError(request_id)
        return rec

    async def draft_reply(self, request_id: str, emit: Emit | None = None) -> dict:
        p = Progress(emit)
        trace_id = begin_trace()
        rec = self._received(request_id)
        async with p.step("관련 일정과 메모를 확인하고 있어요", "pc", "PC 안의 일정·작업 폴더 · 서버로 보내지 않음"):
            await simulate.delay("local_scan", factor=2)
            context_items = self.tools.related_context(f"{rec['title']} {rec['body']}")
        self._emit("local.tool", tool="related_context", hits=len(context_items))
        llm, where = self._llm("draft-reply", f"요청 1건 + 근거 {len(context_items)}건")
        async with p.step("답변 초안을 쓰고 있어요", where, self._llm_label(where)):
            text = await llm.draft_reply(
                self.me.name,
                {"from_name": rec["from_user"]["name"], "title": rec["title"], "body": rec["body"]},
                context_items, on_delta=p.delta,
            )
        return {"text": text, "context_items": context_items, "trace_id": trace_id}

    async def send_reply(self, request_id: str, text: str, emit: Emit | None = None) -> dict:
        p = Progress(emit)
        trace_id = begin_trace()
        self._received(request_id)
        self._emit("user.approve", action="답변 전송")
        async with p.step("답변을 보내고 있어요", "hub", "운영 서버 Hub → 요청 우편실(Broker) · A2A") as sid:
            r = await self.hub.send("request-reply", text=text, data={"request_id": request_id},
                                    on_progress=lambda t: p.info(sid, t))
        if r.ok:
            await self.sync_inbox()
        return {"state": r.state, "text": r.text or r.status_text, "trace_id": trace_id}

    # ------------------------------------------------------------ 수신함 동기화

    async def sync_inbox(self) -> None:
        self.inbox = await self.hub.inbox()
        self.ui.publish("ui", "inbox.sync", self.inbox)

    async def on_hub_event(self, event: str, data: dict) -> None:
        if event == "hello":
            await self.sync_inbox()  # 끊겨 있던 동안 쌓인 요청 반영
            return
        trace_id = data.get("reply_trace_id") if event in ("request.answered", "request.closed") else data.get("trace_id")
        telemetry.emit("inbox.received", trace_id=trace_id or None, user=self.me.user_id, event=event,
                       request_id=data.get("request_id"))
        if "request_id" in data:
            box = "received" if data.get("to_user", {}).get("user_id") == self.me.user_id else "sent"
            others = [r for r in self.inbox[box] if r["request_id"] != data["request_id"]]
            self.inbox[box] = [data, *others]
        self.ui.publish("ui", event, data)

    async def on_hub_state(self, connected: bool) -> None:
        if connected != self.hub_connected:
            self.hub_connected = connected
            self.ui.publish("ui", "hub.state", {"connected": connected, "offline": self.offline})

    def set_offline(self, offline: bool) -> None:
        self.hub.offline = offline
        telemetry.emit("desktop.offline" if offline else "desktop.online", user=self.me.user_id)
        self.ui.publish("ui", "hub.state", {"connected": self.hub_connected and not offline, "offline": offline})
