// 개인 업무 비서 위젯 (목업). 로컬 API(/api/*)만 호출하고, 서버 통신은 로컬 Agent 가 담당한다.

const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const md = (s) => esc(s)
  .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
  .replace(/^## (.+)$/gm, '<b>$1</b>')
  .replace(/^■ (.+)$/gm, '<b>■ $1</b>')
  .replace(/\n/g, '<br>');
function h(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
const initials = (name) => String(name || '?').slice(-2);
const fmtSec = (ms) => (ms < 1000 ? `${Math.round(ms)}ms` : `${(ms / 1000).toFixed(1)}초`);
function ago(iso) {
  if (!iso) return '';
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return '방금';
  if (s < 3600) return `${Math.floor(s / 60)}분 전`;
  if (s < 86400) return `${Math.floor(s / 3600)}시간 전`;
  return iso.slice(5, 10).replace('-', '/');
}

// ------------------------------------------------------------------ 아이콘

const ICON = {
  spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/>',
  building: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h2M14 7h2M8 11h2M14 11h2M8 15h2M14 15h2M10 21v-3h4v3"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  home: '<path d="M4 11l8-7 8 7v9h-5v-6H9v6H4z"/>',
  inbox: '<path d="M4 13l2-8h12l2 8v6H4z"/><path d="M4 13h5l1 2h4l1-2h5"/>',
  report: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',
  laptop: '<rect x="5" y="5" width="14" height="10" rx="1.5"/><path d="M3 19h18"/>',
  send: '<path d="M4 12l16-8-6 16-2-7z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  doc: '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M10 12h5M10 16h5"/>',
  person: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.5 3.1-6 7-6s7 2.5 7 6"/>',
  folder: '<path d="M3 6h6l2 2h10v11H3z"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.5V14M12 17.5v.01"/>',
  server: '<rect x="4" y="4" width="16" height="7" rx="1.5"/><rect x="4" y="13" width="16" height="7" rx="1.5"/><path d="M8 7.5h.01M8 16.5h.01"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  shield: '<path d="M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6z"/><path d="M9 12l2 2 4-4"/>',
  bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
};
const icon = (name, size = 18) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[name] || ''}</svg>`;
const fillIcons = (root = document) => $$('[data-icon]', root).forEach((el) => { el.innerHTML = icon(el.dataset.icon); });

// ------------------------------------------------------------------ API

async function api(path, opts = {}) {
  const r = await fetch(path, { ...opts, headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) } });
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
  return r.json();
}
const post = (path, body) => api(path, { method: 'POST', body: JSON.stringify(body ?? {}) });

// SSE 로 진행 상황(step/info/delta)을 받으며 POST 하고 최종 result 를 돌려준다
async function streamPost(path, body, handlers = {}) {
  const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body ?? {}) });
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  let result = null;
  let error = null;
  const handle = (chunk) => {
    let ev = 'message';
    const data = [];
    for (const line of chunk.split('\n')) {
      if (line.startsWith('event:')) ev = line.slice(6).trim();
      else if (line.startsWith('data:')) data.push(line.slice(5).trim());
    }
    if (!data.length) return;
    const d = JSON.parse(data.join('\n'));
    if (ev === 'result') result = d;
    else if (ev === 'error') error = d.detail;
    else handlers[ev]?.(d);
  };
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf = (buf + dec.decode(value, { stream: true })).replace(/\r\n/g, '\n');
    let i;
    while ((i = buf.indexOf('\n\n')) >= 0) { handle(buf.slice(0, i)); buf = buf.slice(i + 2); }
  }
  if (buf.trim()) handle(buf);
  if (error) throw new Error(error);
  return result;
}

// ------------------------------------------------------------------ 상태

const state = {
  me: null, people: [], inbox: { received: [], sent: [] }, local: null,
  view: 'home', box: 'received', lastAsk: null, drafts: {}, weekly: null, weeklyDone: null, seen: new Set(), sheet: null,
};

// ------------------------------------------------------------------ 진행 표시

const WHERE = {
  pc: { icon: 'laptop', label: '내 PC' },
  llm: { icon: 'spark', label: '사내 AI' },
  hub: { icon: 'server', label: '운영 서버' },
};
const cleanInfo = (t) => String(t).replace(/^\[[^\]]+\]\s*/, '');

function progressView(title) {
  const el = h(`<div class="work"><div class="work-head"><span class="spinner"></span>${esc(title)}<span class="work-time">0.0초</span></div>
    <ol class="steps"></ol><div class="live answer hidden"></div></div>`);
  const t0 = performance.now();
  const steps = {};
  let text = '';
  const timer = setInterval(() => { $('.work-time', el).textContent = fmtSec(performance.now() - t0); }, 100);
  return {
    el,
    step(d) {
      if (!steps[d.id]) {
        const w = WHERE[d.where] || WHERE.pc;
        const li = h(`<li class="running"><span class="wi ${d.where}" title="${esc(w.label)}">${icon(w.icon, 14)}</span>
          <span class="lb">${esc(d.label)}<span class="dt">${esc(d.detail || w.label)}</span><span class="dt now"></span></span>
          <span class="st">진행 중</span></li>`);
        $('.steps', el).append(li);
        steps[d.id] = { li, ...d, infos: [] };
      }
      if (d.status !== 'running') {
        const s = steps[d.id];
        s.li.className = d.status;
        s.ms = d.ms;
        $('.st', s.li).textContent = d.status === 'done' ? `✓ ${fmtSec(d.ms)}` : '실패';
        $('.now', s.li).textContent = '';
      }
    },
    info(d) {
      const s = steps[d.parent];
      if (!s) return;
      s.infos.push(cleanInfo(d.text));
      $('.now', s.li).textContent = `↳ ${cleanInfo(d.text)}`;
    },
    delta(d) {
      const live = $('.live', el);
      live.classList.remove('hidden');
      text += d.text;
      live.innerHTML = md(text);
      live.scrollTop = live.scrollHeight;
      autoscroll();
    },
    finish() {
      clearInterval(timer);
      return { total: performance.now() - t0, steps: Object.values(steps) };
    },
  };
}

function howto(sum, traceId) {
  if (!sum?.steps.length) return '';
  const link = traceId && state.me?.monitor_url
    ? `<div style="margin-top:4px"><a href="${esc(state.me.monitor_url)}/?trace=${esc(traceId)}" target="_blank">업무 오피스에서 흐름 보기 ↗</a></div>` : '';
  return `<details class="howto"><summary>어떻게 처리했나요? · ${sum.steps.length}단계 · ${fmtSec(sum.total)}</summary>
    <ol class="steps">${sum.steps.map((s) => {
    const w = WHERE[s.where] || WHERE.pc;
    return `<li class="done"><span class="wi ${s.where}">${icon(w.icon, 14)}</span><span class="lb">${esc(s.label)}
        <span class="dt">${esc(s.detail || w.label)}</span>
        ${s.infos.length ? `<ul class="infos">${s.infos.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : ''}</span>
        <span class="st">${s.ms != null ? fmtSec(s.ms) : ''}</span></li>`;
  }).join('')}</ol>${link}</details>`;
}

// ------------------------------------------------------------------ 초기화

async function init() {
  fillIcons();
  state.me = await api('/api/me');
  document.title = `업무 비서 · ${state.me.name}`;
  $('#monitor-link').href = `${state.me.monitor_url}/`;
  setConn(state.me.hub_connected, state.me.offline);
  try { state.people = await api('/api/people'); } catch { /* 서버 미연결 */ }
  try { state.inbox = await api('/api/inbox'); } catch { /* 서버 미연결 */ }
  try { state.local = await api('/api/local'); } catch { /* ignore */ }
  renderHello();
  renderQuick();
  renderRecent();
  renderChatEmpty();
  renderInbox();
  renderWeekly();
  bindNav();
  bindActionMenu();
  connectEvents();
  if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
}

function setConn(connected, offline) {
  state.me.hub_connected = connected;
  state.me.offline = offline;
  const el = $('#conn');
  el.className = `conn ${offline ? 'warn' : connected ? 'ok' : 'bad'}`;
  $('span', el).textContent = offline ? '오프라인' : connected ? '연결됨' : '연결 중…';
  if (state.view === 'pc') renderPc();
}

function bindNav() {
  $$('.tabbar button').forEach((b) => { b.onclick = () => go(b.dataset.view); });
  $$('.seg button').forEach((b) => {
    b.onclick = () => {
      state.box = b.dataset.box;
      $$('.seg button').forEach((x) => x.classList.toggle('on', x === b));
      renderInbox();
    };
  });
  $('#new-request').onclick = () => openCompose();
  $('#askbox').onclick = () => { go('chat'); $('#chat-text').focus(); };
  const ta = $('#chat-text');
  ta.addEventListener('input', () => { ta.style.height = 'auto'; ta.style.height = `${Math.min(140, ta.scrollHeight)}px`; });
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); $('#composer').requestSubmit(); }
  });
  $('#composer').onsubmit = (e) => {
    e.preventDefault();
    const text = ta.value.trim();
    if (!text) return;
    ta.value = '';
    ta.style.height = 'auto';
    sendChat(text);
  };
}

function go(view) {
  state.view = view;
  closeSheet();
  toggleActionMenu(false);
  $$('.tabbar button').forEach((b) => b.classList.toggle('on', b.dataset.view === view));
  $$('.view').forEach((v) => v.classList.toggle('hidden', v.id !== `view-${view}`));
  if (view === 'home') { renderHello(); renderRecent(); }
  if (view === 'chat') setTimeout(() => $('#chat-text').focus(), 0);
  if (view === 'inbox') renderInbox();
  if (view === 'weekly') renderWeekly();
  if (view === 'pc') renderPc();
}

// ------------------------------------------------------------------ 홈 (인사 + 한눈에 보기 + 바로가기)

function renderHello() {
  const hr = new Date().getHours();
  const greet = hr < 11 ? '좋은 아침이에요' : hr < 18 ? '좋은 오후예요' : '오늘도 수고 많으셨어요';
  const waiting = state.inbox.received.filter((r) => r.status === 'waiting').length;
  const sentWait = state.inbox.sent.filter((r) => r.status === 'waiting').length;
  const week = state.local?.week?.count ?? '-';
  const today = new Date().toLocaleDateString('ko-KR', { month: 'long', day: 'numeric', weekday: 'long' });
  $('#hello').innerHTML = `<div class="date">${esc(today)} · ${esc(state.me.team)}</div>
    <h1>${greet}, ${esc(state.me.name)}님</h1>
    <div class="glance">
      <button class="${waiting ? 'hot' : ''}" data-go="inbox:received"><b>${waiting}</b><span>답할 요청</span></button>
      <button data-go="inbox:sent"><b>${sentWait}</b><span>답변 기다리는 중</span></button>
      <button data-go="weekly"><b>${week}</b><span>이번 주 활동</span></button>
    </div>`;
  $$('#hello [data-go]').forEach((b) => {
    b.onclick = () => {
      const [view, box] = b.dataset.go.split(':');
      if (box) {
        state.box = box;
        $$('.seg button').forEach((x) => x.classList.toggle('on', x.dataset.box === box));
      }
      go(view);
    };
  });
  $('#badge').textContent = waiting || '';
}

// 바로가기: 홈에서는 예시로 바로 실행, 대화 중 [+] 메뉴에서는 입력창에 예시를 채워 고쳐 쓸 수 있게 한다
const QUICK = [
  { ic: 'doc', label: '사내 문서\n물어보기', desc: '위키·규정·절차를 근거로 답해요', send: '결제 장애 발생 시 대응 절차 알려줘' },
  { ic: 'person', label: '담당자\n찾기', desc: '업무 키워드로 담당자와 부재 여부를 찾아요', send: '배포 담당자 누구야?' },
  { ic: 'folder', label: '내 메모\n찾기', desc: '내 PC 작업 폴더에서만 찾아요', send: '내 메모에서 정산 배치 개선 내용 찾아줘' },
  { ic: 'report', label: '주간보고\n쓰기', desc: '이번 주 활동으로 초안을 만들어요', view: 'weekly' },
  { ic: 'send', label: '담당자에게\n요청하기', desc: '담당자를 찾아 요청을 전달해요', compose: true },
  { ic: 'help', label: '무엇을\n할 수 있나요?', desc: '비서가 할 수 있는 일을 알려드려요', send: '도움말' },
];

function runQuick(q, fromMenu = false) {
  if (q.view) go(q.view);
  else if (q.compose) openCompose();
  else if (fromMenu) {
    const ta = $('#chat-text');
    ta.value = q.send;
    ta.dispatchEvent(new Event('input'));
    ta.focus();
    ta.select();
  } else sendChat(q.send);
}

function renderQuick() {
  $('#quick').innerHTML = QUICK.map((q, i) => `<button data-q="${i}"><span class="qi">${icon(q.ic)}</span>${esc(q.label).replace('\n', '<br>')}</button>`).join('');
  $$('#quick [data-q]').forEach((b) => { b.onclick = () => runQuick(QUICK[Number(b.dataset.q)]); });
}

// 최근 소식: 답할 요청, 도착한 답변, 기다리는 요청, 마지막 대화
function renderRecent() {
  const items = [];
  state.inbox.received.filter((r) => r.status === 'waiting').forEach((r) => items.push({
    ic: 'req', icon: 'inbox', title: r.title, meta: `${r.from_user.name}님이 요청 · ${ago(r.created_at)}`, pill: '<span class="pill bad">답변 필요</span>',
    ts: r.created_at, open: () => { state.box = 'received'; go('inbox'); openRequest(r.request_id); },
  }));
  state.inbox.sent.filter((r) => r.status === 'answered').slice(0, 3).forEach((r) => items.push({
    ic: 'ans', icon: 'check', title: r.title, meta: `${r.to_user.name}님 답변 · ${ago(r.answered_at)}`, pill: '<span class="pill ok">답변 도착</span>',
    ts: r.answered_at, open: () => { state.box = 'sent'; go('inbox'); openRequest(r.request_id); },
  }));
  state.inbox.sent.filter((r) => r.status === 'waiting').slice(0, 2).forEach((r) => items.push({
    ic: 'wait', icon: 'clock', title: r.title, meta: `${r.to_user.name}님 답변 기다리는 중 · ${ago(r.created_at)}`, pill: '',
    ts: r.created_at, open: () => { state.box = 'sent'; go('inbox'); openRequest(r.request_id); },
  }));
  if (state.lastAsk) {
    items.push({ ic: 'chat', icon: 'chat', title: state.lastAsk.text, meta: `최근 대화 · ${ago(state.lastAsk.at)}`, pill: '', ts: state.lastAsk.at, open: () => go('chat') });
  }
  items.sort((a, b) => String(b.ts).localeCompare(String(a.ts)));
  const box = $('#recent');
  if (!items.length) {
    box.innerHTML = `<div class="empty-state" style="padding:18px 10px"><div class="ei">${icon('bell', 22)}</div>새 소식이 없어요.</div>`;
    return;
  }
  box.innerHTML = items.slice(0, 6).map((it, i) => `<div class="item" data-recent="${i}"><span class="ic ${it.ic}">${icon(it.icon, 17)}</span>
    <div style="min-width:0"><b>${esc(it.title)}</b><div class="meta">${esc(it.meta)}</div></div>${it.pill}</div>`).join('');
  $$('#recent [data-recent]').forEach((el) => { el.onclick = () => items[Number(el.dataset.recent)].open(); });
}

// ------------------------------------------------------------------ 대화 화면 보조 (빈 화면, [+] 메뉴)

function renderChatEmpty() {
  const box = $('#chat-empty');
  if ($('#messages').children.length) { box.innerHTML = ''; return; }
  const sugg = [QUICK[0], QUICK[1], QUICK[2]];
  box.innerHTML = `<div class="big">${icon('spark', 26)}</div><h3>무엇이든 물어보세요</h3>
    <p>사내 문서, 담당자, 내 메모를 찾아 드려요.<br>입력창 왼쪽 <b>+</b> 를 누르면 바로가기를 쓸 수 있어요.</p>
    <div class="sugg">${sugg.map((q, i) => `<button data-s="${i}"><span>${icon(q.ic, 16)}</span>${esc(q.send)}</button>`).join('')}</div>`;
  $$('#chat-empty [data-s]').forEach((b) => { b.onclick = () => sendChat(sugg[Number(b.dataset.s)].send); });
}

function toggleActionMenu(open) {
  const menu = $('#actionmenu');
  const btn = $('#plus');
  if (!menu || !btn) return;
  const next = open ?? menu.classList.contains('hidden');
  menu.classList.toggle('hidden', !next);
  btn.setAttribute('aria-expanded', String(next));
  if (next) $('button', menu)?.focus();
}

function bindActionMenu() {
  const menu = $('#actionmenu');
  menu.innerHTML = QUICK.filter((q) => q.ic !== 'help').map((q) => `<button role="menuitem" data-a="${QUICK.indexOf(q)}"><span class="qi">${icon(q.ic, 17)}</span>
    <span><b>${esc(q.label.replace('\n', ' '))}</b><small>${esc(q.desc)}</small></span></button>`).join('');
  $$('[data-a]', menu).forEach((b) => {
    b.onclick = () => { toggleActionMenu(false); runQuick(QUICK[Number(b.dataset.a)], true); };
  });
  $('#plus').onclick = (e) => { e.stopPropagation(); toggleActionMenu(); };
  document.addEventListener('click', (e) => { if (!menu.contains(e.target)) toggleActionMenu(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') toggleActionMenu(false); });
}
// ------------------------------------------------------------------ 대화

const ROUTE = {
  local: { cls: 'local', icon: 'laptop', text: '내 PC에서만 처리' },
  local_llm: { cls: 'local_llm', icon: 'spark', text: '내 PC + 사내 AI' },
  server: { cls: 'server', icon: 'server', text: '운영 서버 연결' },
};
const autoscroll = () => { const s = $('#chat-scroll'); s.scrollTop = s.scrollHeight; };

async function sendChat(text) {
  go('chat');
  const msgs = $('#messages');
  state.lastAsk = { text, at: new Date().toISOString() };
  $('#chat-empty').innerHTML = '';
  msgs.append(h(`<div class="me">${esc(text)}</div>`));
  const bot = h(`<div class="bot"><span class="face">${icon('spark', 16)}</span><div class="card"></div></div>`);
  const pv = progressView('작업 중이에요');
  $('.card', bot).append(pv.el);
  msgs.append(bot);
  autoscroll();
  $('.send').disabled = true;
  try {
    const res = await streamPost('/api/chat/stream', { text }, pv);
    bot.replaceWith(renderBot(res, pv.finish()));
  } catch (err) {
    pv.finish();
    bot.replaceWith(renderBot({ route: 'local', text: `처리하지 못했어요. ${err.message}` }));
  }
  $('.send').disabled = false;
  autoscroll();
}

function renderBot(res, sum = null) {
  const r = ROUTE[res.route] || ROUTE.local;
  const el = h(`<div class="bot"><span class="face">${icon('spark', 16)}</span><div class="card">
    <span class="route ${r.cls}">${icon(r.icon, 13)} ${r.text}</span>
    <div class="answer">${md(res.text || '')}</div></div></div>`);
  const card = $('.card', el);

  if (res.sources?.length) {
    card.append(h(`<div class="sect"><div class="sect-t">내 작업 폴더에서 찾은 문서</div>${res.sources.map((s) => `
      <div class="docrow"><span class="di pc">${icon('folder', 14)}</span><div><b>${esc(s.title)}</b><p>${esc(s.snippet)}</p></div></div>`).join('')}</div>`));
  }
  if (res.citations?.length) {
    card.append(h(`<div class="sect"><div class="sect-t">참고한 사내 문서</div>${res.citations.map((c) => `
      <div class="docrow"><span class="di">${icon('doc', 14)}</span><div><b><a href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.title)}</a></b><p>${esc(c.snippet)}</p></div></div>`).join('')}
      ${res.hidden_count ? `<div class="small muted">열람 권한이 없는 문서 ${res.hidden_count}건은 답변에 쓰지 않았어요.</div>` : ''}</div>`));
  }
  if (res.related_people?.length) {
    card.append(h(`<div class="sect"><div class="sect-t">이 업무의 담당자</div>${res.related_people.map((p) => personRow(p)).join('')}</div>`));
  }
  if (res.matches?.length && !res.related_people?.length) {
    $('.answer', card).innerHTML = `${res.matches.length}명을 찾았어요.`;
    card.append(h(`<div class="sect">${res.matches.map((m) => personRow(m, true)).join('')}</div>`));
  }
  if (res.intent === 'weekly_report' && res.draft) {
    state.weekly = { draft: res.draft, sum };
    const b = h(`<div class="sect"><button class="btn block">${icon('report', 16)} 주간보고 초안 검토하기</button></div>`);
    $('button', b).onclick = () => go('weekly');
    card.append(b);
  }
  if (res.intent === 'send_request' && res.draft) {
    const box = h('<div class="sect"></div>');
    composeForm(box, res.draft, true);
    card.append(box);
  }
  if (sum) card.insertAdjacentHTML('beforeend', howto(sum, res.trace_id));
  return el;
}

function personRow(p, full = false) {
  const away = p.status === 'away'
    ? `<span class="pill warn">부재 · ${esc(p.status_note)}</span>${p.backup ? ` <span class="small muted">대신 ${esc(p.backup.name)}님</span>` : ''}` : '<span class="pill ok">근무 중</span>';
  const work = full && p.current_work?.length ? `<div class="small muted">지금: ${esc(p.current_work.slice(0, 2).join(', '))}</div>` : '';
  return `<div class="person"><span class="ava">${esc(initials(p.name))}</span><div style="min-width:0">
    <b>${esc(p.name)}</b> <span class="small muted">${esc(p.team)}</span><div>${away}</div>${work}</div></div>`;
}

// ------------------------------------------------------------------ 요청 보내기

function composeForm(container, draft = {}, inChat = false) {
  const options = state.people.filter((p) => p.user_id !== state.me.user_id)
    .map((p) => `<option value="${esc(p.user_id)}" ${p.user_id === draft.to_user_id ? 'selected' : ''}>${esc(p.name)} · ${esc(p.team)}${p.status === 'away' ? ' (부재)' : ''}</option>`);
  const el = h(`<form>
    ${inChat ? '<div class="sect-t">이렇게 보낼까요? 확인 후 보내기를 눌러 주세요</div>' : ''}
    <label class="field"><span>받는 사람</span><select name="to_user_id"><option value="">업무 담당자 자동 찾기</option>${options.join('')}</select>
      <em>비워두면 업무 키워드로 담당자를 찾고, 부재 중이면 대리 담당자에게 보내요.</em></label>
    <label class="field"><span>업무 키워드</span><input name="topic" value="${esc(draft.topic)}" placeholder="예: 배포, PG 연동"></label>
    <label class="field"><span>제목</span><input name="title" value="${esc(draft.title)}" placeholder="한 줄로 요약"></label>
    <label class="field"><span>내용</span><textarea name="body" rows="4" placeholder="상대에게 전할 내용">${esc(draft.body)}</textarea></label>
    <label class="field"><span>언제까지 답을 받고 싶나요?</span><input name="due" type="date" value="${esc(draft.due)}"></label>
    <button class="btn block" type="submit">${icon('send', 16)} 요청 보내기</button>
    <div class="result"></div></form>`);
  el.onsubmit = async (e) => {
    e.preventDefault();
    const form = Object.fromEntries(new FormData(el));
    if (!form.body.trim() && !form.topic.trim()) { toast('내용을 입력해 주세요', '업무 키워드나 내용 중 하나는 필요해요.'); return; }
    const btn = $('button[type=submit]', el);
    btn.disabled = true;
    const box = $('.result', el);
    const pv = progressView('요청을 전달하고 있어요');
    box.innerHTML = '';
    box.append(pv.el);
    try {
      const r = await streamPost('/api/requests/stream', form, pv);
      const sum = pv.finish();
      const ok = r.state === 'completed';
      box.innerHTML = `<div class="notice ${ok ? (r.delivered_realtime === false ? 'warn' : 'ok') : 'bad'}">${md(r.text)}</div>${howto(sum, r.trace_id)}`;
      if (ok) $$('input, select, textarea', el).forEach((x) => { x.disabled = true; });
      else btn.disabled = false;
    } catch (err) {
      pv.finish();
      box.innerHTML = `<div class="notice bad">보내지 못했어요. ${esc(err.message)}</div>`;
      btn.disabled = false;
    }
  };
  container.innerHTML = '';
  container.append(el);
}

function openCompose() {
  openSheet('새 요청 보내기', (body) => composeForm(body, {}));
}

// ------------------------------------------------------------------ 시트 (상세 화면)

function openSheet(title, render) {
  const sh = $('#sheet');
  sh.innerHTML = `<div class="sheet-head"><button class="ibtn" data-back aria-label="뒤로">${icon('back')}</button><b>${esc(title)}</b></div>
    <div class="scroll" id="sheet-body"></div>`;
  sh.classList.remove('hidden');
  $('[data-back]', sh).onclick = closeSheet;
  render($('#sheet-body'));
}
function closeSheet() {
  $('#sheet').classList.add('hidden');
  $('#sheet').innerHTML = '';
  state.sheet = null;
}

// ------------------------------------------------------------------ 요청함

function renderInbox() {
  renderHello();
  const list = $('#inbox-list');
  const rows = state.inbox[state.box];
  $('.seg [data-box=received]').textContent = `받은 요청 ${state.inbox.received.length || ''}`;
  $('.seg [data-box=sent]').textContent = `보낸 요청 ${state.inbox.sent.length || ''}`;
  if (!rows.length) {
    list.innerHTML = `<div class="empty-state"><div class="ei">${icon('inbox', 24)}</div>${state.box === 'received' ? '받은 요청이 없어요.' : '보낸 요청이 없어요.<br>대화창이나 "새 요청"으로 보내 보세요.'}</div>`;
    return;
  }
  list.innerHTML = rows.map((r) => {
    const other = state.box === 'received' ? r.from_user : r.to_user;
    const pill = r.status === 'waiting'
      ? `<span class="pill ${state.box === 'received' ? 'bad' : 'warn'}">${state.box === 'received' ? '답변 필요' : '기다리는 중'}</span>`
      : '<span class="pill ok">완료</span>';
    const unread = state.box === 'received' && r.status === 'waiting' && !state.seen.has(r.request_id);
    return `<div class="item ${unread ? 'unread' : ''}" data-id="${esc(r.request_id)}"><span class="ava">${esc(initials(other.name))}</span>
      <div style="min-width:0"><b>${esc(r.title)}</b><div class="meta">${state.box === 'received' ? '' : '→ '}${esc(other.name)} · ${esc(other.team)} · ${esc(ago(r.created_at))}</div></div>${pill}</div>`;
  }).join('');
  $$('#inbox-list [data-id]').forEach((el) => { el.onclick = () => openRequest(el.dataset.id); });
}

function findRequest(id) {
  return state.inbox.received.find((r) => r.request_id === id) || state.inbox.sent.find((r) => r.request_id === id);
}

function openRequest(id) {
  const r = findRequest(id);
  if (!r) return;
  state.seen.add(id);
  const received = r.to_user.user_id === state.me.user_id;
  openSheet(r.title, (body) => renderRequest(body, id, received));
  state.sheet = id;
}

function renderRequest(body, id, received) {
  const r = findRequest(id);
  if (!r || !body) return;
  const other = received ? r.from_user : r.to_user;
  body.innerHTML = `
    <div class="box soft"><div class="person"><span class="ava">${esc(initials(other.name))}</span><div>
      <b>${esc(other.name)}</b> <span class="small muted">${esc(other.team)}</span>
      <div class="small muted">${received ? '보낸 요청' : '받는 사람'} · ${esc(ago(r.created_at))}${r.due ? ` · ${esc(r.due)}까지` : ''}</div></div>
      <span class="sp"></span>${r.status === 'waiting' ? '<span class="pill warn">답변 대기</span>' : '<span class="pill ok">완료</span>'}</div>
      ${r.routed_reason ? `<div class="small muted" style="margin-top:6px">${esc(r.routed_reason)}</div>` : ''}</div>
    <div class="box"><h3>요청 내용</h3><div class="bodytext">${esc(r.body)}</div></div>
    <div id="reply-zone"></div>`;
  const zone = $('#reply-zone', body);
  if (r.status === 'answered') {
    zone.innerHTML = `<div class="box soft"><h3>${received ? '내 답변' : `${esc(r.to_user.name)}님의 답변`} <span class="small muted">${esc(ago(r.answered_at))}</span></h3>
      <div class="bodytext">${esc(r.reply)}</div></div>`;
    return;
  }
  if (!received) {
    zone.innerHTML = `<div class="notice warn">${esc(r.to_user.name)}님의 답변을 기다리고 있어요. 답변이 오면 알려드릴게요.</div>`;
    return;
  }
  const draft = state.drafts[id];
  if (draft?.pv) {
    zone.append(draft.pv.el);
    return;
  }
  if (!draft) {
    zone.innerHTML = `<div class="box soft"><h3>답변하기</h3>
      <p class="small muted" style="margin:0 0 10px">내 일정과 작업 메모를 참고해서 사내 AI 가 초안을 써 드려요. 보내기 전에 꼭 확인할 수 있어요.</p>
      <button class="btn block" data-draft>${icon('spark', 16)} 답변 초안 만들기</button>
      <button class="btn ghost block" data-self style="margin-top:8px">직접 쓸게요</button></div>`;
    $('[data-draft]', zone).onclick = () => makeDraft(id);
    $('[data-self]', zone).onclick = () => { state.drafts[id] = { text: '', context_items: [] }; renderRequest(body, id, true); };
    return;
  }
  const cal = draft.context_items.filter((c) => c.source === 'calendar').length;
  const docs = draft.context_items.length - cal;
  zone.innerHTML = `<div class="box">
      <h3>답변 ${draft.text ? '초안' : '작성'}</h3>
      ${draft.context_items.length ? `<div class="small muted" style="margin-bottom:6px">참고한 내 자료: 일정 ${cal}건 · 메모 ${docs}건 (PC 안에서 확인)</div>` : ''}
      <textarea class="edit" rows="11">${esc(draft.text)}</textarea>
      <div class="consent">${icon('shield', 16)}<span>보내기 전에 내용을 확인해 주세요. 보내면 ${esc(r.from_user.name)}님에게 바로 전달돼요.</span></div>
      <div class="row"><button class="btn" data-send style="flex:1">${icon('send', 16)} 보내기</button>
        <button class="btn ghost" data-redo>${draft.text ? '다시 쓰기' : '초안 받기'}</button></div>
      ${howto(draft.sum, draft.trace_id)}<div class="result"></div></div>`;
  $('textarea', zone).oninput = (e) => { draft.text = e.target.value; };
  $('[data-redo]', zone).onclick = () => makeDraft(id);
  $('[data-send]', zone).onclick = async () => {
    if (!draft.text.trim()) { toast('답변이 비어 있어요', '내용을 입력해 주세요.'); return; }
    const btn = $('[data-send]', zone);
    btn.disabled = true;
    const pv = progressView('답변을 보내고 있어요');
    $('.result', zone).append(pv.el);
    try {
      const res = await streamPost(`/api/requests/${id}/reply/stream`, { text: draft.text }, pv);
      pv.finish();
      if (res.state === 'completed') {
        delete state.drafts[id];
        toast('답변을 보냈어요', r.title);
        if (state.sheet === id) renderRequest($('#sheet-body'), id, true);
      } else {
        $('.result', zone).innerHTML = `<div class="notice bad">${esc(res.text)}</div>`;
        btn.disabled = false;
      }
    } catch (err) {
      pv.finish();
      $('.result', zone).innerHTML = `<div class="notice bad">보내지 못했어요. ${esc(err.message)}</div>`;
      btn.disabled = false;
    }
  };
}

async function makeDraft(id) {
  const pv = progressView('답변 초안을 쓰고 있어요');
  state.drafts[id] = { pv };
  if (state.sheet === id) renderRequest($('#sheet-body'), id, true);
  try {
    const res = await streamPost(`/api/requests/${id}/draft/stream`, {}, pv);
    state.drafts[id] = { ...res, sum: pv.finish() };
  } catch (err) {
    pv.finish();
    delete state.drafts[id];
    toast('초안을 만들지 못했어요', err.message);
  }
  if (state.sheet === id) renderRequest($('#sheet-body'), id, true);
}

// ------------------------------------------------------------------ 주간보고

function renderWeekly() {
  const area = $('#weekly-area');
  if (!area) return;
  const acts = state.local?.activity || [];
  const label = state.local?.week?.label || '';
  const weekActs = acts.filter((a) => label && a.date >= label.slice(0, 10));
  const cnt = (s) => weekActs.filter((a) => a.status === s).length;
  if (state.weeklyDone) {
    const d = state.weeklyDone;
    area.innerHTML = `<div class="box soft" style="text-align:center;padding:22px 14px">
      <div class="ei" style="width:52px;height:52px;border-radius:16px;display:grid;place-items:center;margin:0 auto 10px;background:var(--ok-soft);color:var(--ok)">${icon('check', 26)}</div>
      <h3 style="margin:0 0 4px">주간보고를 올렸어요</h3><div class="small muted">${esc(d.text)}</div>
      ${d.current_work ? `<div class="small" style="margin-top:12px">팀에 보이는 내 '현재 작업'<div class="chips" style="justify-content:center">${d.current_work.map((w) => `<span class="pill blue">${esc(w)}</span>`).join('')}</div></div>` : ''}
      <button class="btn ghost" style="margin-top:14px" data-again>다시 작성하기</button></div>`;
    $('[data-again]', area).onclick = () => { state.weeklyDone = null; state.weekly = null; renderWeekly(); };
    return;
  }
  if (state.weekly?.pv) {
    area.innerHTML = '';
    area.append(state.weekly.pv.el);
    return;
  }
  if (!state.weekly) {
    area.innerHTML = `<div class="box soft"><div class="small muted">${esc(label)}</div>
      <h3 style="margin:2px 0 0">이번 주 활동 ${weekActs.length}건이 기록돼 있어요</h3>
      <div class="stat3"><div><b>${cnt('완료')}</b><span>완료</span></div><div><b>${cnt('진행중')}</b><span>진행 중</span></div><div><b>${cnt('예정')}</b><span>다음 주 예정</span></div></div>
      <p class="small muted" style="margin:8px 0 12px">문서 작업·회의·메일 같은 PC 활동 기록으로 초안을 만들어요. 기록은 PC 안에서 모으고, 글은 사내 AI 가 써요.</p>
      <button class="btn block" data-make>${icon('spark', 16)} 주간보고 초안 만들기</button></div>`;
    $('[data-make]', area).onclick = makeWeekly;
    return;
  }
  const { draft, sum } = state.weekly;
  const group = (s) => draft.items.filter((i) => i.status === s);
  area.innerHTML = `<div class="box">
      <div class="small muted">${esc(draft.week)} · ${esc(draft.week_label)} · 활동 ${draft.source_count}건 기반</div>
      <h3 style="margin:2px 0 8px">초안을 확인하고 다듬어 주세요</h3>
      <textarea class="edit" rows="14">${esc(draft.summary)}</textarea>
      <div class="small" style="margin-top:8px">팀에 공유될 항목</div>
      <div class="chips">${group('진행중').map((i) => `<span class="pill blue">진행 · ${esc(i.title)}</span>`).join('')}
        ${draft.next_week.map((t) => `<span class="pill">예정 · ${esc(t)}</span>`).join('')}
        ${group('완료').map((i) => `<span class="pill ok">완료 · ${esc(i.title)}</span>`).join('')}</div>
      <div class="consent">${icon('shield', 16)}<span>올리면 운영 서버의 인사 데스크에 등록되고, 팀원이 보는 내 '현재 작업'이 진행·예정 항목으로 바뀌어요.</span></div>
      <div class="row"><button class="btn" data-up style="flex:1">${icon('check', 16)} 확인했어요, 올리기</button><button class="btn ghost" data-redo>다시 만들기</button></div>
      ${howto(sum, draft.trace_id)}<div class="result"></div></div>`;
  $('textarea', area).oninput = (e) => { draft.summary = e.target.value; };
  $('[data-redo]', area).onclick = makeWeekly;
  $('[data-up]', area).onclick = async () => {
    const btn = $('[data-up]', area);
    btn.disabled = true;
    const pv = progressView('주간보고를 올리고 있어요');
    $('.result', area).append(pv.el);
    try {
      const report = { week: draft.week, summary: draft.summary, items: draft.items, next_week: draft.next_week };
      const r = await streamPost('/api/weekly/submit/stream', report, pv);
      pv.finish();
      if (r.state === 'completed') {
        state.weeklyDone = r;
        renderWeekly();
        toast('주간보고를 올렸어요', r.text);
      } else {
        $('.result', area).innerHTML = `<div class="notice bad">${esc(r.text)}</div>`;
        btn.disabled = false;
      }
    } catch (err) {
      pv.finish();
      $('.result', area).innerHTML = `<div class="notice bad">올리지 못했어요. ${esc(err.message)}</div>`;
      btn.disabled = false;
    }
  };
}

async function makeWeekly() {
  const pv = progressView('주간보고 초안을 쓰고 있어요');
  state.weekly = { pv };
  renderWeekly();
  try {
    const draft = await streamPost('/api/weekly/draft/stream', {}, pv);
    state.weekly = { draft, sum: pv.finish() };
  } catch (err) {
    pv.finish();
    state.weekly = null;
    toast('초안을 만들지 못했어요', err.message);
  }
  if (state.view === 'weekly') renderWeekly();
}

// ------------------------------------------------------------------ 내 PC

const OUT_LABEL = {
  classify: '질문 이해', 'extract-request': '요청 정리', 'weekly-summary': '주간보고 초안', 'draft-reply': '답변 초안',
  'knowledge-search': '사내 문서 질의', 'people-lookup': '담당자 조회', 'weekly-report-submit': '주간보고 등록',
  'request-create': '요청 전달', 'request-reply': '요청 답변',
};
function outLabel(o) {
  const [where, what] = String(o.target).split(' · ');
  return { where: o.kind === 'LLM' ? '사내 AI' : '운영 서버', what: OUT_LABEL[what] || what || where };
}

async function renderPc() {
  const area = $('#pc-area');
  const [local, outbound] = await Promise.all([api('/api/local'), api('/api/outbound')]);
  state.local = local;
  const off = state.me.offline;
  area.innerHTML = `
    <div class="set">
      <div class="set-row"><div class="tx"><b>오프라인 모드</b><span>${off ? '서버와 사내 AI 연결을 끊었어요. 초안은 PC 안의 기본 문장틀로 만들어요.'
    : state.me.hub_connected ? '운영 서버와 연결돼 있어요. 받은 요청이 실시간으로 와요.' : '연결을 다시 시도하고 있어요.'}</span></div>
        <button class="switch" role="switch" aria-checked="${off}" data-off aria-label="오프라인 모드"></button></div>
      <div class="set-row"><div class="tx"><b>${esc(state.me.name)} · ${esc(state.me.team)}</b><span>사내 AI: ${esc(state.me.llm.model)}</span></div></div>
    </div>
    <div class="set">
      <details open><summary>${icon('shield', 16)} PC 밖으로 보낸 기록<span class="cnt">최근 ${outbound.length}건</span></summary><div class="inner">
        <div class="small muted" style="margin-bottom:6px">어떤 일로 어디에 보냈는지만 기록해요. 내용은 남기지 않아요.</div>
        ${outbound.slice(0, 12).map((o) => {
    const l = outLabel(o);
    return `<div class="log-row"><span class="wi ${o.kind === 'LLM' ? 'llm' : 'hub'}">${icon(o.kind === 'LLM' ? 'spark' : 'server', 13)}</span>
            <span>${esc(l.what)} <span class="small muted">→ ${esc(l.where)}</span></span><span class="t">${esc(ago(o.ts))}</span></div>`;
  }).join('') || '<div class="small muted">아직 보낸 기록이 없어요.</div>'}</div></details>
    </div>
    <div class="set">
      <details><summary>${icon('folder', 16)} 작업 폴더<span class="cnt">${local.workspace.length}개</span></summary><div class="inner">
        ${local.workspace.map((f) => `<div class="log-row" style="cursor:pointer" data-file="${esc(f.name)}"><span class="wi pc">${icon('doc', 13)}</span>
          <span>${esc(f.name.replace(/\.md$/, ''))}</span><span class="t">${f.size}자</span></div>`).join('')}
        <details style="margin-top:8px"><summary class="small">+ 메모 추가</summary>
          <label class="field"><span>제목</span><input data-n="name" placeholder="예: 배포_체크메모"></label>
          <label class="field"><span>내용</span><textarea data-n="content" rows="4"></textarea></label>
          <button class="btn sm" data-add-note>추가</button></details></div></details>
      <details><summary>${icon('calendar', 16)} 일정<span class="cnt">${local.calendar.length}개</span></summary><div class="inner">
        ${local.calendar.map((e) => `<div class="log-row"><span class="wi pc">${icon('clock', 13)}</span><span>${esc(e.title)}<div class="small muted">${esc(e.detail)}</div></span>
          <span class="t">${esc(e.date.slice(5).replace('-', '/'))} ${esc(e.time)}</span></div>`).join('')}
        <details style="margin-top:8px"><summary class="small">+ 일정 추가</summary>
          <div class="row"><label class="field" style="flex:1"><span>날짜</span><input type="date" data-e="date" value="2026-10-21"></label>
            <label class="field"><span>시간</span><input type="time" data-e="time"></label></div>
          <label class="field"><span>제목</span><input data-e="title"></label><label class="field"><span>메모</span><input data-e="detail"></label>
          <button class="btn sm" data-add-event>추가</button></details></div></details>
      <details><summary>${icon('report', 16)} 활동 기록<span class="cnt">이번 주 ${local.week.count}건</span></summary><div class="inner">
        ${[...local.activity].reverse().slice(0, 12).map((a) => `<div class="log-row"><span class="wi pc">${icon('check', 13)}</span>
          <span>${esc(a.title)} ${a.status ? `<span class="pill ${a.status === '완료' ? 'ok' : a.status === '예정' ? '' : 'blue'}">${esc(a.status)}</span>` : ''}<div class="small muted">${esc(a.kind)} · ${esc(a.project)}</div></span>
          <span class="t">${esc(a.date.slice(5).replace('-', '/'))}</span></div>`).join('')}
        <details style="margin-top:8px"><summary class="small">+ 활동 추가</summary>
          <div class="row"><label class="field" style="flex:1"><span>날짜</span><input type="date" data-a="date" value="2026-10-16"></label>
            <label class="field"><span>종류</span><select data-a="kind">${['문서', '코드', '회의', '메일', '채팅', '장애대응', '할일'].map((k) => `<option>${k}</option>`).join('')}</select></label></div>
          <label class="field"><span>내용</span><input data-a="title"></label>
          <div class="row"><label class="field" style="flex:1"><span>프로젝트</span><input data-a="project"></label>
            <label class="field"><span>상태</span><select data-a="status"><option value="">없음</option><option>진행중</option><option>완료</option><option>예정</option></select></label></div>
          <button class="btn sm" data-add-act>추가</button></details></div></details>
    </div>`;
  $('[data-off]', area).onclick = async () => {
    const r = await post('/api/offline', { offline: !state.me.offline });
    setConn(state.me.hub_connected && !r.offline, r.offline);
    toast(r.offline ? '오프라인 모드로 바꿨어요' : '다시 연결할게요', r.offline ? '서버로 오는 요청은 보관됐다가 다시 연결하면 들어와요.' : '그동안 온 요청을 확인할게요.');
  };
  $$('[data-file]', area).forEach((el) => {
    el.onclick = async () => {
      const f = await api(`/api/local/workspace/${encodeURIComponent(el.dataset.file)}`);
      openSheet(f.name.replace(/\.md$/, ''), (b) => { b.innerHTML = `<pre class="viewer">${esc(f.content)}</pre>`; });
    };
  });
  const val = (attr, k) => $(`[${attr}="${k}"]`, area).value;
  $('[data-add-note]', area).onclick = async () => {
    if (!val('data-n', 'name').trim()) return;
    await post('/api/local/workspace', { name: val('data-n', 'name'), content: val('data-n', 'content') });
    toast('메모를 추가했어요', '');
    renderPc();
  };
  $('[data-add-event]', area).onclick = async () => {
    if (!val('data-e', 'title').trim()) return;
    await post('/api/local/calendar', { date: val('data-e', 'date'), time: val('data-e', 'time'), title: val('data-e', 'title'), detail: val('data-e', 'detail') });
    toast('일정을 추가했어요', '');
    renderPc();
  };
  $('[data-add-act]', area).onclick = async () => {
    if (!val('data-a', 'title').trim()) return;
    await post('/api/local/activity', { date: val('data-a', 'date'), kind: val('data-a', 'kind'), project: val('data-a', 'project'), title: val('data-a', 'title'), status: val('data-a', 'status') || null });
    toast('활동을 기록했어요', '');
    renderPc();
  };
}

// ------------------------------------------------------------------ 알림 / 실시간 이벤트

function toast(title, body, onClick) {
  const t = h(`<div class="toast"><span class="ti">${icon('bell', 15)}</span><div><b>${esc(title)}</b>${body ? `<span>${esc(body)}</span>` : ''}</div></div>`);
  t.onclick = () => { t.remove(); onClick?.(); };
  $('#toasts').append(t);
  setTimeout(() => t.remove(), 6000);
  if ('Notification' in window && Notification.permission === 'granted' && document.hidden) new Notification(title, { body });
}

function connectEvents() {
  const es = new EventSource('/api/events');
  es.addEventListener('hello', (e) => { const d = JSON.parse(e.data); setConn(d.hub_connected, d.offline); });
  es.addEventListener('hub.state', (e) => { const d = JSON.parse(e.data); setConn(d.connected, d.offline); });
  es.addEventListener('inbox.sync', (e) => { state.inbox = JSON.parse(e.data); refreshInboxViews(); });
  for (const name of ['request.received', 'request.sent', 'request.answered', 'request.closed', 'request.reminded']) {
    es.addEventListener(name, (e) => onRequestEvent(name, JSON.parse(e.data)));
  }
  es.addEventListener('notice', (e) => toast('공지', JSON.parse(e.data).message));
  es.addEventListener('demo.action', (e) => onDemoAction(JSON.parse(e.data)));
  es.addEventListener('demo.reset', () => location.reload());
  es.addEventListener('demo.status', (e) => demoStatus(JSON.parse(e.data)));
}

function refreshInboxViews() {
  renderHello();
  renderRecent();
  if (state.view === 'inbox') renderInbox();
  const id = state.sheet;
  if (id && findRequest(id) && !state.drafts[id]?.pv) {
    const r = findRequest(id);
    renderRequest($('#sheet-body'), id, r.to_user.user_id === state.me.user_id);
  }
}

function onRequestEvent(name, rec) {
  const box = rec.to_user.user_id === state.me.user_id ? 'received' : 'sent';
  state.inbox[box] = [rec, ...state.inbox[box].filter((r) => r.request_id !== rec.request_id)];
  refreshInboxViews();
  const open = () => {
    state.box = box;
    $$('.seg button').forEach((x) => x.classList.toggle('on', x.dataset.box === box));
    go('inbox');
    openRequest(rec.request_id);
  };
  if (name === 'request.received') toast(`${rec.from_user.name}님의 새 요청`, rec.title, open);
  if (name === 'request.answered') toast(`${rec.to_user.name}님이 답변했어요`, rec.title, open);
  if (name === 'request.reminded') toast('답변을 기다리고 있어요', rec.title, open);
}


// ------------------------------------------------------------------ 자동 시연 (scripts/autoplay.py)
// 사람이 쓰는 것처럼 화면을 직접 조작한다: 입력 타이핑, 버튼 클릭, 결과 대기.

const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
async function waitFor(fn, timeout = 90000, every = 200) {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    const v = fn();
    if (v) return v;
    await sleep(every);
  }
  throw new Error('시간 초과');
}
async function typeInto(el, text, perChar = 28) {
  el.focus();
  el.value = '';
  for (const ch of text) {
    el.value += ch;
    el.dispatchEvent(new Event('input'));
    await sleep(perChar);
  }
}
async function clickEl(el) {
  el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  await sleep(350);
  el.click();
}

function demoStatus(d) {
  $('#demo-pill').classList.toggle('hidden', !d.on);
  $('.demo-caption')?.remove();
  if (d.on && d.caption) {
    $('#widget').append(h(`<div class="demo-caption"><b>자동 시연</b> · ${esc(d.caption)}</div>`));
  }
}

async function onDemoAction(d) {
  // 가려진 탭은 브라우저가 타이머를 늦추므로 맡지 않는다 (PC 에이전트가 백그라운드로 수행)
  if (document.hidden) return;
  const claim = await post(`/api/demo/claim/${d.id}`).catch(() => ({ ok: false }));
  if (!claim.ok) return;
  demoStatus({ on: true, caption: d.title });
  let result = {};
  try {
    result = await DEMO[d.action](d.params || {});
  } catch (err) {
    result = { error: err.message };
  }
  await post(`/api/demo/done/${d.id}`, result).catch(() => {});
}

const DEMO = {
  async chat({ text }) {
    go('chat');
    await sleep(400);
    const ta = $('#chat-text');
    await typeInto(ta, text);
    await sleep(350);
    ta.value = '';
    ta.dispatchEvent(new Event('input'));
    await sendChat(text);
    await sleep(1200);
    return { done: true };
  },
  async compose(params) {
    go('inbox');
    await sleep(500);
    openCompose();
    await sleep(500);
    const form = $('#sheet form');
    for (const key of ['topic', 'title', 'body']) {
      if (params[key]) await typeInto($(`[name=${key}]`, form), params[key], 18);
    }
    await sleep(400);
    await clickEl($('button[type=submit]', form));
    await waitFor(() => $('#sheet .result .notice'));
    await sleep(1800);
    return { done: true };
  },
  async reply() {
    state.box = 'received';
    $$('.seg button').forEach((x) => x.classList.toggle('on', x.dataset.box === 'received'));
    go('inbox');
    const req = await waitFor(() => state.inbox.received.find((r) => r.status === 'waiting'), 20000);
    await sleep(700);
    openRequest(req.request_id);
    await sleep(1200);
    await clickEl(await waitFor(() => $('#sheet [data-draft]'), 5000));
    await waitFor(() => $('#sheet textarea.edit'));
    await sleep(2000);
    await clickEl($('#sheet [data-send]'));
    await waitFor(() => findRequest(req.request_id)?.status === 'answered');
    await sleep(1500);
    return { done: true };
  },
  async weekly() {
    state.weekly = null;
    state.weeklyDone = null;
    go('weekly');
    await sleep(600);
    await clickEl(await waitFor(() => $('[data-make]'), 5000));
    await waitFor(() => $('#weekly-area textarea.edit'));
    await sleep(2000);
    await clickEl($('[data-up]'));
    await waitFor(() => state.weeklyDone);
    await sleep(1800);
    return { done: true };
  },
  async offline({ offline }) {
    go('pc');
    const sw = await waitFor(() => $('[data-off]'), 5000);
    await sleep(600);
    if (String(state.me.offline) !== String(Boolean(offline))) await clickEl(sw);
    await sleep(1200);
    return { offline: state.me.offline };
  },
};

init();