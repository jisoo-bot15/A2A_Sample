"""PC 로컬 도구 - 서버로 보내지 않고 PC 안에서만 처리하는 기능.

목업: desktop/profiles/<user_id>/ 의 더미 파일을 기동 시 메모리로 읽어 사용
  workspace/*.md  : 사용자 작업 폴더
  calendar.json   : 일정 (운영: Outlook/Google Calendar 연동)
  activity.json   : 업무 활동 로그 (운영: 문서 편집/메일/회의/커밋 기록 수집기)
화면(내 PC 탭)에서 추가한 메모/일정/활동은 메모리에만 반영된다 (재시작 시 초기화).

운영 전환 시: 각 기능을 로컬 MCP 서버(파일시스템, Office, 메일/캘린더)로 분리하면
Agent Runtime 이 도구를 표준 방식으로 호출할 수 있다.
"""

import json
from datetime import date, timedelta
from pathlib import Path

from common.textsearch import best_snippet, bigrams, overlap


class LocalTools:
    def __init__(self, profile_dir: Path, today: date):
        self.profile_dir = profile_dir
        self.today = today
        self.workspace: dict[str, str] = {
            p.name: p.read_text(encoding="utf-8")
            for p in sorted((profile_dir / "workspace").glob("*.md"))
        }
        self.calendar: list[dict] = self._load(profile_dir / "calendar.json")
        self.activity: list[dict] = self._load(profile_dir / "activity.json")

    @staticmethod
    def _load(path: Path) -> list[dict]:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else []

    # ---- 화면(내 PC 탭)용 조회/추가 ----

    def add_note(self, name: str, content: str) -> str:
        name = name if name.endswith(".md") else f"{name}.md"
        self.workspace[name] = content
        return name

    def add_event(self, event: dict) -> None:
        self.calendar = sorted([*self.calendar, event], key=lambda e: (e["date"], e.get("time", "")))

    def add_activity(self, activity: dict) -> None:
        self.activity = sorted([*self.activity, activity], key=lambda a: a["date"])

    # ---- 에이전트가 쓰는 도구 ----

    def search_workspace(self, query: str, limit: int = 3, threshold: float = 0.3) -> list[dict]:
        hits = []
        for name, text in self.workspace.items():
            stem = name.removesuffix(".md")
            score = overlap(query, text) + 0.5 * overlap(query, stem)
            if score >= threshold:
                hits.append({
                    "file": f"workspace/{name}",
                    "title": stem,
                    "score": round(score, 3),
                    "snippet": best_snippet(query, text),
                })
        return sorted(hits, key=lambda h: h["score"], reverse=True)[:limit]

    def week_activities(self) -> tuple[str, str, list[dict]]:
        """(ISO 주차, 표시용 기간, 이번 주 활동 목록)"""
        monday = self.today - timedelta(days=self.today.weekday())
        sunday = monday + timedelta(days=6)
        acts = [a for a in self.activity if monday <= date.fromisoformat(a["date"]) <= sunday]
        year, week, _ = monday.isocalendar()
        return f"{year}-W{week:02d}", f"{monday:%Y-%m-%d} ~ {sunday:%m-%d}", acts

    def related_context(self, text: str, limit: int = 5) -> list[dict]:
        """요청 내용과 관련된 앞으로의 일정 + 작업 폴더 문서 (답변 초안 근거)."""
        q = bigrams(text)
        events = []
        for e in self.calendar:
            if date.fromisoformat(e["date"]) < self.today:
                continue
            matched = len(q & bigrams(f"{e['title']} {e.get('detail', '')}"))
            if matched:
                events.append((matched, e))
        events.sort(key=lambda x: (-x[0], x[1]["date"]))
        items = [
            {"source": "calendar", "date": f"{e['date']} {e.get('time', '')}".strip(),
             "title": e["title"], "detail": e.get("detail", "")}
            for _, e in events[:limit]
        ]
        for name, body in self.workspace.items():
            if len(q & bigrams(body)) >= 3:
                items.append({"source": "workspace", "date": "", "title": name.removesuffix(".md"),
                              "detail": best_snippet(text, body, max_len=160)})
        return sorted(items, key=lambda i: (i["source"] != "calendar", i["date"]))
