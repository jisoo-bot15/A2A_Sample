"""운영 Hub 접속 클라이언트 + PC 밖으로 나가는 통신 기록.

- 서버(Hub, 사내 vLLM)로 나간 요청은 outbound 기록에 남긴다 (화면 '내 PC' 탭: 무엇이 PC 밖으로 나갔는지)
- offline=True 이면 모든 서버 호출을 막는다 (오프라인 시뮬레이션)
"""

from collections import deque
from datetime import datetime

import httpx

from common import telemetry
from common.a2a_kit import A2AConnector, AgentResult, ProgressCallback
from common.auth import auth_headers


class HubOffline(Exception):
    """오프라인 모드에서 서버 호출을 시도함."""


class HubClient:
    def __init__(self, hub_url: str, token: str):
        self.hub_url = hub_url
        self.offline = False
        self.outbound: deque[dict] = deque(maxlen=200)
        self._token = token
        self._a2a = A2AConnector()
        self._http = httpx.AsyncClient(base_url=hub_url, headers=auth_headers(token), timeout=60)

    def record(self, kind: str, target: str, summary: str) -> None:
        """PC 밖으로 나가는 호출 기록. 오프라인이면 호출 자체를 막는다."""
        if self.offline:
            raise HubOffline
        self.outbound.appendleft({
            "ts": datetime.now().isoformat(timespec="seconds"),
            "kind": kind, "target": target, "summary": summary, "trace_id": telemetry.get_trace() or "",
        })

    async def send(self, skill: str, *, text: str = "", data: dict | None = None, task_id: str | None = None,
                   on_progress: ProgressCallback | None = None,
                   on_text: ProgressCallback | None = None) -> AgentResult:
        """A2A 로 Hub 의 skill 호출 (진행 메시지/답변 조각은 콜백으로 실시간 전달)."""
        parts = [f"text {len(text)}자"] if text else []
        if data:
            parts.append("data{" + ", ".join(data.keys()) + "}")
        self.record("A2A", f"Hub · {skill}", " + ".join(parts))
        return await self._a2a.send(self.hub_url, skill=skill, token=self._token, text=text, data=data,
                                    task_id=task_id, on_progress=on_progress, on_text=on_text)

    async def inbox(self) -> dict:
        if self.offline:
            raise HubOffline
        r = await self._http.get("/api/inbox")
        r.raise_for_status()
        return r.json()

    async def people(self) -> list[dict]:
        self.record("REST", "Hub · 담당자 목록", "-")
        r = await self._http.get("/api/people", headers={"X-Trace-Id": telemetry.get_trace() or ""})
        r.raise_for_status()
        return r.json()

    async def aclose(self) -> None:
        await self._a2a.aclose()
        await self._http.aclose()
