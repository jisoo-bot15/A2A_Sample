"""개인 비서 데스크탑 App (목업).

실제 데스크탑 App(Tauri/Electron)의 '백엔드 + 화면'을 로컬 웹서버로 흉내낸다.
- 화면  : http://127.0.0.1:<DESKTOP_PORT>/
- 로컬 API 는 127.0.0.1 에만 바인딩한다 (운영 데스크탑 App 에서는 IPC 로 대체)

환경변수
  DESKTOP_USER_ID : 로그인 사용자 (기본 u002)
  DESKTOP_PORT    : 로컬 포트 (기본 8001)
  HUB_URL         : 운영 Hub 주소

실행: $env:DESKTOP_USER_ID="u002"; python -m uvicorn desktop.main:app --port 8001
"""

import asyncio
import os
import uuid
from contextlib import asynccontextmanager

import httpx
from a2a.client import A2AClientError
from fastapi import Body, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from common import telemetry
from common.config import HUB_URL, LLM_PROVIDER, MONITOR_URL, ROOT_DIR, VLLM_BASE_URL, VLLM_MODEL
from common.events import sse
from common.logs import setup_logging
from desktop.agent import HUB_DOWN_MESSAGE, OFFLINE_MESSAGE, PersonalAgent
from desktop.hub_client import HubOffline
from desktop.inbox_listener import InboxListener
from desktop.local_tools import LocalTools

USER_ID = os.getenv("DESKTOP_USER_ID", "u002")
STATIC_DIR = ROOT_DIR / "desktop" / "static"

setup_logging(f"desktop:{USER_ID}")
telemetry.configure(f"desktop:{USER_ID}")

agent = PersonalAgent(USER_ID, HUB_URL, ROOT_DIR / "desktop" / "profiles" / USER_ID)


class Listener:
    """수신함 구독 태스크 관리 (오프라인 전환 시 중지, 복귀 시 재시작)."""

    task: asyncio.Task | None = None

    @classmethod
    def start(cls) -> None:
        if cls.task is None or cls.task.done():
            listener = InboxListener(HUB_URL, agent.token, agent.on_hub_event, agent.on_hub_state)
            cls.task = asyncio.create_task(listener.run())

    @classmethod
    async def stop(cls) -> None:
        if cls.task:
            cls.task.cancel()
            cls.task = None
        await agent.on_hub_state(False)


@asynccontextmanager
async def lifespan(_: FastAPI):
    Listener.start()
    yield
    await Listener.stop()
    await agent.hub.aclose()


app = FastAPI(title=f"Personal Agent ({USER_ID})", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.exception_handler(HubOffline)
async def offline_handler(_: Request, __: HubOffline) -> JSONResponse:
    return JSONResponse(status_code=409, content={"detail": OFFLINE_MESSAGE})


@app.exception_handler(httpx.HTTPError)
@app.exception_handler(A2AClientError)
async def hub_down_handler(_: Request, exc: Exception) -> JSONResponse:
    return JSONResponse(status_code=503, content={"detail": f"{HUB_DOWN_MESSAGE} ({exc.__class__.__name__})"})


def stream_task(run) -> StreamingResponse:
    """에이전트 작업을 실행하면서 진행 단계/생성 텍스트를 SSE 로 흘려보낸다.

    이벤트: step(단계 시작/종료) · info(서버 진행 메시지) · delta(생성 중 텍스트) · result(최종 결과) · error
    """
    queue: asyncio.Queue = asyncio.Queue()

    async def emit(event: str, data: dict) -> None:
        await queue.put((event, data))

    async def runner() -> None:
        try:
            await queue.put(("result", await run(emit)))
        except HubOffline:
            await queue.put(("error", {"detail": OFFLINE_MESSAGE}))
        except KeyError:
            await queue.put(("error", {"detail": "받은 요청을 찾을 수 없습니다."}))
        except (httpx.HTTPError, A2AClientError) as e:
            await queue.put(("error", {"detail": f"{HUB_DOWN_MESSAGE} ({e.__class__.__name__})"}))
        except Exception as e:  # noqa: BLE001
            await queue.put(("error", {"detail": f"{e.__class__.__name__}: {e}"}))
        finally:
            await queue.put(None)

    async def gen():
        task = asyncio.create_task(runner())
        try:
            while (item := await queue.get()) is not None:
                yield sse(*item)
        finally:
            if not task.done():
                task.cancel()

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})


@app.post("/api/chat/stream")
async def chat_stream(text: str = Body(..., embed=True)) -> StreamingResponse:
    return stream_task(lambda emit: agent.chat(text, emit))


@app.post("/api/weekly/draft/stream")
async def weekly_draft_stream() -> StreamingResponse:
    return stream_task(agent.draft_weekly)


@app.post("/api/weekly/submit/stream")
async def weekly_submit_stream(report: dict = Body(...)) -> StreamingResponse:
    return stream_task(lambda emit: agent.submit_weekly(report, emit))


@app.post("/api/requests/stream")
async def create_request_stream(draft: dict = Body(...)) -> StreamingResponse:
    return stream_task(lambda emit: agent.create_request(draft, emit))


@app.post("/api/requests/{request_id}/draft/stream")
async def draft_reply_stream(request_id: str) -> StreamingResponse:
    return stream_task(lambda emit: agent.draft_reply(request_id, emit))


@app.post("/api/requests/{request_id}/reply/stream")
async def send_reply_stream(request_id: str, text: str = Body(..., embed=True)) -> StreamingResponse:
    return stream_task(lambda emit: agent.send_reply(request_id, text, emit))


@app.get("/", include_in_schema=False)
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/me")
async def me() -> dict:
    return {**agent.me.to_dict(), "hub_url": HUB_URL, "hub_connected": agent.hub_connected,
            "offline": agent.offline, "monitor_url": MONITOR_URL,
            "llm": {"provider": LLM_PROVIDER, "base_url": VLLM_BASE_URL, "model": VLLM_MODEL}}


@app.post("/api/chat")
async def chat(text: str = Body(..., embed=True)) -> dict:
    return await agent.chat(text)


@app.get("/api/inbox")
async def inbox() -> dict:
    return agent.inbox


@app.post("/api/inbox/refresh")
async def refresh_inbox() -> dict:
    await agent.sync_inbox()
    return agent.inbox


@app.get("/api/people")
async def people() -> list[dict]:
    # 담당자 명단은 자주 바뀌지 않으므로 한 번 받아 두고 재사용 (요청 작성 화면용)
    if agent._people_cache is None:
        agent._people_cache = await agent.hub.people()
    return agent._people_cache


@app.post("/api/requests")
async def create_request(draft: dict = Body(...)) -> dict:
    return await agent.create_request(draft)


@app.post("/api/requests/{request_id}/draft")
async def draft_reply(request_id: str) -> dict:
    try:
        return await agent.draft_reply(request_id)
    except KeyError:
        raise HTTPException(404, "받은 요청을 찾을 수 없습니다.") from None


@app.post("/api/requests/{request_id}/reply")
async def send_reply(request_id: str, text: str = Body(..., embed=True)) -> dict:
    try:
        return await agent.send_reply(request_id, text)
    except KeyError:
        raise HTTPException(404, "받은 요청을 찾을 수 없습니다.") from None


@app.post("/api/weekly/draft")
async def weekly_draft() -> dict:
    return await agent.draft_weekly()


@app.post("/api/weekly/submit")
async def weekly_submit(report: dict = Body(...)) -> dict:
    return await agent.submit_weekly(report)


@app.get("/api/events")
async def ui_events() -> StreamingResponse:
    """화면 갱신용 SSE (수신함 이벤트, Hub 연결 상태)."""
    return StreamingResponse(
        agent.ui.stream("ui", hello={"hub_connected": agent.hub_connected, "offline": agent.offline}),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache"},
    )


# ----------------------------------------------------------------- 내 PC 탭 (로컬 데이터 / 연결 제어)


class NoteIn(BaseModel):
    name: str
    content: str


class EventIn(BaseModel):
    date: str
    time: str = ""
    title: str
    detail: str = ""


class ActivityIn(BaseModel):
    date: str
    kind: str
    project: str = ""
    title: str
    status: str | None = None


@app.post("/api/offline")
async def set_offline(offline: bool = Body(..., embed=True)) -> dict:
    """오프라인 시뮬레이션: Hub 호출 차단 + 수신함 연결 해제. 해제 시 재연결 후 놓친 요청 동기화."""
    agent.set_offline(offline)
    if offline:
        await Listener.stop()
    else:
        Listener.start()
    return {"offline": agent.offline}


@app.get("/api/local")
async def local_data() -> dict:
    week, week_label, acts = agent.tools.week_activities()
    return {
        "workspace": [{"name": n, "size": len(t), "preview": t.strip().splitlines()[0][:60] if t.strip() else ""}
                      for n, t in agent.tools.workspace.items()],
        "calendar": agent.tools.calendar,
        "activity": agent.tools.activity,
        "week": {"id": week, "label": week_label, "count": len(acts)},
    }


@app.get("/api/local/workspace/{name}")
async def read_note(name: str) -> dict:
    if name not in agent.tools.workspace:
        raise HTTPException(404, "파일 없음")
    return {"name": name, "content": agent.tools.workspace[name]}


@app.post("/api/local/workspace")
async def add_note(body: NoteIn) -> dict:
    return {"name": agent.tools.add_note(body.name, body.content)}


@app.post("/api/local/calendar")
async def add_event(body: EventIn) -> dict:
    agent.tools.add_event(body.model_dump())
    return {"ok": True}


@app.post("/api/local/activity")
async def add_activity(body: ActivityIn) -> dict:
    agent.tools.add_activity(body.model_dump(exclude_none=True))
    return {"ok": True}


@app.get("/api/outbound")
async def outbound() -> list[dict]:
    return list(agent.hub.outbound)


# ----------------------------------------------------------------- 자동 시연 (scripts/autoplay.py 가 호출)
#
# 위젯 화면이 열려 있으면 화면이 직접 수행한다(입력 타이핑, 버튼 클릭이 보이도록).
# 화면이 없거나 응답이 없으면 같은 일을 에이전트가 직접 수행한다(관제 화면에서만 보임).

demo_waiters: dict[str, asyncio.Future] = {}
demo_claimed: set[str] = set()


async def run_direct(action: str, params: dict) -> dict:
    if action == "chat":
        r = await agent.chat(params["text"])
        return {"intent": r.get("intent"), "route": r.get("route")}
    if action == "compose":
        r = await agent.create_request({k: v for k, v in params.items() if k != "title_hint"})
        return {"state": r.get("state"), "to": (r.get("request") or {}).get("to_user", {}).get("name")}
    if action == "reply":
        await agent.sync_inbox()
        waiting = [x for x in agent.inbox["received"] if x["status"] == "waiting"]
        if not waiting:
            return {"skipped": "답변할 요청 없음"}
        draft = await agent.draft_reply(waiting[0]["request_id"])
        r = await agent.send_reply(waiting[0]["request_id"], draft["text"])
        return {"state": r.get("state")}
    if action == "weekly":
        d = await agent.draft_weekly()
        r = await agent.submit_weekly({k: d[k] for k in ("week", "summary", "items", "next_week")})
        return {"state": r.get("state")}
    if action == "offline":
        await set_offline(params.get("offline", False))
        return {"offline": agent.offline}
    raise HTTPException(400, f"unknown demo action: {action}")


@app.post("/api/demo/run")
async def demo_run(body: dict = Body(...)) -> dict:
    action, params = body["action"], body.get("params", {})
    if agent.ui.subscriber_count("ui") > 0:
        rid = uuid.uuid4().hex
        fut = asyncio.get_running_loop().create_future()
        demo_waiters[rid] = fut
        agent.ui.publish("ui", "demo.action", {"id": rid, "action": action, "params": params,
                                               "title": body.get("title", "")})
        # 3초 안에 화면이 맡지 않으면(창이 가려져 있거나 닫힘) 직접 수행
        for _ in range(30):
            if rid in demo_claimed:
                break
            await asyncio.sleep(0.1)
        if rid not in demo_claimed:
            demo_waiters.pop(rid, None)
            return {"via": "direct", **await run_direct(action, params)}
        try:
            return {"via": "ui", **await asyncio.wait_for(fut, timeout=float(body.get("timeout", 150)))}
        except asyncio.TimeoutError:
            if rid not in demo_claimed:  # 화면이 받지 못했으면 직접 수행
                return {"via": "direct", **await run_direct(action, params)}
            return {"via": "ui", "timeout": True}
        finally:
            demo_waiters.pop(rid, None)
            demo_claimed.discard(rid)
    return {"via": "direct", **await run_direct(action, params)}


@app.post("/api/demo/claim/{rid}")
async def demo_claim(rid: str) -> dict:
    """같은 PC 화면이 여러 탭에 열려 있어도 한 탭만 수행하도록."""
    if rid in demo_waiters and rid not in demo_claimed:
        demo_claimed.add(rid)
        return {"ok": True}
    return {"ok": False}


@app.post("/api/demo/done/{rid}")
async def demo_done(rid: str, body: dict = Body(default={})) -> dict:
    fut = demo_waiters.get(rid)
    if fut and not fut.done():
        fut.set_result(body)
    return {"ok": True}


@app.post("/api/demo/reset")
async def demo_reset() -> dict:
    """시연용 초기화: PC 로컬 데이터를 원본 파일로 되돌리고 화면을 새로 고친다."""
    if agent.offline:
        await set_offline(False)
    agent.tools = LocalTools(agent.tools.profile_dir, agent.tools.today)
    agent.hub.outbound.clear()
    agent._people_cache = None
    agent.inbox = {"received": [], "sent": []}
    try:
        await agent.sync_inbox()
    except Exception:  # noqa: BLE001 - 서버 초기화 직후일 수 있음
        pass
    agent.ui.publish("ui", "demo.reset", {})
    return {"ok": True}


@app.post("/api/demo/status")
async def demo_status(body: dict = Body(...)) -> dict:
    """화면 상단 '자동 시연' 표시 (on/off, 현재 단계 설명)."""
    agent.ui.publish("ui", "demo.status", body)
    return {"ok": True}