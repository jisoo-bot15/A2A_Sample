"""수신함 구독 - PC 가 서버로 SSE 연결을 열어두고 요청 이벤트를 받는다.

- PC -> 서버 방향 연결만 사용하므로 PC 에 포트 개방/방화벽 변경이 필요 없다.
- 연결 직후(hello) 수신함 전체를 다시 조회해 끊겨 있던 동안의 요청을 동기화한다.
- 끊기면 지수 백오프로 재연결한다.
"""

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable

import httpx

from common.auth import auth_headers

logger = logging.getLogger(__name__)


class InboxListener:
    def __init__(
        self,
        hub_url: str,
        token: str,
        on_event: Callable[[str, dict], Awaitable[None]],
        on_state: Callable[[bool], Awaitable[None]],
    ):
        self.url = f"{hub_url}/api/inbox/stream"
        self.token = token
        self.on_event = on_event
        self.on_state = on_state

    async def run(self) -> None:
        backoff = 1.0
        while True:
            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(10.0, read=60.0)) as client:
                    async with client.stream("GET", self.url, headers=auth_headers(self.token)) as r:
                        r.raise_for_status()
                        await self.on_state(True)
                        backoff = 1.0
                        await self._consume(r)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                logger.info("수신함 연결 끊김: %s (%.0f초 후 재연결)", e.__class__.__name__, backoff)
            await self.on_state(False)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 15.0)

    async def _consume(self, response: httpx.Response) -> None:
        event = "message"
        async for line in response.aiter_lines():
            if line.startswith("event:"):
                event = line[6:].strip()
            elif line.startswith("data:"):
                await self.on_event(event, json.loads(line[5:].strip()))
            elif not line:
                event = "message"
