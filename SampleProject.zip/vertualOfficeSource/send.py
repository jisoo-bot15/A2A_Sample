"""아무 A2A 에이전트에나 메시지를 보내 보는 클라이언트 (오케스트레이터 역할).

    python send.py http://127.0.0.1:9201 "안녕"
    python send.py http://127.0.0.1:9201 "이어서" --context <앞에서 받은 context_id>
    python send.py http://127.0.0.1:9201 --card            카드만 보기

사무공간 허브(:9900)가 켜져 있으면 자기 활동("→ 상대 이름")도 알려서 오케스트레이터 자리에 표시한다.
허브가 없으면 알리지 않고 그냥 보낸다.
"""
import argparse
import asyncio
import json
import sys
import uuid

import httpx
from a2a.client import ClientConfig, create_client
from a2a.helpers.proto_helpers import get_data_parts, get_text_parts
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest, TaskState

HUB = "http://127.0.0.1:9900"
ME = "client:orchestrator"


async def notify(http: httpx.AsyncClient, type_: str, payload: dict | None = None, task_id: str = "") -> None:
    try:
        await http.post(f"{HUB}/events", json={"agentId": ME, "type": type_, "taskId": task_id, "payload": payload or {}}, timeout=1)
    except httpx.HTTPError:
        pass


async def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("url", help="에이전트 주소 예: http://127.0.0.1:9201")
    ap.add_argument("text", nargs="?", default="")
    ap.add_argument("--context", default="", help="이어서 보낼 대화의 context_id")
    ap.add_argument("--card", action="store_true", help="Agent Card 만 출력")
    a = ap.parse_args()
    url = a.url.rstrip("/")

    async with httpx.AsyncClient(timeout=httpx.Timeout(600, connect=5)) as http:
        try:
            r = await http.get(f"{url}/.well-known/agent-card.json")
            r.raise_for_status()
        except httpx.HTTPError as e:
            print(f"✗ Agent Card 를 읽지 못했습니다 ({type(e).__name__}). 에이전트가 켜져 있는지 확인하세요.")
            return 1
        card = r.json()
        print(f"상대: {card['name']}")
        for s in card.get("skills", []):
            print(f"  skill {s['id']}: {s.get('description', '')}")
        if a.card:
            print(json.dumps(card, ensure_ascii=False, indent=2))
            return 0
        if not a.text:
            print("보낼 글이 없습니다. 예: python send.py URL \"안녕\"")
            return 1

        rid = uuid.uuid4().hex[:8]
        await notify(http, "agent.online", {"name": "오케스트레이터", "role": "client", "zone": "exec"})
        await notify(http, "task.started", {"name": f"→ {card['name']}"}, rid)
        await notify(http, "agent.say", {"text": f"→ {card['name']}: {a.text[:40]}"})

        client = await create_client(url, client_config=ClientConfig(httpx_client=http))
        msg = Message(message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=[Part(text=a.text)], context_id=a.context)
        state, context_id = "", a.context
        async for resp in client.send_message(SendMessageRequest(message=msg)):
            kind = resp.WhichOneof("payload")
            if kind == "task":
                context_id, state = resp.task.context_id, TaskState.Name(resp.task.status.state)
                print(f"[task]            id={resp.task.id[:8]}  {state}")
            elif kind == "status_update":
                state = TaskState.Name(resp.status_update.status.state)
                note = " ".join(get_text_parts(resp.status_update.status.message.parts))
                print(f"[status_update]   {state}" + (f"  — {note}" if note else ""))
            elif kind == "artifact_update":
                art = resp.artifact_update.artifact
                print(f"[artifact_update] {art.name}")
                for t in get_text_parts(art.parts):
                    print("  │ " + t.replace("\n", "\n  │ "))
                for d in get_data_parts(art.parts):
                    print("  │ data " + json.dumps(d, ensure_ascii=False)[:300])
            elif kind == "message":
                print("[message]         " + " ".join(get_text_parts(resp.message.parts)))

        done = state == "TASK_STATE_COMPLETED"
        await notify(http, "task.done" if done else "task.failed", {} if done else {"reason": state.replace("TASK_STATE_", "")}, rid)
        print(f"context_id = {context_id}   (이어서 보내려면 --context {context_id})")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
