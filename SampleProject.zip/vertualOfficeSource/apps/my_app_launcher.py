"""[틀] 내 프로그램의 원래 화면을 그대로 띄우면서, 화면에서 한 일을 사무공간에도 알린다.

    python apps/my_app_launcher.py

언제 쓰나: 사람이 쓰는 화면(Tkinter·PyQt·CLI 등)이 따로 있고, 그 화면에서 한 일도 사무공간에
보이게 하고 싶을 때. (A2A 서버로 맡겨진 일은 허브가 알아서 관찰하므로 이 파일이 필요 없다.)

방법: 화면이 일을 시킬 때 부르는 핵심 함수를 '앞뒤로 알림을 보내는 함수'로 바꿔 둔 다음,
원래 화면을 그대로 실행한다. 내 프로젝트 파일은 고치지 않는다.

순서가 중요하다. 화면 코드가 `from 모듈 import 함수` 로 이름을 가져가기 **전에** 바꿔야 한다.
그래서 (1) 모듈 import → (2) 함수 바꾸기 → (3) 화면 모듈 import 순서로 쓴다.
"""
from office_notify import Notifier, attach_project, roster_entry

AGENT_ID = "my-agent"                       # TODO 1: agents.json 의 id (래퍼와 같은 id 면 같은 자리에 표시)
attach_project(roster_entry(AGENT_ID))
office = Notifier(AGENT_ID, "내 화면")       # 말풍선 앞에 [내 화면] 으로 표시

# TODO 2: (1) 핵심 함수가 들어 있는 모듈
# import core.service as service

# TODO 3: (2) 그 함수를 알림 함수로 바꾼다
# _original = service.answer_question
#
# def answer_question(question, *args, **kwargs):
#     tid = office.started(question)                 # 사무공간: 작업 중 + 요청 말풍선
#     try:
#         result = _original(question, *args, **kwargs)
#     except Exception as e:
#         office.failed(tid, str(e))                 # 사무공간: 실패
#         raise
#     office.done(tid, str(result))                  # 사무공간: 결과 말풍선
#     return result
#
# service.answer_question = answer_question

# TODO 4: (3) 원래 화면을 그대로 실행
# import app
# if __name__ == "__main__":
#     office.online()
#     office.heartbeat_forever()   # 화면이 열려 있는 동안 '자리에 있음'
#     app.main()

if __name__ == "__main__":
    raise SystemExit("my_app_launcher.py 는 틀입니다. TODO 2~4 를 내 프로그램에 맞게 채운 뒤 실행하세요. "
                     "예시는 examples/교대_자재_사례/apps/ 를 보세요.")
