"""원래 화면(Tkinter·Streamlit)에서 한 일을 사무공간 허브에 알리는 공통 부품.

허브는 A2A Task 만 관찰하므로, A2A 를 거치지 않는 원래 화면의 작업은 보이지 않는다.
런처가 핵심 함수 앞뒤로 이 모듈을 불러 같은 에이전트 자리(agentId = A2A 주소)에 표시한다.
알림은 별도 스레드에서 보내므로 허브가 꺼져 있거나 느려도 화면은 멈추지 않는다.
"""
import json
import sys
import threading
import time
import urllib.request
import uuid
from pathlib import Path

A2A_DIR = Path(__file__).resolve().parent.parent
HUB = "http://127.0.0.1:9900"


def roster_entry(agent_id: str) -> dict:
    agents = json.loads((A2A_DIR / "agents.json").read_text(encoding="utf-8"))["agents"]
    return next(a for a in agents if a["id"] == agent_id)


def attach_project(entry: dict) -> Path:
    """기존 프로젝트 폴더를 import 경로 맨 앞에 넣는다 (래퍼와 같은 방식, 파일은 고치지 않음)."""
    project = (A2A_DIR / entry["project"]).resolve()
    sys.path.insert(0, str(project))
    sys.dont_write_bytecode = True
    return project


def snippet(text: str, n: int = 48) -> str:
    for line in (text or "").splitlines():
        line = line.replace("**", "").strip(" #│=-*\t")
        if line:
            return line if len(line) <= n else line[:n - 1] + "…"
    return ""


class Notifier:
    def __init__(self, agent_id: str, ui: str):
        entry = roster_entry(agent_id)
        # A2A 와 같은 자리에 앉도록 허브와 같은 키 (url 이 있으면 url, 없으면 127.0.0.1:port)
        self.key = (entry.get("url") or f"http://127.0.0.1:{entry['port']}").rstrip("/")
        self.name = entry["name"]
        self.zone = entry.get("zone", "ops")
        self.ui = ui                                      # 말풍선 앞에 붙는 출처 표시

    def _post(self, ev: dict) -> None:
        def send():
            try:
                req = urllib.request.Request(f"{HUB}/events", data=json.dumps(ev, ensure_ascii=False).encode(),
                                             headers={"Content-Type": "application/json"})
                urllib.request.urlopen(req, timeout=1).read()
            except OSError:
                pass  # 허브가 없으면 알리지 않는다
        threading.Thread(target=send, daemon=True).start()

    def emit(self, type_: str, payload: dict | None = None, task_id: str = "") -> None:
        self._post({"agentId": self.key, "type": type_, "taskId": task_id, "payload": payload or {}})

    def online(self) -> None:
        self.emit("agent.online", {"name": self.name, "zone": self.zone, "role": "server"})

    def heartbeat_forever(self, every: float = 2.0) -> None:
        """A2A 서버가 꺼져 있어도 화면이 열려 있는 동안은 자리에 있는 것으로 보이게 한다."""
        def loop():
            while True:
                self.emit("agent.heartbeat")
                time.sleep(every)
        threading.Thread(target=loop, daemon=True).start()

    def started(self, request: str) -> str:
        tid = f"ui-{uuid.uuid4().hex[:8]}"
        self.emit("task.started", {"taskId": tid, "name": f"[{self.ui}] " + (snippet(request, 24) or "작업")}, tid)
        self.emit("agent.say", {"text": f"[{self.ui}] ← " + snippet(request)})
        return tid

    def done(self, tid: str, result: str) -> None:
        self.emit("task.done", {"taskId": tid, "result": f"[{self.ui}] " + snippet(result, 60)}, tid)

    def failed(self, tid: str, reason: str) -> None:
        self.emit("task.failed", {"taskId": tid, "reason": f"[{self.ui}] " + snippet(reason, 60)}, tid)
