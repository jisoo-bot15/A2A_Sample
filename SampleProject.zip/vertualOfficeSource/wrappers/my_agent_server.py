"""[틀] A2A 가 아닌 내 파이썬 프로그램을 A2A 서버로 감싼다. TODO 네 곳만 채우면 된다.

    1) agents.json 에 항목 추가 (id 는 아래 AGENT_ID 와 같게)
         {"id": "my-agent", "name": "내 에이전트", "zone": "trading", "port": 9301,
          "project": "../../내_프로젝트_폴더", "server": "wrappers/my_agent_server.py"}
       project 는 agents.json 기준 상대 경로. 내 프로젝트 파일은 고치지 않는다.
    2) python run_agents.py --office

TODO 를 채우기 전에도 실행된다 — 받은 글을 그대로 돌려주므로 사무공간 연결부터 확인할 수 있다.
"""
import asyncio
import sys

from common import attach_project, make_card, roster_entry, serve

AGENT_ID = "my-agent"                        # TODO 1: agents.json 의 id
ENTRY = roster_entry(AGENT_ID)
PROJECT = attach_project(ENTRY)              # 내 프로젝트 폴더를 import 경로에 붙인다

# TODO 2: 내 프로젝트의 핵심 함수를 가져온다 (화면 코드가 아니라 일을 하는 함수)
# from core.service import answer_question

from a2a.helpers.proto_helpers import (  # noqa: E402
    new_data_part, new_task_from_user_message, new_text_message, new_text_part,
)
from a2a.server.agent_execution import AgentExecutor, RequestContext  # noqa: E402
from a2a.server.events import EventQueue  # noqa: E402
from a2a.server.tasks.task_updater import TaskUpdater  # noqa: E402
from a2a.types.a2a_pb2 import AgentSkill, TaskState  # noqa: E402


def run(text: str) -> tuple[str, dict]:
    """받은 글로 내 함수를 부르고 (사람이 읽을 답, 구조화 데이터) 를 돌려준다. 실패면 예외를 낸다."""
    # TODO 3: 내 함수를 부른다. 예) result = answer_question(text); return result.text, result.to_dict()
    return f"(아직 내 함수와 연결 안 됨) 받은 글: {text}", {"input": text}


class MyExecutor(AgentExecutor):
    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)                                   # 1. Task
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        await updater.update_status(TaskState.TASK_STATE_WORKING)              # 2. 작업 중

        try:
            text, data = await asyncio.to_thread(run, context.get_user_input())  # 3. 내 함수 (이벤트 루프를 막지 않게)
        except Exception as e:
            await updater.failed(new_text_message(f"{type(e).__name__}: {e}",   # 4b. 실패
                                                  context_id=task.context_id, task_id=task.id))
            return

        summary = text.strip().splitlines()[0][:60] if text.strip() else "완료"  # 사무공간 결과 말풍선
        await updater.add_artifact(parts=[new_text_part(text), new_data_part(data)], name="result",
                                   metadata={"summary": summary})              # 4a. 결과물
        await updater.complete()                                                # 5. 완료

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("cancel is not supported")


# TODO 4: 다른 에이전트(와 LLM 라우터)가 읽는 자기소개. 무엇을 받고 무엇을 돌려주는지 구체적으로.
SKILL = AgentSkill(
    id="my.skill",
    name="내 에이전트가 하는 일",
    description="무엇을 입력받아 무엇을 돌려주는지 한두 문장으로",
    tags=["example"],
    examples=["이런 질문을 보내면 됩니다"],
    input_modes=["text/plain"],
    output_modes=["text/plain", "application/json"],
)

if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    card = make_card(ENTRY, "내 에이전트 설명 (래퍼)", [SKILL])
    serve(card, MyExecutor(), ENTRY["port"])
