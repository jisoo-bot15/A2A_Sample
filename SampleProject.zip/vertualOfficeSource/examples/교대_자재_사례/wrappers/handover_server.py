"""01_인수인계_보고서 를 A2A 서버로 감싼다.

    python wrappers/handover_server.py          실제 Claude 호출 (API 비용 발생)
    python wrappers/handover_server.py --mock   API 호출 없이, 같은 메모로 이미 만든 보고서를 돌려준다

입력: Message 의 DataPart {"memo", "shift", "writer", "target", "work_date"} — 또는 TextPart 에 메모만.
출력: Artifact "handover_report" = DataPart(보고서 JSON) + TextPart(사람이 읽는 보고서).
실제 모드에서 만든 보고서는 기존 앱과 같은 reports/ 폴더에 저장되어 [보고서 보기] 탭에도 나온다.
"""
import argparse
import asyncio
import json
import sys
import time

from common import MOCK_DELAY_SEC, attach_project, make_card, roster_entry, serve

ENTRY = roster_entry("handover")
attach_project(ENTRY)

from core.client import HandoverError, clean_memo, make_report  # noqa: E402  (01 프로젝트 코드)
from core.dates import parse_work_date  # noqa: E402
from core.render import render_text  # noqa: E402
from core.schema import HandoverReport  # noqa: E402
from core.storage import REPORTS_DIR, save  # noqa: E402
from core.validate import validate  # noqa: E402

from a2a.helpers.proto_helpers import (  # noqa: E402
    get_data_parts, get_text_parts, new_data_part, new_task_from_user_message, new_text_message, new_text_part,
)
from a2a.server.agent_execution import AgentExecutor, RequestContext  # noqa: E402
from a2a.server.events import EventQueue  # noqa: E402
from a2a.server.tasks.task_updater import TaskUpdater  # noqa: E402
from a2a.types.a2a_pb2 import AgentSkill, TaskState  # noqa: E402

FIELDS = ("memo", "shift", "writer", "target", "work_date")


def parse_request(message) -> dict:
    """DataPart 의 필드를 먼저 쓰고, memo 가 없으면 TextPart 를 메모로 쓴다."""
    args = {k: "" for k in FIELDS}
    for d in get_data_parts(message.parts):
        if isinstance(d, dict):
            args.update({k: str(d[k]) for k in FIELDS if d.get(k)})
    if not args["memo"]:
        args["memo"] = "\n".join(get_text_parts(message.parts))
    return args


def find_stored(memo: str) -> dict | None:
    """모의 모드: 같은 메모로 이미 저장된 보고서(최신본)를 찾는다."""
    for p in sorted(REPORTS_DIR.glob("*.json"), reverse=True):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if clean_memo(data.get("memo", "")) == memo:
            return data
    return None


def run(memo: str, shift: str, writer: str, target: str, work_date: str, mock: bool) -> tuple[dict, str]:
    memo = clean_memo(memo)
    if not memo:
        raise HandoverError("메모가 비어 있습니다.")
    if work_date:
        try:
            parse_work_date(work_date)
        except ValueError:
            raise HandoverError("근무일은 YYYY-MM-DD 형식으로 보내세요.")

    if mock:
        time.sleep(MOCK_DELAY_SEC)  # LLM 처리 시간 흉내 — 사무공간에 '작업 중'이 보이도록
        data = find_stored(memo)
        if data is None:
            raise HandoverError("모의 모드: 같은 메모로 만든 기존 보고서가 reports/ 에 없습니다.")
        report = HandoverReport.model_validate(data["report"])
        meta, warnings = {**data["meta"], "mock": True}, data["warnings"]
    else:
        report = make_report(memo, shift, writer, target)
        warnings = validate(report, memo)
        meta = {"shift": shift, "writer": writer, "target": target, "source": "A2A"}
        if work_date:
            meta["work_date"] = work_date
        path = save(report, memo, meta, warnings)
        meta = json.loads(path.read_text(encoding="utf-8"))["meta"]

    result = {"file": meta.get("file", ""), "mock": mock, "report": report.model_dump(), "warnings": warnings}
    return result, render_text(report, memo, meta, warnings)


class HandoverExecutor(AgentExecutor):
    def __init__(self, mock: bool):
        self.mock = mock

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        await updater.update_status(TaskState.TASK_STATE_WORKING)

        try:
            result, text = await asyncio.to_thread(run, **parse_request(context.message), mock=self.mock)
        except HandoverError as e:
            await updater.failed(new_text_message(str(e), context_id=task.context_id, task_id=task.id))
            return

        r = result["report"]
        summary = f"{r['category']} · {r['resolution']} · 확인할 일 {len(r['next_checks'])}건"  # 사무공간 말풍선용
        await updater.add_artifact(parts=[new_data_part(result), new_text_part(text)], name="handover_report",
                                   metadata={"summary": summary})
        await updater.complete()

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("cancel is not supported")


SKILL = AgentSkill(
    id="handover.report",
    name="인수인계 보고서 작성",
    description="교대 근무자의 작업 메모를 발생한 일·조치·현재 상태·다음 근무자 확인 사항·미확인 사항으로 정리한다. "
                "메모에 없는 내용은 채우지 않고 '미확인'으로 표시한다.",
    tags=["handover", "shift", "report", "인수인계"],
    examples=["10:15 포장 1라인 완충재 잔량 확인. 2묶음 남아 있음. ..."],
    input_modes=["text/plain", "application/json"],
    output_modes=["application/json", "text/plain"],
)

if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--mock", action="store_true", help="API 호출 없이 저장된 보고서로 응답")
    a = ap.parse_args()
    card = make_card(ENTRY, "작업 메모를 교대 인수인계 보고서로 정리하는 에이전트 (01_인수인계_보고서 래퍼)", [SKILL])
    serve(card, HandoverExecutor(a.mock), ENTRY["port"])
