"""두 에이전트를 A2A 로 잇는 테스트 클라이언트 (오케스트레이터 역할).

두 에이전트는 서로를 모른다. 이 파일만 둘을 안다.

  1. 발견   agents.json 의 URL 에서 Agent Card 를 읽는다
  2. 위임 1 인수인계 에이전트에 작업 메모를 보내 보고서(JSON)를 받는다
  3. 위임 2 보고서의 대상·현재 상태·확인할 일을 자재대응 에이전트에 넘겨 생산 가능 여부를 묻는다
  4. 이어서 --follow 로 준 답을 같은 context_id 로 보낸다 (되묻기에 답하기)

    python test_client.py --cards-only
    python test_client.py
    python test_client.py --memo ..\\01_인수인계_보고서\\참고\\작업메모_12_작업지시변경.txt --follow "오늘 오후 1시에 시작해"
"""
import argparse
import asyncio
import json
import sys
import uuid
from pathlib import Path

import httpx
from a2a.client import ClientConfig, create_client
from a2a.helpers.proto_helpers import get_data_parts, get_text_parts, new_data_part
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest, TaskState

A2A_DIR = Path(__file__).resolve().parent
DEFAULT_MEMO = A2A_DIR.parent / "01_인수인계_보고서" / "참고" / "작업메모_12_작업지시변경.txt"
TIMEOUT = httpx.Timeout(600, connect=5)  # LLM 작업은 수십 초~수 분 걸린다
HUB = "http://127.0.0.1:9900"            # 사무공간 허브 (office_hub.py). 없으면 알리지 않고 넘어간다
ME = "client:orchestrator"
NAMES = {"handover": "인수인계", "material": "자재대응"}


async def notify(http: httpx.AsyncClient, type_: str, payload: dict | None = None, task_id: str = "") -> None:
    """오케스트레이터 자신의 활동을 허브에 알린다. 에이전트는 허브를 모르지만, 클라이언트는 자기 일을 보고할 수 있다."""
    ev = {"agentId": ME, "type": type_, "taskId": task_id, "payload": payload or {}}
    try:
        await http.post(f"{HUB}/events", json=ev, timeout=1)
    except httpx.HTTPError:
        pass


async def delegate(http: httpx.AsyncClient, urls: dict, who: str, parts: list[Part], say: str,
                   context_id: str | None = None) -> dict:
    """ask() 앞뒤로 허브에 '→ 누구에게 맡김 / 결과'를 알린다."""
    rid = uuid.uuid4().hex[:8]
    await notify(http, "task.started", {"name": f"→ {NAMES[who]}"}, rid)
    await notify(http, "agent.say", {"text": f"→ {NAMES[who]}: {say[:40]}"})
    try:
        r = await ask(http, urls[who], parts, context_id)
    except Exception as e:
        await notify(http, "task.failed", {"reason": f"{NAMES[who]} 호출 실패 · {type(e).__name__}"}, rid)
        raise
    done = r["state"] == "TASK_STATE_COMPLETED"
    await notify(http, "task.done" if done else "task.failed",
                 {} if done else {"reason": r["state"].replace("TASK_STATE_", "")}, rid)
    return r


def roster() -> dict[str, str]:
    agents = json.loads((A2A_DIR / "agents.json").read_text(encoding="utf-8"))["agents"]
    return {a["id"]: (a.get("url") or f"http://127.0.0.1:{a['port']}").rstrip("/") for a in agents}


async def show_card(http: httpx.AsyncClient, url: str) -> bool:
    try:
        r = await http.get(f"{url}/.well-known/agent-card.json")
        r.raise_for_status()
    except httpx.HTTPError as e:
        print(f"  ✗ {url} — 카드를 읽지 못함 ({type(e).__name__})")
        return False
    card = r.json()
    print(f"  ✓ {card['name']}  ({url})")
    for s in card.get("skills", []):
        print(f"      skill {s['id']}: {s['name']}  tags={s.get('tags')}")
    return True


async def ask(http: httpx.AsyncClient, url: str, parts: list[Part], context_id: str | None = None) -> dict:
    """메시지 하나를 보내고 이벤트를 받으며 출력한다. 최종 상태·텍스트·데이터·context_id 를 돌려준다."""
    client = await create_client(url, client_config=ClientConfig(httpx_client=http))
    msg = Message(message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=parts, context_id=context_id or "")
    out = {"state": "", "texts": [], "data": [], "context_id": context_id, "task_id": ""}
    async for resp in client.send_message(SendMessageRequest(message=msg)):
        kind = resp.WhichOneof("payload")
        if kind == "task":
            out["task_id"], out["context_id"] = resp.task.id, resp.task.context_id
            out["state"] = TaskState.Name(resp.task.status.state)
            print(f"    [task]            id={resp.task.id[:8]}  context={resp.task.context_id[:8]}  {out['state']}")
        elif kind == "status_update":
            out["state"] = TaskState.Name(resp.status_update.status.state)
            note = " ".join(get_text_parts(resp.status_update.status.message.parts))
            print(f"    [status_update]   {out['state']}" + (f"  — {note}" if note else ""))
            if note:
                out["texts"].append(note)
        elif kind == "artifact_update":
            art = resp.artifact_update.artifact
            out["texts"] += get_text_parts(art.parts)
            out["data"] += get_data_parts(art.parts)
            print(f"    [artifact_update] {art.name}  text={len(get_text_parts(art.parts))}  data={len(get_data_parts(art.parts))}")
    return out


def material_question(report: dict) -> str:
    """보고서 JSON 에서 자재대응 에이전트에 넘길 내용만 골라 질문을 만든다."""
    lines = lambda key: "\n".join(f"- {i['text']}" for i in report.get(key, [])) or "- (없음)"
    return (
        "아래는 교대 인수인계 보고서의 일부입니다. 보고서에 나온 제품의 남은 작업 수량을 "
        "자재 기준으로 생산할 수 있는지 확인해 주세요. 남은 수량을 확정할 수 없으면 그렇게 말해 주세요.\n\n"
        f"[대상] {report.get('target', '')}\n"
        f"[발생한 일]\n{lines('occurred')}\n"
        f"[현재 상태]\n{lines('current_status')}\n"
        f"[다음 근무자가 확인할 일]\n{lines('next_checks')}"
    )


async def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--memo", type=Path, default=DEFAULT_MEMO)
    ap.add_argument("--shift", default="주간")
    ap.add_argument("--follow", action="append", default=[], help="자재대응 에이전트에 이어서 보낼 말 (여러 번 가능)")
    ap.add_argument("--cards-only", action="store_true")
    a = ap.parse_args()
    urls = roster()

    async with httpx.AsyncClient(timeout=TIMEOUT) as http:
        print("① 발견 — Agent Card")
        ok = [await show_card(http, u) for u in urls.values()]
        if not all(ok):
            print("서버가 떠 있지 않습니다. 먼저 python run_agents.py [--mock] 을 실행하세요.")
            return 1
        if a.cards_only:
            return 0
        await notify(http, "agent.online", {"name": "오케스트레이터", "role": "client", "zone": "exec"})

        print(f"\n② 위임 — 인수인계 에이전트 ← {a.memo.name}")
        memo = a.memo.read_text(encoding="utf-8")
        r1 = await delegate(http, urls, "handover", [new_data_part({"memo": memo, "shift": a.shift})], a.memo.stem)
        if r1["state"] != "TASK_STATE_COMPLETED" or not r1["data"]:
            print(f"  인수인계 단계 실패: {r1['state']} {r1['texts']}")
            return 1
        result = r1["data"][0]
        report = result["report"]
        print(f"  보고서 파일: {result.get('file')}  유형: {report['category']}  해결: {report['resolution']}  "
              f"검증 경고 {len(result['warnings'])}건{'  (모의)' if result.get('mock') else ''}")

        question = material_question(report)
        print("\n③ 위임 — 자재대응 에이전트 ← 보고서에서 만든 질문")
        print("  " + question.replace("\n", "\n  "))
        r2 = await delegate(http, urls, "material", [Part(text=question)], f"{report.get('target', '')} 생산 가능?")
        _print_answer(r2)

        for i, text in enumerate(a.follow, 1):
            print(f"\n④-{i} 이어서 (같은 context_id) ← {text}")
            r2 = await delegate(http, urls, "material", [Part(text=text)], text, context_id=r2["context_id"])
            _print_answer(r2)
    return 0


def _print_answer(r: dict) -> None:
    print(f"  최종 상태: {r['state']}")
    for t in r["texts"]:
        print("  │ " + t.replace("\n", "\n  │ "))
    for d in r["data"]:
        tools = ", ".join(x["name"] for x in d.get("tools", [])) or "없음"
        # DataPart 의 숫자는 protobuf Value 를 거쳐 float 로 돌아온다
        print(f"  도구 {int(d.get('tool_calls', 0))}/{int(d.get('max_tool_calls', 0))}회: {tools}")


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
