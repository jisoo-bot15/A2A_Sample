"""02_자재대응_Agent 의 원래 Streamlit 화면을 띄우되, 질문·답변을 사무공간에도 알린다.

    .venv\\Scripts\\python.exe -m streamlit run apps\\material_app.py

02 폴더의 파일은 고치지 않는다. MaterialAgent.run_turn 을 알림을 끼운 함수로 바꾼 뒤
02 의 app.py 를 그대로 실행한다. Streamlit 은 화면을 조작할 때마다 이 파일을 다시 실행하므로
바꾸기·알림 스레드는 프로세스당 한 번만 한다.
"""
import runpy

from office_notify import Notifier, attach_project, roster_entry

PROJECT = attach_project(roster_entry("material"))

from agent.agent import MaterialAgent  # noqa: E402  (02 프로젝트 코드)

if not getattr(MaterialAgent, "_office_patched", False):
    office = Notifier("material", "Streamlit")
    _run_turn = MaterialAgent.run_turn

    def run_turn(self, messages, user_text):
        tid = office.started(user_text)
        r = _run_turn(self, messages, user_text)
        if r.text:
            office.done(tid, r.text)
        else:
            office.failed(tid, r.warning or "응답 없음")
        return r

    MaterialAgent.run_turn = run_turn
    MaterialAgent._office_patched = True
    office.online()
    office.heartbeat_forever()

runpy.run_path(str(PROJECT / "app.py"), run_name="__main__")  # 02 의 app.py 를 그대로
