"""에코 에이전트 — API 키 없이 사무공간 연동을 확인하는 예제 A2A 서버.

    python agents/echo_agent.py              :9201
    python agents/echo_agent.py --port 9202  다른 포트로 하나 더

책 10장의 echo_server.py 와 같은 뼈대(AgentExecutor + Agent Card + 라우트)이고, 사무공간에서 상태가
보이도록 두 가지만 더했다.
  - 2초 동안 '작업 중'(WORKING)으로 머문다
  - 받은 글에 "실패"가 들어 있으면 FAILED 로 끝난다 → 사무공간에서 실패·경보를 확인할 때 쓴다

이 파일은 사무공간 코드를 하나도 import 하지 않는다. 표준 A2A 서버이기만 하면 사무공간에 앉는다.
"""
import argparse
import asyncio
import sys

import uvicorn
from fastapi import FastAPI

from a2a.helpers.proto_helpers import new_task_from_user_message, new_text_message, new_text_part
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import AgentCapabilities, AgentCard, AgentInterface, AgentSkill, TaskState

WORK_SEC = 2


class EchoExecutor(AgentExecutor):
    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        await updater.update_status(TaskState.TASK_STATE_WORKING)

        text = context.get_user_input().strip()
        await asyncio.sleep(WORK_SEC)  # 실제 에이전트라면 여기서 일을 한다

        if "실패" in text:
            await updater.failed(new_text_message("요청에 '실패'가 있어 일부러 실패 처리했습니다.",
                                                  context_id=task.context_id, task_id=task.id))
            return
        reply = f"echo: {text}"
        await updater.add_artifact(parts=[new_text_part(reply)], name="reply",
                                   metadata={"summary": reply[:60]})  # 사무공간 결과 말풍선
        await updater.complete()

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("cancel is not supported")


def make_app(port: int) -> FastAPI:
    card = AgentCard(
        name="에코 에이전트(예제)",
        description="받은 글을 2초 뒤 그대로 돌려주는 예제 에이전트. '실패'가 들어 있으면 실패로 끝난다.",
        version="0.1.0",
        default_input_modes=["text/plain"],
        default_output_modes=["text/plain"],
        capabilities=AgentCapabilities(streaming=True),
        supported_interfaces=[AgentInterface(url=f"http://127.0.0.1:{port}/", protocol_binding="JSONRPC", protocol_version="1.0")],
        skills=[AgentSkill(id="echo", name="echo", description="입력 텍스트를 그대로 반환한다",
                           tags=["echo", "test"], examples=["안녕", "실패 테스트"],
                           input_modes=["text/plain"], output_modes=["text/plain"])],
    )
    handler = DefaultRequestHandler(agent_executor=EchoExecutor(), task_store=InMemoryTaskStore(), agent_card=card)
    app = FastAPI(title=card.name)
    add_a2a_routes_to_fastapi(app, agent_card_routes=create_agent_card_routes(card),
                              jsonrpc_routes=create_jsonrpc_routes(handler, rpc_url="/"))
    return app


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=9201)
    ap.add_argument("--mock", action="store_true", help="(무시) run_agents.py --mock 과 함께 써도 되도록")
    a = ap.parse_args()
    print(f"에코 에이전트 — http://127.0.0.1:{a.port}/.well-known/agent-card.json", flush=True)
    uvicorn.run(make_app(a.port), host="127.0.0.1", port=a.port, log_level="warning")
