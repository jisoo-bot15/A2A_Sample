# 에이전트 사무공간 — 내 A2A 에이전트를 앉히기

A2A 에이전트들의 상태(대기·작업 중·실패·응답 없음)와 주고받는 일을 가상 사무공간에서 실시간으로 봅니다.
에이전트 쪽에는 사무공간용 코드가 필요 없습니다. 허브가 **A2A 표준(Agent Card 조회 + ListTasks)** 만으로 관찰합니다.

자세한 안내: `docs/사무공간_연동_가이드.docx` · 사례: `docs/A2A_연동방법.docx`

## 1. 설치 (처음 한 번, Python 3.10 이상 — 3.12 에서 확인)

```powershell
cd vertualOfficeSource
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## 2. 5분 확인 — 예제 에이전트로 (API 키 필요 없음)

```powershell
python run_agents.py --office                  # 터미널 1: 에코 에이전트 + 사무공간 허브
# 브라우저로 http://127.0.0.1:9900/ 열기          → 에코 에이전트가 자리에 앉음
python send.py http://127.0.0.1:9201 "안녕"      # 터미널 2: 초록(작업 중) 2초 → 결과 말풍선
python send.py http://127.0.0.1:9201 "실패 테스트"   # 실패. 20초 안에 두 번이면 빨강 경보
```

## 3. 내 에이전트 연결 — 세 가지 경우

| 내 에이전트가 | 할 일 |
|---|---|
| **이미 A2A 서버** (책 실습 서버 등) | `agents.json` 의 `agents` 에 `{"id", "name", "zone", "url"}` 한 줄. 에이전트 코드는 그대로 |
| **A2A 가 아닌 파이썬 프로그램** | `wrappers/my_agent_server.py` 틀의 TODO 4곳을 채우고 `agents.json` 에 `port`·`project`·`server` 항목 추가 |
| **사람이 쓰는 화면도 있음** | 위에 더해 `apps/my_app_launcher.py` 틀로 원래 화면을 띄우면 화면에서 한 일도 같은 자리에 표시 |

`agents.json` 의 `_examples` 에 세 경우의 항목 예가 있습니다. 바꾼 뒤에는 `run_agents.py` 를 다시 실행하세요.

## 4. 사무공간 크기와 구역 (`agents.json` 의 `office`)

| preset | 칸 | 쓸 수 있는 zone |
|---|---|---|
| studio | 2 | exec |
| small (기본) | 6 | trading(3) · ops(3) |
| dept | 12 | trading · content · ops (각 4) |
| hq | 20 | exec(1) · trading(7) · content(7) · ops(5) |

`labels` 로 구역 이름을 바꿉니다. 프리셋에 없는 zone 을 적으면 비슷한 구역으로, 칸이 모자라면 다른 구역으로 옮겨 앉습니다.

## 5. 폴더

| 경로 | 내용 |
|---|---|
| `office_hub.py` | 관찰 허브 :9900 — 화면 제공 + 에이전트 관찰 + 이벤트 스트림(SSE) |
| `office/agentUI.html` | 사무공간 화면 (이미지까지 들어 있는 한 파일) |
| `agents.json` | 에이전트 명부 + 사무공간 설정 |
| `run_agents.py` | 명부의 에이전트(server 항목)와 허브를 띄움 |
| `send.py` | 아무 A2A 에이전트에 메시지 보내기 (오케스트레이터 역할, 허브에 자기 활동도 알림) |
| `agents/echo_agent.py` | 예제 A2A 에이전트 (책 echo_server 와 같은 뼈대) |
| `wrappers/common.py`, `wrappers/my_agent_server.py` | 래퍼 공통 부품과 틀 |
| `apps/office_notify.py`, `apps/my_app_launcher.py` | 런처 공통 부품과 틀 |
| `examples/교대_자재_사례/` | 실제 사례 코드 (교대 인수인계 + 자재대응). 읽기용 |
| `docs/` | 안내서·사례 문서·화면 캡처 |

## 6. 직접 알리기 (선택)

서버가 아닌 참여자(오케스트레이터, 화면 등)는 허브에 이벤트를 직접 보낼 수 있습니다.

```
POST http://127.0.0.1:9900/events
{"agentId": "client:my-router", "type": "task.started", "taskId": "t1", "payload": {"name": "→ 물류 에이전트"}}
```

type: `agent.online`(name·zone·role) · `agent.heartbeat` · `task.started`(name) · `task.done`(result) · `task.failed`(reason) · `agent.say`(text) · `agent.alert`(text)

## 7. 주의

- `127.0.0.1` 에서만 받습니다. 인증이 없으니 외부에 열지 마세요.
- API 키 파일(`claudeapi.txt` 등)은 이 폴더에 넣지 말고, 공유할 때 `.venv` 와 `office/events.jsonl` 은 빼세요.
