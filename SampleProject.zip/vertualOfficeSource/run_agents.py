"""agents.json 의 에이전트를 띄우고, 사무공간 허브도 함께 띄운다. Ctrl+C 로 전부 내린다.

    python run_agents.py            실제 모드
    python run_agents.py --mock     모의 모드 ("mock": true 인 항목에만 --mock 을 넘김. API 호출 없음)
    python run_agents.py --office   사무공간 허브(:9900)도 함께

명부 항목은 두 종류다.
  "server" 가 있는 항목  이 실행기가 그 파일을 띄운다 (래퍼·예제 에이전트). 주소는 127.0.0.1:port
  "url" 만 있는 항목     이미 따로 떠 있는 A2A 에이전트 (다른 팀·책 실습 서버 등). 띄우지 않고 응답만 확인
"""
import argparse
import json
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx

A2A_DIR = Path(__file__).resolve().parent
HUB_PORT = 9900


def agent_url(a: dict) -> str:
    return (a.get("url") or f"http://127.0.0.1:{a['port']}").rstrip("/")


def wait_card(ag: dict, proc=None, timeout: float = 30) -> bool:
    url = agent_url(ag) + "/.well-known/agent-card.json"
    deadline = time.time() + timeout
    while time.time() < deadline:
        if proc is not None and proc.poll() is not None:
            print(f"✗ {ag['name']} 프로세스가 종료됨 (코드 {proc.returncode})")
            return False
        try:
            httpx.get(url, timeout=1).raise_for_status()
            return True
        except httpx.HTTPError:
            time.sleep(0.3)
    return False


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--mock", action="store_true")
    ap.add_argument("--office", action="store_true", help=f"사무공간 허브(:{HUB_PORT})도 함께 띄운다")
    a = ap.parse_args()

    agents = json.loads((A2A_DIR / "agents.json").read_text(encoding="utf-8"))["agents"]
    launched = [ag for ag in agents if ag.get("server")]
    external = [ag for ag in agents if not ag.get("server")]

    ports = launched + ([{"name": "사무공간 허브", "port": HUB_PORT}] if a.office else [])
    busy = [ag for ag in ports if _port_in_use(ag["port"])]
    if busy:  # 이미 떠 있는 서버의 응답을 새 서버로 착각하지 않도록 먼저 막는다
        for ag in busy:
            print(f"✗ 포트 {ag['port']}({ag['name']})를 다른 프로세스가 쓰고 있습니다. 먼저 종료하세요.")
        return 1

    procs = []
    for ag in launched:
        server = A2A_DIR / ag["server"]
        cmd = [sys.executable, str(server)] + (["--mock"] if a.mock and ag.get("mock") else [])
        procs.append((ag, subprocess.Popen(cmd, cwd=server.parent)))
    for ag, p in procs:
        ok = wait_card(ag, p)
        print(f"{'✓' if ok else '✗'} {ag['name']} {'준비됨' if ok else '응답 없음'} — {agent_url(ag)}")
    for ag in external:  # 띄우지 않는다. 허브가 응답할 때부터 자리에 앉힌다
        ok = wait_card(ag, timeout=2)
        print(f"{'✓' if ok else '…'} {ag['name']} (외부) {'응답함' if ok else '아직 응답 없음 — 켜지면 자리에 앉음'} — {agent_url(ag)}")

    if a.office:  # 사무공간 허브 — 에이전트를 관찰만 하므로 에이전트보다 나중에 띄운다
        hub = subprocess.Popen([sys.executable, str(A2A_DIR / "office_hub.py")], cwd=A2A_DIR)
        procs.append(({"name": "사무공간 허브", "port": HUB_PORT}, hub))
        for _ in range(60):
            try:
                httpx.get(f"http://127.0.0.1:{HUB_PORT}/health", timeout=1).raise_for_status()
                print(f"✓ 사무공간 허브 준비됨 — 브라우저로 http://127.0.0.1:{HUB_PORT}/ 을 여세요")
                break
            except httpx.HTTPError:
                time.sleep(0.3)

    if not procs:
        print("띄울 항목이 없습니다 (server 항목도 --office 도 없음).")
        return 0
    print("모의 모드" if a.mock else "실제 모드", "— Ctrl+C 로 종료")
    try:
        while any(p.poll() is None for _, p in procs):
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        for _, p in procs:
            if p.poll() is None:
                p.terminate()
    return 0


def _port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


if __name__ == "__main__":
    sys.exit(main())
